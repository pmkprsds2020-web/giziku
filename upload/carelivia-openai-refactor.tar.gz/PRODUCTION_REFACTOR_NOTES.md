# CareLivia — Production AI Refactor: Summary & Checklist

## Apa yang berubah

### Sebelum
- AI reasoning (`generateAIReasoning` di `meal-generator.ts`) dan AI insight
  (`comparisons/route.ts`) memanggil `z-ai-web-dev-sdk`, bukan OpenAI.
- Tidak ada struktur `/api/ai/*`, tidak ada schema validation, tidak ada
  cache, tidak ada logging token/biaya, tidak ada rate limiting.

### Sesudah
- **Semua panggilan AI** melalui OpenAI API resmi (`openai` npm package),
  **hanya di server** (`src/lib/ai/client.ts`, ditandai `import "server-only"`).
- **Struktur route sesuai spek**: `src/app/api/ai/{meal-plan, exercise-plan,
  shopping-planner, nutrition-analysis, food-record, alternative-food,
  patient-summary, reasoning, chat}/route.ts`.
- **Model terpusat** di `src/lib/ai/models.ts` — ganti model tanpa ubah kode lain.
- **Prompt terpisah per fitur** di `src/lib/ai/prompts/*.ts`.
- **Schema validation (Zod) + retry otomatis** di `src/lib/ai/validator/validate.ts`
  — jika output AI tidak sesuai schema, sistem regenerasi otomatis (maks 2x),
  lalu fallback ke pesan "AI sedang tidak tersedia..." tanpa crash.
- **JSON parser toleran** (`src/lib/ai/parser/json-parser.ts`) — menangani
  markdown code fence / teks tambahan dari model.
- **Cache Supabase** (`src/lib/ai/cache.ts`, tabel `ai_cache`) — request
  identik tidak memanggil OpenAI dua kali.
- **Logging Supabase** (`src/lib/ai/logging.ts`, tabel `ai_usage_logs`) —
  response time, prompt/completion tokens, estimasi biaya USD, model, cache hit.
- **Rate limiting** per-IP (`src/lib/ai/rate-limit.ts`) di setiap route AI.
- **Sanitasi input & error** (`src/lib/ai/sanitize.ts`).
- **Streaming** untuk AI Chat (`/api/ai/chat`), **JSON biasa** untuk fitur lain
  — sesuai spek.
- **Meal Plan** tetap presisi ±2%/±2g/±3g karena angka gram dihitung oleh
  optimizer deterministik (`meal-generator.ts`, sudah ada sebelumnya, TIDAK
  diubah logikanya) — AI hanya menambahkan lapisan narasi klinis
  (reasoning, alternatives, warnings) di atasnya.
- `z-ai-web-dev-sdk` sudah tidak dipanggil di manapun (masih ada di
  `package.json` — aman dihapus jika tidak dipakai fitur lain).

## Environment Variables (Vercel → Project Settings → Environment Variables)

```
OPENAI_API_KEY=sk-...                    (ROTATE dulu — key lama sudah terekspos di chat)
NEXT_PUBLIC_SUPABASE_URL=https://...supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=...
SUPABASE_SERVICE_ROLE_KEY=...            (untuk lib/supabase/service.ts — logging & cache)
```

Lihat `.env.example` untuk daftar lengkap + variabel opsional (override model).

## Sebelum deploy ke Vercel

1. **Jalankan migrasi Supabase baru**: `supabase/migrations/019_ai_infrastructure.sql`
   (bisa dijalankan langsung di Supabase SQL Editor — idempotent, aman dijalankan ulang).
2. **Set 4 environment variables** di atas pada Vercel (Production + Preview).
3. `npm install` — package.json sudah diupdate dengan `openai@^7.2.0` dan `server-only`.
4. Jalankan `npx prisma generate` sebelum build jika masih memakai Prisma
   untuk sebagian data (proyek ini hybrid Prisma→Supabase; lihat catatan di bawah).
5. `next.config.ts` sudah punya `typescript: { ignoreBuildErrors: true }` —
   pertimbangkan untuk mengaktifkan kembali setelah migrasi Prisma→Supabase
   selesai total, supaya error tipe tidak lolos ke production tanpa sadar.

## Yang masih perlu dikerjakan (tidak termasuk dalam sesi ini)

Ini refactor besar (30+ route API, migrasi Prisma→Supabase yang belum
100% selesai). Bagian AI-nya (fokus permintaan Anda) sudah lengkap dan
mengikuti pola yang konsisten. Sisanya:

- **Frontend wiring**: hook-hook di `src/hooks/use-carelivia.ts` masih
  memanggil `/api/meal-plan`, `/api/exercise`, `/api/shopping`, dll (route
  lama, non-AI-prefixed). Beberapa dari route lama itu sendiri belum
  dipindah ke pipeline OpenAI (mis. `/api/exercise/route.ts`,
  `/api/shopping/route.ts` saat ini kemungkinan besar masih rule-based
  tanpa AI). Untuk fitur baru (`exercise-plan`, `shopping-planner`,
  `alternative-food`, `food-record`, `patient-summary`) yang sudah dibuat
  di `/api/ai/*`, UI perlu diarahkan untuk memanggilnya.
- **Migrasi Prisma → Supabase**: masih ada file di `src/lib/repositories/`
  dan banyak import `@prisma/client` types (`DiagnosisType`, `MealSlot`,
  dst.) di komponen — ini pre-existing, bukan bagian dari refactor AI, tapi
  memengaruhi typecheck bersih. `prisma generate` gagal di sandbox ini
  karena `binaries.prisma.sh` tidak bisa diakses (akan berhasil normal di
  Vercel/lokal dengan akses internet penuh).
- **Testing end-to-end** terhadap OpenAI & Supabase asli belum bisa
  dilakukan dari sandbox ini (tidak ada akses jaringan ke `api.openai.com`
  / `*.supabase.co`). Setelah deploy, jalankan checklist "Acceptance Test"
  di prompt asli Anda satu per satu.
- **Upstash/Redis rate limiting** jika traffic tinggi lintas region —
  limiter saat ini in-memory per-instance (cukup untuk traffic rendah-menengah).

## Pola untuk menambah fitur AI baru

Setiap route baru di `src/app/api/ai/<fitur>/route.ts` mengikuti pola yang
sama persis (lihat `nutrition-analysis/route.ts` sebagai contoh referensi
paling lengkap): rate limit → zod parse → sanitize → (opsional) cache
lookup → `generateStructured()` → simpan ke Supabase → `logAIUsage()` →
`ok(data)`. Tinggal buat schema di `lib/ai/schemas/`, prompt di
`lib/ai/prompts/`, lalu salin pola route tersebut.
