// CareLivia — UI Navigation Store (Zustand)
"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";

export type ViewKey =
  | "dashboard"
  | "patients"
  | "calorie"
  | "foods"
  | "recipes"
  | "meal-plan"
  | "exercise"
  | "food-record"
  | "shopping"
  | "saved-menus"
  | "price-management"
  | "supabase-monitor"
  | "database-browser"
  | "report";

interface CareLiviaState {
  activeView: ViewKey;
  activePatientId: string | null;
  sidebarOpen: boolean;
  theme: "light" | "dark";
  setActiveView: (v: ViewKey) => void;
  setActivePatient: (id: string | null) => void;
  setSidebarOpen: (o: boolean) => void;
  toggleSidebar: () => void;
}

export const useCareLiviaStore = create<CareLiviaState>()(
  persist(
    (set) => ({
      activeView: "dashboard",
      activePatientId: null,
      sidebarOpen: false,
      theme: "light",
      setActiveView: (v) => set({ activeView: v, sidebarOpen: false }),
      setActivePatient: (id) => set({ activePatientId: id }),
      setSidebarOpen: (o) => set({ sidebarOpen: o }),
      toggleSidebar: () => set((s) => ({ sidebarOpen: !s.sidebarOpen })),
    }),
    { name: "carelivia-ui" },
  ),
);
