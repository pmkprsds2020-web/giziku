"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useTheme } from "next-themes";
import { Moon, Sun, Menu, X, Stethoscope, HeartPulse, ChefHat, DollarSign, Database, Table2, User as UserIcon, LogOut, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { useCareLiviaStore, type ViewKey } from "@/store/carelivia";
import { useAuth } from "@/lib/supabase/auth-context";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuLabel,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { useQueryClient } from "@tanstack/react-query";

interface NavItem {
  key: ViewKey;
  label: string;
  short: string;
  icon: React.ComponentType<{ className?: string }>;
  desc: string;
  group: "klinis" | "data" | "output";
}

const NAV_ITEMS: NavItem[] = [
  { key: "dashboard", label: "Dashboard", short: "Home", icon: HeartPulse, desc: "Ringkasan klinis & tren pasien", group: "klinis" },
  { key: "patients", label: "Manajemen Pasien", short: "Pasien", icon: Stethoscope, desc: "Data pasien & asesmen gizi", group: "klinis" },
  { key: "calorie", label: "Kalkulator Kalori", short: "Kalori", icon: Stethoscope, desc: "Formula CareLivia 11 langkah", group: "klinis" },
  { key: "meal-plan", label: "AI Meal Plan", short: "Meal Plan", icon: Stethoscope, desc: "Generator rencana makan AI", group: "klinis" },
  { key: "exercise", label: "Exercise Plan", short: "Olahraga", icon: Stethoscope, desc: "Rencana latihan terpersonalisasi", group: "klinis" },
  { key: "foods", label: "Database Bahan Makanan", short: "Bahan Makanan", icon: Stethoscope, desc: "TKPI/DKBM 73 bahan", group: "data" },
  { key: "recipes", label: "Resep & Menu", short: "Resep", icon: ChefHat, desc: "Manajemen resep & komposisi", group: "data" },
  { key: "price-management", label: "Manajemen Harga", short: "Harga", icon: DollarSign, desc: "Kelola harga bahan makanan", group: "data" },
  { key: "food-record", label: "Catatan Asupan", short: "Asupan", icon: Stethoscope, desc: "Food record harian", group: "data" },
  { key: "saved-menus", label: "Saved Meal Library", short: "Menu Tersimpan", icon: ChefHat, desc: "Template menu & perbandingan", group: "data" },
  { key: "shopping", label: "Shopping Planner", short: "Belanja", icon: Stethoscope, desc: "Daftar belanja & estimasi harga", group: "output" },
  { key: "supabase-monitor", label: "Database Monitor", short: "Monitor", icon: Database, desc: "Status koneksi & kesehatan database", group: "output" },
  { key: "database-browser", label: "Database Browser", short: "Browser", icon: Table2, desc: "Lihat isi tabel database", group: "output" },
  { key: "report", label: "Laporan Klinis PDF", short: "Laporan", icon: Stethoscope, desc: "Laporan nutrisi profesional", group: "output" },
];

const GROUP_LABELS: Record<NavItem["group"], string> = {
  klinis: "Modul Klinis",
  data: "Basis Data & Asupan",
  output: "Output & Laporan",
};

function NavButton({ item }: { item: NavItem }) {
  const { activeView, setActiveView } = useCareLiviaStore();
  const Icon = item.icon;
  const active = activeView === item.key;
  return (
    <button
      onClick={() => setActiveView(item.key)}
      className={cn(
        "group flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm font-medium transition-all",
        active
          ? "bg-primary text-primary-foreground shadow-sm"
          : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
      )}
      aria-current={active ? "page" : undefined}
    >
      <span
        className={cn(
          "flex h-8 w-8 shrink-0 items-center justify-center rounded-md transition-colors",
          active ? "bg-primary-foreground/15" : "bg-sidebar-accent/60 group-hover:bg-sidebar-accent",
        )}
      >
        <Icon className="h-4 w-4" />
      </span>
      <span className="flex flex-col leading-tight">
        <span>{item.label}</span>
        <span
          className={cn(
            "text-[11px] font-normal",
            active ? "text-primary-foreground/70" : "text-muted-foreground",
          )}
        >
          {item.desc}
        </span>
      </span>
    </button>
  );
}

export function AppShell({ children }: { children: React.ReactNode }) {
  const { sidebarOpen, toggleSidebar, setSidebarOpen } = useCareLiviaStore();
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = React.useState(false);
  React.useEffect(() => setMounted(true), []);

  const groups: NavItem["group"][] = ["klinis", "data", "output"];

  return (
    <div className="flex h-screen w-full overflow-hidden bg-background">
      {/* Sidebar — desktop */}
      <aside className="hidden w-72 shrink-0 border-r border-sidebar-border bg-sidebar lg:flex lg:flex-col">
        <SidebarContent groups={groups} />
      </aside>

      {/* Sidebar — mobile drawer */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="absolute inset-0 bg-black/50 backdrop-blur-sm"
            onClick={() => setSidebarOpen(false)}
          />
          <aside className="absolute left-0 top-0 flex h-full w-72 flex-col border-r border-sidebar-border bg-sidebar shadow-xl">
            <div className="flex items-center justify-between border-b border-sidebar-border px-4 py-3">
              <Brand />
              <Button variant="ghost" size="icon" onClick={() => setSidebarOpen(false)}>
                <X className="h-5 w-5" />
              </Button>
            </div>
            <SidebarContent groups={groups} />
          </aside>
        </div>
      )}

      {/* Main */}
      <div className="flex h-screen min-w-0 flex-1 flex-col overflow-hidden">
        <Header
          onMenu={toggleSidebar}
          theme={theme}
          toggleTheme={() => setTheme(theme === "dark" ? "light" : "dark")}
          mounted={mounted}
        />
        <main className="flex-1 overflow-y-auto overflow-x-hidden bg-gradient-to-b from-background to-muted/30">
          <div className="mx-auto w-full max-w-[1400px] px-4 py-6 sm:px-6 lg:px-8">
            {children}
          </div>
        </main>
        <Footer />
      </div>
    </div>
  );
}

function SidebarContent({ groups }: { groups: NavItem["group"][] }) {
  return (
    <div className="flex h-full flex-col">
      <div className="hidden border-b border-sidebar-border px-5 py-4 lg:block">
        <Brand />
      </div>
      <nav className="flex-1 space-y-6 overflow-y-auto px-3 py-4">
        {groups.map((g) => (
          <div key={g} className="space-y-1.5">
            <p className="px-3 text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
              {GROUP_LABELS[g]}
            </p>
            {NAV_ITEMS.filter((i) => i.group === g).map((item) => (
              <NavButton key={item.key} item={item} />
            ))}
          </div>
        ))}
      </nav>
      <div className="border-t border-sidebar-border p-4">
        <div className="rounded-lg bg-sidebar-accent/50 p-3">
          <p className="text-xs font-semibold text-sidebar-accent-foreground">
            CareLivia CNMS v1.0
          </p>
          <p className="mt-0.5 text-[11px] text-muted-foreground">
            Clinical Nutrition Decision Support System. Sesuai PERKENI, ESPEN,
            ASPEN, KDIGO, WHO &amp; Kemenkes RI.
          </p>
          <div className="mt-2 flex flex-wrap gap-1">
            <Badge variant="secondary" className="text-[10px]">
              TKPI/DKBM
            </Badge>
            <Badge variant="secondary" className="text-[10px]">
              AI Engine
            </Badge>
          </div>
        </div>
      </div>
    </div>
  );
}

function Brand() {
  return (
    <Link href="/" className="flex items-center gap-2.5">
      <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-chart-2 text-primary-foreground shadow-sm">
        <HeartPulse className="h-5 w-5" />
      </div>
      <div className="flex flex-col leading-tight">
        <span className="text-base font-bold tracking-tight text-sidebar-foreground">
          CareLivia
        </span>
        <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
          Clinical Nutrition
        </span>
      </div>
    </Link>
  );
}

function Header({
  onMenu,
  theme,
  toggleTheme,
  mounted,
}: {
  onMenu: () => void;
  theme: string | undefined;
  toggleTheme: () => void;
  mounted: boolean;
}) {
  const { activeView } = useCareLiviaStore();
  const current = NAV_ITEMS.find((i) => i.key === activeView);
  return (
    <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-border bg-background/80 px-4 backdrop-blur-md sm:px-6">
      <div className="flex items-center gap-3">
        <Button
          variant="ghost"
          size="icon"
          className="lg:hidden"
          onClick={onMenu}
          aria-label="Buka menu"
        >
          <Menu className="h-5 w-5" />
        </Button>
        <div className="flex items-center gap-2 lg:hidden">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-primary to-chart-2 text-primary-foreground">
            <HeartPulse className="h-4 w-4" />
          </div>
        </div>
        <div className="hidden flex-col leading-tight sm:flex">
          <h1 className="text-sm font-semibold text-foreground sm:text-base">
            {current?.label ?? "Dashboard"}
          </h1>
          <p className="text-[11px] text-muted-foreground">
            {current?.desc ?? "Sistem Nutrisi Klinis"}
          </p>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <Badge variant="outline" className="hidden gap-1 text-xs sm:flex">
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
          Sistem Aktif
        </Badge>
        <Button
          variant="ghost"
          size="icon"
          onClick={toggleTheme}
          aria-label="Ganti tema"
          className="h-9 w-9"
        >
          {mounted && theme === "dark" ? (
            <Sun className="h-4 w-4" />
          ) : (
            <Moon className="h-4 w-4" />
          )}
        </Button>
        <UserMenu />
      </div>
    </header>
  );
}

function Footer() {
  return (
    <footer className="mt-auto border-t border-border bg-background px-4 py-4 sm:px-6">
      <div className="mx-auto flex w-full max-w-[1400px] flex-col items-center justify-between gap-2 text-xs text-muted-foreground sm:flex-row">
        <p>
          © {new Date().getFullYear()} CareLivia CNMS — Clinical Nutrition
          Decision Support System
        </p>
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1">
            <HeartPulse className="h-3 w-3 text-primary" />
            Powered by CareLivia Engine
          </span>
          <span className="hidden sm:inline">·</span>
          <span className="hidden sm:inline">
            PERKENI · ESPEN · ASPEN · KDIGO · WHO
          </span>
        </div>
      </div>
    </footer>
  );
}

function UserMenu() {
  const { user, signOut } = useAuth();
  const router = useRouter();
  const qc = useQueryClient();
  const [showLogoutConfirm, setShowLogoutConfirm] = React.useState(false);

  const handleLogout = async () => {
    try {
      await signOut();
      // Clear all React Query cache
      qc.clear();
      // Clear localStorage and sessionStorage
      try {
        localStorage.clear();
        sessionStorage.clear();
      } catch {}
      // Redirect to login
      router.push("/login");
      router.refresh();
    } catch (e) {
      console.error("Logout error:", e);
      router.push("/login");
    }
  };

  // If not logged in, show login link
  if (!user) {
    return (
      <Button
        variant="outline"
        size="sm"
        onClick={() => router.push("/login")}
        className="h-9 gap-1.5"
      >
        <UserIcon className="h-4 w-4" />
        <span className="hidden sm:inline">Login</span>
      </Button>
    );
  }

  const email = user.email || "";
  const displayName = user.user_metadata?.name || email.split("@")[0] || "User";
  const initials = displayName.substring(0, 2).toUpperCase();

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="sm" className="h-9 gap-2 px-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-full bg-gradient-to-br from-primary to-chart-2 text-xs font-bold text-primary-foreground">
              {initials}
            </div>
            <span className="hidden text-sm font-medium sm:inline">{displayName}</span>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-56">
          <DropdownMenuLabel className="font-normal">
            <div className="flex flex-col space-y-1">
              <p className="text-sm font-medium leading-none">{displayName}</p>
              <p className="text-xs leading-none text-muted-foreground">{email}</p>
            </div>
          </DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={() => router.push("/login")}>
            <Settings className="mr-2 h-4 w-4" />
            <span>Pengaturan</span>
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem
            onClick={() => setShowLogoutConfirm(true)}
            className="text-rose-600 focus:text-rose-700"
          >
            <LogOut className="mr-2 h-4 w-4" />
            <span>Logout</span>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      <Dialog open={showLogoutConfirm} onOpenChange={setShowLogoutConfirm}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Keluar dari Akun?</DialogTitle>
            <DialogDescription>
              Apakah Anda yakin ingin keluar? Anda perlu login kembali untuk mengakses aplikasi.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => setShowLogoutConfirm(false)}>
              Batal
            </Button>
            <Button variant="destructive" onClick={handleLogout}>
              <LogOut className="mr-1.5 h-4 w-4" />
              Logout
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
