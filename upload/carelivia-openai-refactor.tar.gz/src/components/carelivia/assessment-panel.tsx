"use client";

import * as React from "react";
import {
  ClipboardCheck,
  Activity,
  Shield,
  Hand,
  Ruler,
  Stethoscope,
  AlertTriangle,
  Save,
  Trash2,
  Plus,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import {
  useAssessments,
  useCreateAssessment,
  useDeleteAssessment,
} from "@/hooks/use-carelivia";
import {
  ACTIVITY_LABELS,
  STRESS_LABELS,
} from "@/lib/clinical/constants";
import type { ActivityLevel, StressLevel } from "@prisma/client";

const ACTIVITY_OPTS = Object.keys(ACTIVITY_LABELS) as ActivityLevel[];
const STRESS_OPTS = Object.keys(STRESS_LABELS) as StressLevel[];

// ---------------------------------------------------------------------
// MUST (Malnutrition Universal Screening Tool) scoring
// BMI: >20 = 0, 18.5-20 = 1, <18.5 = 2
// Weight loss: <5% = 0, 5-10% = 1, >10% = 2
// Acute disease: yes = 2, no = 0
// Total: 0 = LOW, 1 = MEDIUM, ≥2 = HIGH
// ---------------------------------------------------------------------
function computeMUST(bmi: number, weightLossPct: number, acuteDisease: boolean) {
  const bmiScore = bmi > 20 ? 0 : bmi >= 18.5 ? 1 : 2;
  const wlScore = weightLossPct < 5 ? 0 : weightLossPct <= 10 ? 1 : 2;
  const acuteScore = acuteDisease ? 2 : 0;
  const total = bmiScore + wlScore + acuteScore;
  return {
    score: total,
    category: total === 0 ? "LOW" : total === 1 ? "MEDIUM" : "HIGH",
    label:
      total === 0 ? "Risiko Rendah" : total === 1 ? "Risiko Sedang" : "Risiko Tinggi",
    color:
      total === 0 ? "emerald" : total === 1 ? "amber" : "rose",
  };
}

// NRS-2002: score ≥3 = at risk
function computeNRS(impairedNutrition: number, diseaseSeverity: number, ageBonus: boolean) {
  const total = impairedNutrition + diseaseSeverity + (ageBonus ? 1 : 0);
  return {
    score: total,
    category: total >= 3 ? "AT_RISK" : "NOT_AT_RISK",
    label: total >= 3 ? "Berisiko" : "Tidak Berisiko",
  };
}

// MNA Short Form (0-14): 12-14 normal, 8-11 at risk, 0-7 malnourished
function computeMNA(score: number) {
  return {
    category:
      score >= 12 ? "NORMAL" : score >= 8 ? "AT_RISK" : "MALNOURISHED",
    label:
      score >= 12
        ? "Status Gizi Normal"
        : score >= 8
          ? "Berisiko Malnutrisi"
          : "Malnutrisi",
  };
}

// Barthel Index interpretation
function barthelLabel(score: number) {
  if (score >= 95) return { label: "Mandiri", color: "emerald" };
  if (score >= 60) return { label: "Bantuan Minimal", color: "amber" };
  if (score >= 40) return { label: "Bantuan Sedang", color: "amber" };
  if (score >= 20) return { label: "Bantuan Berat", color: "rose" };
  return { label: "Tergantung Total", color: "rose" };
}

// FRAIL scale: 0 = Robust, 1-2 = Prefrail, ≥3 = Frail
function frailtyLabel(score: number) {
  if (score === 0) return { category: "ROBUST", label: "Robust", color: "emerald" };
  if (score <= 2) return { category: "PREFRAIL", label: "Prefrail", color: "amber" };
  return { category: "FRAIL", label: "Frail", color: "rose" };
}

export function AssessmentPanel({ patientId }: { patientId: string }) {
  const { data: assessments, isLoading } = useAssessments(patientId);
  const [showForm, setShowForm] = React.useState(false);
  const deleteMut = useDeleteAssessment();

  const latest = assessments?.[0];

  const handleDelete = async (id: string) => {
    if (!confirm("Hapus asesmen ini?")) return;
    try {
      await deleteMut.mutateAsync(id);
      toast.success("Asesmen dihapus");
    } catch (e: any) {
      toast.error(e.message);
    }
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <ClipboardCheck className="h-4 w-4 text-primary" />
          <h3 className="text-sm font-semibold">Asesmen Gizi & Fungsional</h3>
          {latest && (
            <Badge variant="outline" className="text-[10px]">
              Terakhir: {new Date(latest.recordedAt).toLocaleDateString("id-ID")}
            </Badge>
          )}
        </div>
        <Button size="sm" variant="outline" className="h-8" onClick={() => setShowForm(true)}>
          <Plus className="mr-1.5 h-3.5 w-3.5" /> Asesmen Baru
        </Button>
      </div>

      {isLoading ? (
        <div className="h-32 animate-pulse rounded-lg bg-muted" />
      ) : !assessments || assessments.length === 0 ? (
        <div className="rounded-lg border border-dashed border-border p-6 text-center">
          <ClipboardCheck className="mx-auto mb-2 h-8 w-8 text-muted-foreground/50" />
          <p className="text-sm font-medium">Belum ada asesmen</p>
          <p className="mt-1 text-xs text-muted-foreground">
            Buat asesmen gizi komprehensif (MUST, NRS-2002, SGA, MNA, ECOG, Barthel, Frailty, Fall Risk).
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {/* Latest assessment summary cards */}
          {latest && <AssessmentSummary assessment={latest} />}

          {/* History list */}
          {assessments.length > 1 && (
            <div>
              <p className="mb-1.5 text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                Riwayat Asesmen
              </p>
              <ScrollArea className="max-h-40">
                <div className="space-y-1">
                  {Array.isArray(assessments) && assessments.slice(1).map((a: any) => (
                    <div
                      key={a.id}
                      className="flex items-center justify-between rounded-md border border-border/40 px-3 py-1.5 text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-muted-foreground">
                          {new Date(a.recordedAt).toLocaleDateString("id-ID", {
                            day: "numeric",
                            month: "short",
                            year: "numeric",
                          })}
                        </span>
                        {a.must && (
                          <Badge variant="outline" className="text-[9px]">{a.must}</Badge>
                        )}
                        {a.sga && (
                          <Badge variant="outline" className="text-[9px]">SGA {a.sga}</Badge>
                        )}
                      </div>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-6 w-6 text-rose-500"
                        onClick={() => handleDelete(a.id)}
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>
          )}
        </div>
      )}

      <AssessmentFormDialog
        open={showForm}
        onOpenChange={setShowForm}
        patientId={patientId}
      />
    </div>
  );
}

// ---------------------------------------------------------------------
// Assessment Summary — displays latest assessment as score cards
// ---------------------------------------------------------------------
function AssessmentSummary({ assessment }: { assessment: any }) {
  const mustColor =
    assessment.must === "LOW" ? "emerald" : assessment.must === "MEDIUM" ? "amber" : "rose";
  const sgaColor = assessment.sga === "A" ? "emerald" : assessment.sga === "B" ? "amber" : "rose";
  const frailtyInfo = assessment.frailty
    ? frailtyLabel(assessment.frailtyScore || 0)
    : null;
  const barthelInfo = assessment.barthel != null ? barthelLabel(assessment.barthel) : null;

  return (
    <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
      {assessment.must && (
        <ScoreCard
          title="MUST"
          score={assessment.mustScore != null ? String(assessment.mustScore) : "—"}
          label={assessment.must === "LOW" ? "Risiko Rendah" : assessment.must === "MEDIUM" ? "Risiko Sedang" : "Risiko Tinggi"}
          color={mustColor as any}
          icon={Shield}
        />
      )}
      {assessment.sga && (
        <ScoreCard
          title="SGA"
          score={assessment.sga}
          label={assessment.sga === "A" ? "Gizi Baik" : assessment.sga === "B" ? "Malnutrisi Sedang" : "Malnutrisi Berat"}
          color={sgaColor as any}
          icon={Stethoscope}
        />
      )}
      {assessment.nrs2002 && (
        <ScoreCard
          title="NRS-2002"
          score={assessment.nrsScore != null ? String(assessment.nrsScore) : "—"}
          label={assessment.nrs2002 === "AT_RISK" ? "Berisiko" : "Tidak Berisiko"}
          color={assessment.nrs2002 === "AT_RISK" ? "rose" : "emerald"}
          icon={Shield}
        />
      )}
      {assessment.mna && (
        <ScoreCard
          title="MNA"
          score={assessment.mnaScore != null ? String(assessment.mnaScore) : "—"}
          label={
            assessment.mna === "NORMAL"
              ? "Normal"
              : assessment.mna === "AT_RISK"
                ? "Berisiko"
                : "Malnutrisi"
          }
          color={
            assessment.mna === "NORMAL" ? "emerald" : assessment.mna === "AT_RISK" ? "amber" : "rose"
          }
          icon={Stethoscope}
        />
      )}
      {assessment.ecog != null && (
        <ScoreCard
          title="ECOG"
          score={assessment.ecog}
          label={
            assessment.ecog === "0"
              ? "Aktif"
              : assessment.ecog === "1"
                ? "Aktif Ringan"
                : assessment.ecog === "2"
                  ? "Bisa Jalan"
                  : assessment.ecog === "3"
                    ? "Bedrest >50%"
                    : "Bedrest Total"
          }
          color={Number(assessment.ecog) <= 1 ? "emerald" : Number(assessment.ecog) <= 2 ? "amber" : "rose"}
          icon={Activity}
        />
      )}
      {assessment.barthel != null && barthelInfo && (
        <ScoreCard
          title="Barthel Index"
          score={String(assessment.barthel)}
          label={barthelInfo.label}
          color={barthelInfo.color as any}
          icon={Activity}
        />
      )}
      {assessment.frailty && frailtyInfo && (
        <ScoreCard
          title="Frailty (FRAIL)"
          score={assessment.frailtyScore != null ? String(assessment.frailtyScore) : "—"}
          label={frailtyInfo.label}
          color={frailtyInfo.color as any}
          icon={Shield}
        />
      )}
      {assessment.fallRisk && (
        <ScoreCard
          title="Fall Risk"
          score={assessment.fallRisk}
          label={assessment.fallRisk === "LOW" ? "Rendah" : assessment.fallRisk === "MODERATE" ? "Sedang" : "Tinggi"}
          color={assessment.fallRisk === "LOW" ? "emerald" : assessment.fallRisk === "MODERATE" ? "amber" : "rose"}
          icon={AlertTriangle}
        />
      )}
      {assessment.handGrip != null && (
        <ScoreCard
          title="Hand Grip"
          score={`${assessment.handGrip} kg`}
          label="Kekuatan genggam"
          color="violet"
          icon={Hand}
        />
      )}
      {assessment.calfCirc != null && (
        <ScoreCard
          title="Calf Circ."
          score={`${assessment.calfCirc} cm`}
          label={assessment.calfCirc < 31 ? "Risiko Sarcopenia" : "Normal"}
          color={assessment.calfCirc < 31 ? "amber" : "emerald"}
          icon={Ruler}
        />
      )}
      {assessment.activity && (
        <ScoreCard
          title="Aktivitas"
          score={ACTIVITY_LABELS[assessment.activity as ActivityLevel]?.split(" ")[0] || "—"}
          label="Level aktivitas"
          color="teal"
          icon={Activity}
        />
      )}
      {assessment.stress && assessment.stress !== "NONE" && (
        <ScoreCard
          title="Stress"
          score={STRESS_LABELS[assessment.stress as StressLevel]?.split(" ")[1] || assessment.stress}
          label="Faktor stress"
          color="amber"
          icon={AlertTriangle}
        />
      )}
    </div>
  );
}

function ScoreCard({
  title,
  score,
  label,
  color,
  icon: Icon,
}: {
  title: string;
  score: string;
  label: string;
  color: "emerald" | "amber" | "rose" | "violet" | "teal";
  icon: any;
}) {
  const colorMap: Record<string, string> = {
    emerald: "border-emerald-300 bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-400",
    amber: "border-amber-300 bg-amber-50 dark:bg-amber-950/30 text-amber-700 dark:text-amber-400",
    rose: "border-rose-300 bg-rose-50 dark:bg-rose-950/30 text-rose-700 dark:text-rose-400",
    violet: "border-violet-300 bg-violet-50 dark:bg-violet-950/30 text-violet-700 dark:text-violet-400",
    teal: "border-teal-300 bg-teal-50 dark:bg-teal-950/30 text-teal-700 dark:text-teal-400",
  };
  return (
    <div className={`rounded-lg border p-2.5 ${colorMap[color]}`}>
      <div className="flex items-center justify-between">
        <span className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wide opacity-80">
          <Icon className="h-3 w-3" />
          {title}
        </span>
      </div>
      <p className="mt-1 text-xl font-bold cl-stat-num">{score}</p>
      <p className="text-[10px] opacity-80">{label}</p>
    </div>
  );
}

// ---------------------------------------------------------------------
// Assessment Form Dialog — multi-tab comprehensive clinical assessment
// ---------------------------------------------------------------------
function AssessmentFormDialog({
  open,
  onOpenChange,
  patientId,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  patientId: string;
}) {
  const createMut = useCreateAssessment();

  // MUST inputs
  const [bmi, setBmi] = React.useState("22");
  const [weightLossPct, setWeightLossPct] = React.useState("0");
  const [acuteDisease, setAcuteDisease] = React.useState(false);
  const must = computeMUST(Number(bmi) || 22, Number(weightLossPct) || 0, acuteDisease);

  // NRS-2002 inputs
  const [nrsNutrition, setNrsNutrition] = React.useState(0);
  const [nrsDisease, setNrsDisease] = React.useState(0);
  const [nrsAgeBonus, setNrsAgeBonus] = React.useState(false);
  const nrs = computeNRS(nrsNutrition, nrsDisease, nrsAgeBonus);

  // SGA
  const [sga, setSga] = React.useState<"A" | "B" | "C" | "">("");

  // MNA Short Form (6 questions, max 14)
  const [mnaFoodIntake, setMnaFoodIntake] = React.useState(2); // 0-2
  const [mnaWeightLoss, setMnaWeightLoss] = React.useState(3); // 0-3
  const [mnaMobility, setMnaMobility] = React.useState(2); // 0-2
  const [mnaPsych, setMnaPsych] = React.useState(2); // 0-2
  const [mnaBMI, setMnaBMI] = React.useState(3); // 0-3
  const mnaScore = mnaFoodIntake + mnaWeightLoss + mnaMobility + mnaPsych + mnaBMI;
  const mna = computeMNA(mnaScore);

  // Functional
  const [ecog, setEcog] = React.useState<string>("");
  const [barthel, setBarthel] = React.useState(100);
  const [pps, setPps] = React.useState("");

  // Frailty (FRAIL scale: Fatigue, Resistance, Ambulation, Illnesses, Loss of weight)
  const [frailFatigue, setFrailFatigue] = React.useState(false);
  const [frailResistance, setFrailResistance] = React.useState(false);
  const [frailAmbulation, setFrailAmbulation] = React.useState(false);
  const [frailIllness, setFrailIllness] = React.useState(false);
  const [frailLoss, setFrailLoss] = React.useState(false);
  const frailtyScore = [frailFatigue, frailResistance, frailAmbulation, frailIllness, frailLoss].filter(Boolean).length;
  const frailty = frailtyLabel(frailtyScore);

  // Fall risk
  const [fallRisk, setFallRisk] = React.useState<"LOW" | "MODERATE" | "HIGH" | "">("");

  // Physical
  const [handGrip, setHandGrip] = React.useState("");
  const [calfCirc, setCalfCirc] = React.useState("");

  // CareLivia inputs
  const [activity, setActivity] = React.useState<ActivityLevel>("LIGHT");
  const [stress, setStress] = React.useState<StressLevel>("NONE");
  const [notes, setNotes] = React.useState("");

  const submit = async () => {
    try {
      await createMut.mutateAsync({
        patientId,
        must: must.category,
        mustScore: must.score,
        sga: sga || null,
        nrs2002: nrs.category,
        nrsScore: nrs.score,
        mna: mna.category,
        mnaScore,
        pps: pps || null,
        ecog: ecog || null,
        barthel,
        frailty: frailty.category,
        frailtyScore,
        fallRisk: fallRisk || null,
        handGrip: handGrip ? Number(handGrip) : null,
        calfCirc: calfCirc ? Number(calfCirc) : null,
        activity,
        stress,
        notes,
      });
      toast.success("Asesmen gizi disimpan");
      onOpenChange(false);
      // reset
      setSga("");
      setEcog("");
      setFallRisk("");
      setHandGrip("");
      setCalfCirc("");
      setNotes("");
    } catch (e: any) {
      toast.error(e.message || "Gagal menyimpan asesmen");
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[94vh] overflow-hidden p-0 sm:max-w-[720px]">
        <DialogHeader className="px-6 pt-6 pb-2">
          <DialogTitle className="flex items-center gap-2">
            <ClipboardCheck className="h-5 w-5 text-primary" />
            Asesmen Gizi & Fungsional Komprehensif
          </DialogTitle>
          <DialogDescription>
            Screening multi-alat: MUST, NRS-2002, SGA, MNA, ECOG, Barthel, FRAIL, Fall Risk.
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="screening" className="flex min-h-0 flex-1 flex-col">
          <TabsList className="mx-6 grid grid-cols-4">
            <TabsTrigger value="screening">Screening</TabsTrigger>
            <TabsTrigger value="functional">Fungsional</TabsTrigger>
            <TabsTrigger value="frailty">Frailty & Fall</TabsTrigger>
            <TabsTrigger value="clinical">Klinis</TabsTrigger>
          </TabsList>

          <ScrollArea className="max-h-[55vh] px-6 py-4">
            <TabsContent value="screening" className="mt-0 space-y-4">
              {/* MUST */}
              <AssessmentSection title="MUST (Malnutrition Universal Screening Tool)" icon={Shield}>
                <div className="grid gap-3 sm:grid-cols-3">
                  <div>
                    <Label className="text-xs">BMI (kg/m²)</Label>
                    <Input type="number" value={bmi} onChange={(e) => setBmi(e.target.value)} step="0.1" />
                  </div>
                  <div>
                    <Label className="text-xs">Penurunan BB (%)</Label>
                    <Input type="number" value={weightLossPct} onChange={(e) => setWeightLossPct(e.target.value)} step="0.1" />
                  </div>
                  <div className="flex items-end">
                    <label className="flex cursor-pointer items-center gap-2 text-xs">
                      <Checkbox checked={acuteDisease} onCheckedChange={(c) => setAcuteDisease(!!c)} />
                      Penyakit akut
                    </label>
                  </div>
                </div>
                <ScoreResult score={`Skor: ${must.score}`} label={must.label} color={must.color} />
              </AssessmentSection>

              {/* NRS-2002 */}
              <AssessmentSection title="NRS-2002 (Nutritional Risk Screening)" icon={Shield}>
                <div className="space-y-2">
                  <div>
                    <Label className="text-xs">Gangguan nutrisi (0-3)</Label>
                    <Slider value={[nrsNutrition]} onValueChange={(v) => setNrsNutrition(v[0])} min={0} max={3} step={1} />
                    <p className="mt-1 text-[10px] text-muted-foreground">
                      0=Normal · 1=Ringan · 2=Sedang · 3=Berat
                    </p>
                  </div>
                  <div>
                    <Label className="text-xs">Tingkat keparahan penyakit (0-3)</Label>
                    <Slider value={[nrsDisease]} onValueChange={(v) => setNrsDisease(v[0])} min={0} max={3} step={1} />
                    <p className="mt-1 text-[10px] text-muted-foreground">
                      0=Normal · 1=Ringan · 2=Sedang · 3=Berat
                    </p>
                  </div>
                  <label className="flex cursor-pointer items-center gap-2 text-xs">
                    <Checkbox checked={nrsAgeBonus} onCheckedChange={(c) => setNrsAgeBonus(!!c)} />
                    Pasien ≥70 tahun (+1)
                  </label>
                </div>
                <ScoreResult score={`Skor: ${nrs.score}`} label={nrs.label} color={nrs.score >= 3 ? "rose" : "emerald"} />
              </AssessmentSection>

              {/* SGA */}
              <AssessmentSection title="SGA (Subjective Global Assessment)" icon={Stethoscope}>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { val: "A", label: "A — Gizi Baik", color: "emerald" },
                    { val: "B", label: "B — Sedang", color: "amber" },
                    { val: "C", label: "C — Berat", color: "rose" },
                  ].map((opt) => (
                    <button
                      key={opt.val}
                      onClick={() => setSga(opt.val as any)}
                      className={`rounded-lg border-2 p-3 text-center text-xs font-medium transition-all ${
                        sga === opt.val
                          ? opt.color === "emerald"
                            ? "border-emerald-500 bg-emerald-50 text-emerald-700 dark:bg-emerald-950"
                            : opt.color === "amber"
                              ? "border-amber-500 bg-amber-50 text-amber-700 dark:bg-amber-950"
                              : "border-rose-500 bg-rose-50 text-rose-700 dark:bg-rose-950"
                          : "border-border hover:border-primary/40"
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </AssessmentSection>

              {/* MNA Short Form */}
              <AssessmentSection title="MNA Short Form (Lansia)" icon={Stethoscope}>
                <div className="space-y-2">
                  <MNARow label="Asupan makanan" value={mnaFoodIntake} onChange={setMnaFoodIntake} max={2} hint="0=berkurang drastis · 2=normal" />
                  <MNARow label="Penurunan BB" value={mnaWeightLoss} onChange={setMnaWeightLoss} max={3} hint="0=>3kg · 3=tidak turun" />
                  <MNARow label="Mobilitas" value={mnaMobility} onChange={setMnaMobility} max={2} hint="0=bedrest · 2=berjalan" />
                  <MNARow label="Stress psikologis" value={mnaPsych} onChange={setMnaPsych} max={2} hint="0=depresi berat · 2=normal" />
                  <MNARow label="BMI" value={mnaBMI} onChange={setMnaBMI} max={3} hint="0=<19 · 3=>23" />
                </div>
                <ScoreResult score={`Skor: ${mnaScore}/14`} label={mna.label} color={mnaScore >= 12 ? "emerald" : mnaScore >= 8 ? "amber" : "rose"} />
              </AssessmentSection>
            </TabsContent>

            <TabsContent value="functional" className="mt-0 space-y-4">
              <AssessmentSection title="ECOG Performance Status" icon={Activity}>
                <div className="grid grid-cols-5 gap-1.5">
                  {[
                    { val: "0", label: "0", desc: "Aktif" },
                    { val: "1", label: "1", desc: "Ringan" },
                    { val: "2", label: "2", desc: "Bisa jalan" },
                    { val: "3", label: "3", desc: "Bedrest >50%" },
                    { val: "4", label: "4", desc: "Bedrest total" },
                  ].map((opt) => (
                    <button
                      key={opt.val}
                      onClick={() => setEcog(opt.val)}
                      className={`rounded-lg border-2 p-2 text-center transition-all ${
                        ecog === opt.val
                          ? "border-primary bg-primary/10"
                          : "border-border hover:border-primary/40"
                      }`}
                    >
                      <p className="text-lg font-bold">{opt.label}</p>
                      <p className="text-[9px] text-muted-foreground">{opt.desc}</p>
                    </button>
                  ))}
                </div>
              </AssessmentSection>

              <AssessmentSection title="Barthel Index (Aktivitas Kehidupan Sehari-hari)" icon={Activity}>
                <div>
                  <div className="mb-1.5 flex items-center justify-between text-xs">
                    <span className="font-medium">Skor: {barthel}/100</span>
                    <span className="text-muted-foreground">
                      {barthelLabel(barthel).label}
                    </span>
                  </div>
                  <Slider value={[barthel]} onValueChange={(v) => setBarthel(v[0])} min={0} max={100} step={5} />
                  <div className="mt-1 flex justify-between text-[9px] text-muted-foreground">
                    <span>Tergantung</span>
                    <span>Mandiri</span>
                  </div>
                </div>
              </AssessmentSection>

              <AssessmentSection title="PPS (Palliative Performance Scale)" icon={Stethoscope}>
                <div>
                  <Label className="text-xs">Skor PPS (%)</Label>
                  <Select value={pps} onValueChange={setPps}>
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih skor PPS..." />
                    </SelectTrigger>
                    <SelectContent>
                      {["100", "90", "80", "70", "60", "50", "40", "30", "20", "10"].map((v) => (
                        <SelectItem key={v} value={v}>{v}%</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </AssessmentSection>
            </TabsContent>

            <TabsContent value="frailty" className="mt-0 space-y-4">
              <AssessmentSection title="FRAIL Scale (5 komponen)" icon={Shield}>
                <div className="space-y-2">
                  <FrailRow label="Fatigue — merasa lelah sebagian besar waktu?" checked={frailFatigue} onChange={setFrailFatigue} />
                  <FrailRow label="Resistance — kesulitan naik 10 tangga tanpa bantuan?" checked={frailResistance} onChange={setFrailResistance} />
                  <FrailRow label="Ambulation — kesulitan berjalan satu blok?" checked={frailAmbulation} onChange={setFrailAmbulation} />
                  <FrailRow label="Illnesses — ≥5 kondisi kronis?" checked={frailIllness} onChange={setFrailIllness} />
                  <FrailRow label="Loss of weight — penurunan BB >5% dalam 12 bulan?" checked={frailLoss} onChange={setFrailLoss} />
                </div>
                <ScoreResult score={`Skor: ${frailtyScore}/5`} label={frailty.label} color={frailty.color as any} />
              </AssessmentSection>

              <AssessmentSection title="Fall Risk Assessment" icon={AlertTriangle}>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { val: "LOW", label: "Rendah", color: "emerald" },
                    { val: "MODERATE", label: "Sedang", color: "amber" },
                    { val: "HIGH", label: "Tinggi", color: "rose" },
                  ].map((opt) => (
                    <button
                      key={opt.val}
                      onClick={() => setFallRisk(opt.val as any)}
                      className={`rounded-lg border-2 p-3 text-center text-xs font-medium transition-all ${
                        fallRisk === opt.val
                          ? opt.color === "emerald"
                            ? "border-emerald-500 bg-emerald-50 text-emerald-700 dark:bg-emerald-950"
                            : opt.color === "amber"
                              ? "border-amber-500 bg-amber-50 text-amber-700 dark:bg-amber-950"
                              : "border-rose-500 bg-rose-50 text-rose-700 dark:bg-rose-950"
                          : "border-border hover:border-primary/40"
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </AssessmentSection>

              <AssessmentSection title="Pengukuran Fisik" icon={Ruler}>
                <div className="grid gap-3 sm:grid-cols-2">
                  <div>
                    <Label className="text-xs">Hand Grip Strength (kg)</Label>
                    <Input type="number" value={handGrip} onChange={(e) => setHandGrip(e.target.value)} placeholder="contoh: 25" step="0.1" />
                    <p className="mt-0.5 text-[10px] text-muted-foreground">
                      Sarcopenia: &lt;27kg (P), &lt;35kg (L)
                    </p>
                  </div>
                  <div>
                    <Label className="text-xs">Calf Circumference (cm)</Label>
                    <Input type="number" value={calfCirc} onChange={(e) => setCalfCirc(e.target.value)} placeholder="contoh: 32" step="0.1" />
                    <p className="mt-0.5 text-[10px] text-muted-foreground">
                      Sarcopenia: &lt;31 cm
                    </p>
                  </div>
                </div>
              </AssessmentSection>
            </TabsContent>

            <TabsContent value="clinical" className="mt-0 space-y-4">
              <AssessmentSection title="Input CareLivia Engine" icon={Activity}>
                <div className="grid gap-3 sm:grid-cols-2">
                  <div>
                    <Label className="text-xs">Level Aktivitas</Label>
                    <Select value={activity} onValueChange={(v) => setActivity(v as ActivityLevel)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {ACTIVITY_OPTS.map((a) => (
                          <SelectItem key={a} value={a}>
                            {ACTIVITY_LABELS[a]}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-xs">Stress Klinis</Label>
                    <Select value={stress} onValueChange={(v) => setStress(v as StressLevel)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {STRESS_OPTS.map((s) => (
                          <SelectItem key={s} value={s}>
                            {STRESS_LABELS[s]}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </AssessmentSection>

              <AssessmentSection title="Catatan Klinis" icon={Stethoscope}>
                <Textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Catatan tambahan hasil asesmen..."
                  rows={4}
                />
              </AssessmentSection>
            </TabsContent>
          </ScrollArea>
        </Tabs>

        <DialogFooter className="border-t px-6 py-4">
          <Button variant="outline" onClick={() => onOpenChange(false)}>Batal</Button>
          <Button onClick={submit} disabled={createMut.isPending}>
            {createMut.isPending ? (
              "Menyimpan..."
            ) : (
              <>
                <Save className="mr-2 h-4 w-4" /> Simpan Asesmen
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function AssessmentSection({
  title,
  icon: Icon,
  children,
}: {
  title: string;
  icon: any;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-lg border border-border/60 p-3">
      <p className="mb-2.5 flex items-center gap-1.5 text-xs font-semibold text-foreground">
        <Icon className="h-3.5 w-3.5 text-primary" />
        {title}
      </p>
      {children}
    </div>
  );
}

function ScoreResult({
  score,
  label,
  color,
}: {
  score: string;
  label: string;
  color: "emerald" | "amber" | "rose";
}) {
  const colorMap = {
    emerald: "border-emerald-300 bg-emerald-50 text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-400",
    amber: "border-amber-300 bg-amber-50 text-amber-700 dark:bg-amber-950/30 dark:text-amber-400",
    rose: "border-rose-300 bg-rose-50 text-rose-700 dark:bg-rose-950/30 dark:text-rose-400",
  };
  return (
    <div className={`mt-2.5 flex items-center justify-between rounded-md border px-3 py-1.5 ${colorMap[color]}`}>
      <span className="text-xs font-bold">{score}</span>
      <span className="text-xs">{label}</span>
    </div>
  );
}

function MNARow({
  label,
  value,
  onChange,
  max,
  hint,
}: {
  label: string;
  value: number;
  onChange: (v: number) => void;
  max: number;
  hint: string;
}) {
  return (
    <div>
      <div className="mb-1 flex items-center justify-between text-xs">
        <span className="font-medium">{label}</span>
        <span className="font-mono text-muted-foreground">{value}/{max}</span>
      </div>
      <Slider value={[value]} onValueChange={(v) => onChange(v[0])} min={0} max={max} step={1} />
      <p className="mt-0.5 text-[9px] text-muted-foreground">{hint}</p>
    </div>
  );
}

function FrailRow({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <label className="flex cursor-pointer items-center gap-2 rounded-md border border-border/40 px-3 py-2 text-xs hover:bg-muted/40">
      <Checkbox checked={checked} onCheckedChange={(c) => onChange(!!c)} />
      <span>{label}</span>
    </label>
  );
}
