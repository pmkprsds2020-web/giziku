"use client";

import * as React from "react";
import {
  Utensils,
  Sparkles,
  User,
  Clock,
  CheckCircle2,
  Target,
  TrendingUp,
  Brain,
  AlertCircle,
  Plus,
  Trash2,
  Bookmark,
  Stethoscope,
  Activity,
  Save,
  FolderOpen,
  Apple,
  RotateCw,
  ChevronDown,
  ChevronRight,
  Info,
  X,
  RefreshCw,
  Pencil,
} from "lucide-react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { toast } from "sonner";
import {
  PageHeader,
  SectionCard,
  StatCard,
  EmptyState,
} from "@/components/carelivia/ui-helpers";
import { IsiPiringkuPlate } from "@/components/carelivia/isi-piringku-plate";
import {
  FoodPickerDialog,
  type FoodPickerResult,
} from "@/components/carelivia/food-picker-dialog";
import {
  usePatients,
  useMealPlans,
  useGenerateMealPlan,
  usePreviewIsiPiringku,
  usePresets,
  useCreateSavedMealPlan,
  useAddMealItem,
  useUpdateMealItem,
  useDeleteMealItem,
} from "@/hooks/use-carelivia";
import { useCareLiviaStore } from "@/store/carelivia";
import { DIAGNOSIS_ADJUSTMENTS } from "@/lib/clinical/constants";
import { computeFoodNutrition } from "@/lib/clinical/calorie-engine";
import type { DiagnosisType, MealSlot } from "@prisma/client";
import type { PlateGroup } from "@/lib/clinical/isi-piringku";
import {
  COMPLIANCE_TIER_LABEL,
  COMPLIANCE_TIER_COLOR,
  COMPLIANCE_TIER_ICON,
  PLATE_GROUP_LABEL,
  PLATE_GROUP_ICON,
} from "@/lib/clinical/isi-piringku";

const SLOT_LABELS: Record<MealSlot, string> = {
  BREAKFAST: "Sarapan",
  MORNING_SNACK: "Snack Pagi",
  LUNCH: "Makan Siang",
  AFTERNOON_SNACK: "Snack Sore",
  DINNER: "Makan Malam",
  EVENING_SNACK: "Snack Malam",
};

const SLOT_DISTRIBUTION_PCT: Record<MealSlot, string> = {
  BREAKFAST: "20-25%",
  MORNING_SNACK: "5-10%",
  LUNCH: "30-35%",
  AFTERNOON_SNACK: "5-10%",
  DINNER: "25-30%",
  EVENING_SNACK: "0-5%",
};

const SLOT_COLORS: Record<MealSlot, string> = {
  BREAKFAST: "bg-amber-500/10 text-amber-700 dark:text-amber-400 ring-amber-500/20",
  MORNING_SNACK: "bg-orange-500/10 text-orange-700 dark:text-orange-400 ring-orange-500/20",
  LUNCH: "bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 ring-emerald-500/20",
  AFTERNOON_SNACK: "bg-teal-500/10 text-teal-700 dark:text-teal-400 ring-teal-500/20",
  DINNER: "bg-violet-500/10 text-violet-700 dark:text-violet-400 ring-violet-500/20",
  EVENING_SNACK: "bg-slate-500/10 text-slate-700 dark:text-slate-400 ring-slate-500/20",
};

const MAIN_SLOTS: MealSlot[] = ["BREAKFAST", "LUNCH", "DINNER"];

export function MealPlanView() {
  const { data: patients } = usePatients();
  const { activePatientId } = useCareLiviaStore();
  const [selectedPatientId, setSelectedPatientId] = React.useState<string>(
    activePatientId || "",
  );
  const [activePresetId, setActivePresetId] = React.useState<string | null>(null);
  const [activePresetName, setActivePresetName] = React.useState<string | null>(null);
  const [previewData, setPreviewData] = React.useState<any>(null);
  const [showSaveDialog, setShowSaveDialog] = React.useState(false);
  const [saveName, setSaveName] = React.useState("");

  React.useEffect(() => {
    if (activePatientId && !selectedPatientId) {
      setSelectedPatientId(activePatientId);
    }
  }, [activePatientId, selectedPatientId]);

  const { data: plans, isLoading } = useMealPlans(selectedPatientId || undefined);
  const { data: presets } = usePresets(selectedPatientId || undefined);
  const generateMut = useGenerateMealPlan();
  const previewMut = usePreviewIsiPiringku();
  const saveMut = useCreateSavedMealPlan();

  const latestPlan = plans?.[0];
  const selectedPatient = patients?.find((p) => p.id === selectedPatientId);
  const patientPresets = (presets || []).filter((p: any) => !p.isTemplate);
  const templatePresets = (presets || []).filter((p: any) => p.isTemplate);

  // Sync active preset from latest meal plan
  React.useEffect(() => {
    if (latestPlan?.presetId && !activePresetId) {
      setActivePresetId(latestPlan.presetId);
      setActivePresetName(latestPlan.preset?.name || null);
    }
  }, [latestPlan, activePresetId]);

  const handleGenerate = async () => {
    if (!selectedPatientId) {
      toast.error("Pilih pasien terlebih dahulu");
      return;
    }
    try {
      // Use preview endpoint (no persistence) for live view
      const result = await previewMut.mutateAsync({
        patientId: selectedPatientId,
        presetId: activePresetId || undefined,
      });
      setPreviewData(result);
      toast.success(
        activePresetName
          ? `Meal plan Isi Piringku dibuat dengan preset "${activePresetName}"`
          : "Meal plan Isi Piringku berhasil dibuat",
      );
    } catch (e: any) {
      toast.error(e.message || "Gagal membuat meal plan");
    }
  };

  const handlePersist = async () => {
    if (!selectedPatientId) return;
    try {
      await generateMut.mutateAsync({
        patientId: selectedPatientId,
        presetId: activePresetId || undefined,
      });
      toast.success("Meal plan disimpan ke database");
    } catch (e: any) {
      toast.error(e.message || "Gagal menyimpan meal plan");
    }
  };

  const handleSaveAsTemplate = async () => {
    if (!selectedPatientId || !previewData) return;
    try {
      await saveMut.mutateAsync({
        patientId: selectedPatientId,
        name: saveName || `Meal Plan ${new Date().toLocaleDateString("id-ID")}`,
        date: new Date().toISOString(),
        totalCal: previewData.plan.totals.cal,
        totalProtein: previewData.plan.totals.protein,
        totalFat: previewData.plan.totals.fat,
        totalCarb: previewData.plan.totals.carb,
        totalFiber: previewData.plan.totals.fiber,
        totalSodium: previewData.plan.totals.sodium,
        compliance: previewData.plan.overallCompliance,
        notes: `Compliance: ${previewData.plan.overallTierLabel}`,
        items: previewData.plan.items.map((i: any) => ({
          slot: i.slot,
          foodId: i.foodId,
          amount: i.amount,
          cal: i.cal,
          protein: i.protein,
          fat: i.fat,
          carb: i.carb,
          fiber: i.fiber,
          sodium: i.sodium,
        })),
      });
      toast.success(`Meal plan "${saveName}" disimpan ke library`);
      setShowSaveDialog(false);
      setSaveName("");
    } catch (e: any) {
      toast.error(e.message || "Gagal menyimpan meal plan");
    }
  };

  const handleSelectPreset = (preset: any) => {
    setActivePresetId(preset.id);
    setActivePresetName(preset.name);
    toast.success(`Preset "${preset.name}" dipilih — klik Generate untuk membuat Meal Plan baru`);
  };

  const plan = previewData?.plan;
  const calorieResult = previewData?.calorieResult;
  const aiReasoning = previewData?.aiReasoning;
  const patientInfo = previewData?.patient;
  const targets = previewData?.targets;

  return (
    <div className="space-y-6">
      <PageHeader
        title="AI Meal Plan — Isi Piringku"
        subtitle="Pedoman Gizi Seimbang Kemenkes RI: 4 kelompok makanan di setiap makan utama"
        icon={Utensils}
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setPreviewData(null);
                setActivePresetId(null);
                setActivePresetName(null);
              }}
            >
              <X className="mr-1.5 h-4 w-4" /> Reset
            </Button>
            <Button
              onClick={handleGenerate}
              disabled={previewMut.isPending || !selectedPatientId}
              size="sm"
            >
              <Sparkles className="mr-1.5 h-4 w-4" />
              {previewMut.isPending ? "Menyusun…" : "Generate Isi Piringku"}
            </Button>
          </>
        }
      />

      {/* Patient + Preset selector */}
      <Card className="border-border/60">
        <CardContent className="p-5">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <div>
              <Label className="text-xs font-medium text-muted-foreground">
                <User className="mr-1 inline h-3.5 w-3.5" /> Pasien
              </Label>
              <Select
                value={selectedPatientId}
                onValueChange={setSelectedPatientId}
              >
                <SelectTrigger className="mt-1.5">
                  <SelectValue placeholder="Pilih pasien" />
                </SelectTrigger>
                <SelectContent>
                  {(patients || []).map((p: any) => (
                    <SelectItem key={p.id} value={p.id}>
                      {p.name} — {p.mrn}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-xs font-medium text-muted-foreground">
                <Target className="mr-1 inline h-3.5 w-3.5" /> Preset Aktif (opsional)
              </Label>
              <Select
                value={activePresetId || "__none__"}
                onValueChange={(v) => {
                  if (v === "__none__") {
                    setActivePresetId(null);
                    setActivePresetName(null);
                  } else {
                    const p = (presets || []).find((x: any) => x.id === v);
                    if (p) handleSelectPreset(p);
                  }
                }}
              >
                <SelectTrigger className="mt-1.5">
                  <SelectValue placeholder="Tanpa preset (pakai target CareLivia)" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="__none__">— Tanpa preset —</SelectItem>
                  {patientPresets.length > 0 && (
                    <>
                      <div className="px-2 py-1 text-[10px] font-bold uppercase tracking-wide text-muted-foreground">
                        Preset Pasien
                      </div>
                      {patientPresets.map((p: any) => (
                        <SelectItem key={p.id} value={p.id}>
                          {p.name} ({p.totalCal} kcal)
                        </SelectItem>
                      ))}
                    </>
                  )}
                  {templatePresets.length > 0 && (
                    <>
                      <div className="px-2 py-1 text-[10px] font-bold uppercase tracking-wide text-muted-foreground">
                        Template
                      </div>
                      {templatePresets.map((p: any) => (
                        <SelectItem key={p.id} value={p.id}>
                          {p.name} ({p.totalCal} kcal)
                        </SelectItem>
                      ))}
                    </>
                  )}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-xs font-medium text-muted-foreground">
                <Activity className="mr-1 inline h-3.5 w-3.5" /> Diagnosis Utama
              </Label>
              <div className="mt-1.5 flex flex-wrap gap-1">
                {selectedPatient?.diagnoses?.length ? (
                  selectedPatient.diagnoses.map((raw: any, idx: number) => {
                    const d: string = typeof raw === "string" ? raw : (raw?.type ?? "");
                    if (!d) return null;
                    return (
                      <Badge key={`${d}-${idx}`} variant="secondary" className="text-xs">
                        {DIAGNOSIS_ADJUSTMENTS[d as DiagnosisType]?.label || d}
                      </Badge>
                    );
                  })
                ) : (
                  <Badge variant="outline" className="text-xs">Umum</Badge>
                )}
              </div>
            </div>
          </div>

          {activePresetName && (
            <Alert className="mt-4 border-violet-500/30 bg-violet-500/5">
              <Target className="h-4 w-4 text-violet-600" />
              <AlertTitle className="text-sm">Preset aktif: {activePresetName}</AlertTitle>
              <AlertDescription className="text-xs">
                Target akan di-override dengan nilai preset. Klik Generate untuk menyusun ulang.
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Loading state */}
      {previewMut.isPending && !plan && (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-72 w-full rounded-xl" />
          ))}
        </div>
      )}

      {/* Empty state */}
      {!plan && !previewMut.isPending && (
        <EmptyState
          icon={Utensils}
          title="Belum ada Meal Plan"
          description="Pilih pasien lalu klik Generate untuk menyusun rencana makan sesuai Pedoman Isi Piringku Kemenkes RI. Setiap makan utama akan berisi 4 kelompok: makanan pokok, lauk pauk, sayuran, dan buah."
          action={
            <Button onClick={handleGenerate} disabled={!selectedPatientId}>
              <Sparkles className="mr-1.5 h-4 w-4" /> Generate Sekarang
            </Button>
          }
        />
      )}

      {/* MAIN CONTENT — Isi Piringku plan */}
      {plan && calorieResult && (
        <>
          {/* Top summary stats */}
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard
              label="Target Energi"
              value={calorieResult.targetCalorie.toLocaleString("id-ID")}
              unit="kcal"
              icon={Target}
              color="primary"
              sublabel={`BMI ${calorieResult.bmi} (${calorieResult.bmiLabel})`}
            />
            <StatCard
              label="Energi Aktual"
              value={plan.totals.cal.toLocaleString("id-ID")}
              unit="kcal"
              icon={TrendingUp}
              color="emerald"
              sublabel={`${Math.round((plan.totals.cal / calorieResult.targetCalorie) * 100)}% dari target`}
            />
            <StatCard
              label="Compliance Isi Piringku"
              value={plan.overallCompliance}
              unit="%"
              icon={CheckCircle2}
              color={plan.overallCompliance >= 90 ? "emerald" : plan.overallCompliance >= 70 ? "amber" : "rose"}
              sublabel={`${COMPLIANCE_TIER_ICON[plan.overallTier]} ${plan.overallTierLabel}`}
            />
            <StatCard
              label="Distribusi Makro"
              value={`P${Math.round((plan.totals.protein * 4 / plan.totals.cal) * 100)}/L${Math.round((plan.totals.fat * 9 / plan.totals.cal) * 100)}/K${Math.round((plan.totals.carb * 4 / plan.totals.cal) * 100)}`}
              icon={Activity}
              color="violet"
              sublabel={`Protein ${plan.totals.protein}g · Lemak ${plan.totals.fat}g · Karbo ${plan.totals.carb}g`}
            />
          </div>

          {/* Action bar */}
          <div className="flex flex-wrap items-center gap-2">
            <Button onClick={handleGenerate} variant="outline" size="sm" disabled={previewMut.isPending}>
              <RefreshCw className="mr-1.5 h-4 w-4" />
              {previewMut.isPending ? "Menyusun ulang…" : "Generate Ulang"}
            </Button>
            <Button onClick={handlePersist} variant="default" size="sm" disabled={generateMut.isPending}>
              <Save className="mr-1.5 h-4 w-4" />
              {generateMut.isPending ? "Menyimpan…" : "Simpan ke Database"}
            </Button>
            <Button onClick={() => setShowSaveDialog(true)} variant="outline" size="sm">
              <Bookmark className="mr-1.5 h-4 w-4" /> Simpan ke Library
            </Button>
            {patientInfo && (
              <Badge variant="outline" className="ml-auto text-xs">
                <User className="mr-1 h-3 w-3" />
                {patientInfo.name} · {patientInfo.mrn}
              </Badge>
            )}
          </div>

          {/* ROTATION WARNINGS */}
          {plan.rotationWarnings.length > 0 && (
            <Alert className="border-amber-500/30 bg-amber-500/5">
              <RotateCw className="h-4 w-4 text-amber-600" />
              <AlertTitle className="text-sm">Peringatan Variasi Menu (Rotasi 14 Hari)</AlertTitle>
              <AlertDescription className="text-xs">
                <ul className="list-disc pl-4 space-y-0.5">
                  {plan.rotationWarnings.map((w: string, i: number) => (
                    <li key={i}>{w}</li>
                  ))}
                </ul>
              </AlertDescription>
            </Alert>
          )}

          {/* PLATE VISUALIZATION — 3 main meals */}
          <SectionCard
            title="Visualisasi Isi Piringku"
            description="Setiap makan utama mengikuti proporsi: 2/3 makanan pokok + 1/3 lauk pauk (setengah piring pertama); 2/3 sayuran + 1/3 buah (setengah piring kedua)"
          >
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {plan.slotSummaries
                .filter((s: any) => MAIN_SLOTS.includes(s.slot))
                .map((s: any) => (
                  <PlateMealCard key={s.slot} summary={s} />
                ))}
            </div>
          </SectionCard>

          {/* DETAILED MEAL ITEMS BY SLOT */}
          <SectionCard
            title="Daftar Menu Lengkap"
            description="Klik item untuk melihat alternatif pengganti setara nutrisi"
          >
            <div className="space-y-3">
              {plan.slotSummaries.map((s: any) => (
                <SlotItemsCard key={s.slot} summary={s} />
              ))}
            </div>
          </SectionCard>

          {/* NUTRITION VALIDATION TABLE */}
          <SectionCard
            title="Validasi Kecukupan Gizi"
            description="Target terpenuhi jika 95-105% dari kebutuhan harian (Kemenkes RI)"
          >
            <NutritionValidationTable validation={plan.validation} />
          </SectionCard>

          {/* AI REASONING */}
          {aiReasoning && (
            <SectionCard
              title="Evaluasi AI CareLivia"
              description="Analisis klinis berbasis Pedoman Isi Piringku & diagnosis pasien"
            >
              <div className="rounded-lg border border-violet-500/20 bg-gradient-to-br from-violet-500/5 to-primary/5 p-4">
                <div className="mb-2 flex items-center gap-2">
                  <div className="flex h-7 w-7 items-center justify-center rounded-full bg-violet-500/10">
                    <Brain className="h-3.5 w-3.5 text-violet-600" />
                  </div>
                  <span className="text-sm font-semibold text-violet-700 dark:text-violet-300">
                    CareLivia AI Nutritionist
                  </span>
                </div>
                <p className="whitespace-pre-line text-sm leading-relaxed text-foreground/90">
                  {aiReasoning}
                </p>
              </div>
            </SectionCard>
          )}

          {/* GROUP COVERAGE SUMMARY */}
          <SectionCard
            title="Cakupan Kelompok Makanan Hari Ini"
            description="Jumlah item per kelompok — ideal: 3+ makanan pokok, 3+ lauk, 3+ sayur, 3+ buah"
          >
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              <GroupCoverageCard
                group="STAPLE"
                count={plan.groupCoverage.staple}
                target={3}
              />
              <GroupCoverageCard
                group="PROTEIN"
                count={plan.groupCoverage.protein}
                target={3}
              />
              <GroupCoverageCard
                group="VEGETABLE"
                count={plan.groupCoverage.vegetable}
                target={3}
              />
              <GroupCoverageCard
                group="FRUIT"
                count={plan.groupCoverage.fruit}
                target={3}
              />
            </div>
          </SectionCard>

          {/* CLINICAL GUIDELINES REFERENCE */}
          <SectionCard
            title="Panduan Klinis & Distribusi Energi"
            description="Acuan: Permenkes RI No.41/2014, Pedoman Gizi Seimbang 2023, PERKENI, ESPEN, KDIGO"
          >
            <div className="grid gap-4 lg:grid-cols-2">
              <div>
                <h4 className="mb-2 text-xs font-bold uppercase tracking-wide text-muted-foreground">
                  Distribusi Energi per Waktu Makan
                </h4>
                <div className="space-y-1.5">
                  {(Object.keys(SLOT_LABELS) as MealSlot[]).map((slot) => (
                    <div
                      key={slot}
                      className="flex items-center justify-between rounded-md bg-muted/40 px-3 py-1.5 text-xs"
                    >
                      <span className="font-medium">{SLOT_LABELS[slot]}</span>
                      <Badge variant="outline" className="text-[10px]">
                        {SLOT_DISTRIBUTION_PCT[slot]}
                      </Badge>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="mb-2 text-xs font-bold uppercase tracking-wide text-muted-foreground">
                  Modifikasi Diagnosis
                </h4>
                <div className="rounded-lg border border-border/60 bg-muted/30 p-3 text-xs">
                  <p className="font-semibold text-foreground">
                    {calorieResult.primaryDiagnosis?.label || "Umum"}
                  </p>
                  <p className="mt-1 text-muted-foreground">
                    {calorieResult.primaryDiagnosis?.notes}
                  </p>
                  {calorieResult.warnings.length > 0 && (
                    <ul className="mt-2 list-disc space-y-0.5 pl-4 text-amber-700 dark:text-amber-400">
                      {calorieResult.warnings.map((w: string, i: number) => (
                        <li key={i}>{w}</li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>
            </div>
          </SectionCard>
        </>
      )}

      {/* EDITABLE LATEST PERSISTED MEAL PLAN — add/edit/delete foods */}
      {latestPlan && selectedPatientId && (
        <LatestMealPlanEditor plan={latestPlan} />
      )}

      {/* SAVE TO LIBRARY DIALOG */}
      <Dialog open={showSaveDialog} onOpenChange={setShowSaveDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Simpan ke Library Meal Plan</DialogTitle>
            <DialogDescription>
              Beri nama untuk meal plan ini. Anda dapat memuatnya kembali nanti untuk pasien yang sama.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div>
              <Label htmlFor="save-name">Nama Meal Plan</Label>
              <Input
                id="save-name"
                placeholder="cth: Menu DM 1500 kcal Hari 1"
                value={saveName}
                onChange={(e) => setSaveName(e.target.value)}
                className="mt-1.5"
              />
            </div>
            {plan && (
              <div className="rounded-md bg-muted/40 p-3 text-xs text-muted-foreground">
                <div className="grid grid-cols-2 gap-2">
                  <span>Total: <strong className="text-foreground">{plan.totals.cal} kcal</strong></span>
                  <span>Protein: <strong className="text-foreground">{plan.totals.protein}g</strong></span>
                  <span>Lemak: <strong className="text-foreground">{plan.totals.fat}g</strong></span>
                  <span>Karbo: <strong className="text-foreground">{plan.totals.carb}g</strong></span>
                  <span>Serat: <strong className="text-foreground">{plan.totals.fiber}g</strong></span>
                  <span>Compliance: <strong className="text-foreground">{plan.overallCompliance}%</strong></span>
                </div>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowSaveDialog(false)}>
              Batal
            </Button>
            <Button
              onClick={handleSaveAsTemplate}
              disabled={saveMut.isPending || !saveName.trim()}
            >
              {saveMut.isPending ? "Menyimpan…" : "Simpan"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ---------------------------------------------------------------------
// PlateMealCard — visual plate + compliance for one main meal
// ---------------------------------------------------------------------
function PlateMealCard({ summary }: { summary: any }) {
  const items = summary.items || [];
  const calPct = summary.slotTargetCal > 0 ? Math.round((summary.slotActualCal / summary.slotTargetCal) * 100) : 0;
  const tierColor = COMPLIANCE_TIER_COLOR[summary.compliance.tier as keyof typeof COMPLIANCE_TIER_COLOR];

  return (
    <Card className="overflow-hidden border-border/60">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2 text-base">
              <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-bold ring-1 ${SLOT_COLORS[summary.slot as MealSlot]}`}>
                {SLOT_LABELS[summary.slot as MealSlot]}
              </span>
            </CardTitle>
            <p className="mt-1 text-xs text-muted-foreground">
              Target {summary.slotTargetCal} kcal · Aktual {summary.slotActualCal} kcal ({calPct}%)
            </p>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold" style={{ color: tierColor }}>
              {summary.compliance.score}%
            </div>
            <div className="text-[10px] font-medium" style={{ color: tierColor }}>
              {COMPLIANCE_TIER_ICON[summary.compliance.tier as keyof typeof COMPLIANCE_TIER_ICON]} {COMPLIANCE_TIER_LABEL[summary.compliance.tier as keyof typeof COMPLIANCE_TIER_LABEL]}
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent className="flex flex-col items-center pt-2">
        <IsiPiringkuPlate
          items={items.map((i: any) => ({
            group: i.group as PlateGroup,
            foodName: i.foodName,
            grams: i.amount,
            cal: i.cal,
          }))}
          size={240}
          showLegend={false}
        />
        {summary.compliance.recommendations.length > 0 && (
          <div className="mt-3 w-full rounded-md border border-amber-500/30 bg-amber-500/5 p-2">
            <p className="mb-1 text-[10px] font-bold uppercase tracking-wide text-amber-700 dark:text-amber-400">
              Saran Perbaikan
            </p>
            <ul className="space-y-0.5 text-[11px] text-amber-800 dark:text-amber-300">
              {summary.compliance.recommendations.map((r: string, i: number) => (
                <li key={i}>• {r}</li>
              ))}
            </ul>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ---------------------------------------------------------------------
// SlotItemsCard — detailed item list per slot, with alternatives
// ---------------------------------------------------------------------
function SlotItemsCard({ summary }: { summary: any }) {
  const [open, setOpen] = React.useState(true);
  const items = summary.items || [];
  const isMain = MAIN_SLOTS.includes(summary.slot as MealSlot);

  return (
    <Collapsible open={open} onOpenChange={setOpen}>
      <div className="rounded-lg border border-border/60">
        <CollapsibleTrigger asChild>
          <button className="flex w-full items-center justify-between px-4 py-2.5 text-left hover:bg-muted/30">
            <div className="flex items-center gap-2">
              {open ? (
                <ChevronDown className="h-4 w-4 text-muted-foreground" />
              ) : (
                <ChevronRight className="h-4 w-4 text-muted-foreground" />
              )}
              <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-bold ring-1 ${SLOT_COLORS[summary.slot as MealSlot]}`}>
                {SLOT_LABELS[summary.slot as MealSlot]}
              </span>
              <Badge variant="outline" className="text-[10px]">
                {SLOT_DISTRIBUTION_PCT[summary.slot as MealSlot]}
              </Badge>
              {isMain && (
                <Badge variant="secondary" className="text-[10px] bg-emerald-500/10 text-emerald-700">
                  Isi Piringku
                </Badge>
              )}
            </div>
            <div className="flex items-center gap-3 text-xs">
              <span className="text-muted-foreground">
                {items.length} item · {summary.slotActualCal} kcal
              </span>
              {isMain && (
                <span
                  className="rounded-full px-2 py-0.5 text-[10px] font-bold text-white"
                  style={{ background: COMPLIANCE_TIER_COLOR[summary.compliance.tier as keyof typeof COMPLIANCE_TIER_COLOR] }}
                >
                  {summary.compliance.score}%
                </span>
              )}
            </div>
          </button>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <div className="divide-y divide-border/40 border-t border-border/40">
            {items.length === 0 ? (
              <div className="px-4 py-3 text-xs text-muted-foreground">
                Tidak ada item — slot mungkin tidak dapat dipenuhi karena keterbatasan database makanan.
              </div>
            ) : (
              items.map((item: any, idx: number) => (
                <MealItemRow key={idx} item={item} />
              ))
            )}
          </div>
        </CollapsibleContent>
      </div>
    </Collapsible>
  );
}

// ---------------------------------------------------------------------
// MealItemRow — single item with expandable alternatives
// ---------------------------------------------------------------------
function MealItemRow({ item }: { item: any }) {
  const [showAlts, setShowAlts] = React.useState(false);
  const alts = item.alternatives || [];

  return (
    <div className="px-4 py-2.5">
      <div className="flex items-start justify-between gap-3">
        <div className="flex min-w-0 flex-1 items-start gap-3">
          <div
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg text-base"
            style={{ background: `${item.groupColor}22` }}
          >
            {item.groupIcon}
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <p className="truncate text-sm font-semibold text-foreground">{item.foodName}</p>
              <Badge
                variant="outline"
                className="shrink-0 text-[9px]"
                style={{
                  borderColor: `${item.groupColor}55`,
                  color: item.groupColor,
                  background: `${item.groupColor}11`,
                }}
              >
                {item.groupLabel}
              </Badge>
            </div>
            <div className="mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-[11px] text-muted-foreground">
              <span><strong className="text-foreground">{item.amount}g</strong></span>
              {item.urt && <span>· {item.urt}</span>}
              <span>· <strong className="text-foreground">{item.cal}</strong> kkal</span>
              <span>· P {item.protein}g</span>
              <span>· L {item.fat}g</span>
              <span>· K {item.carb}g</span>
              <span>· Serat {item.fiber}g</span>
              <span>· Na {item.sodium}mg</span>
            </div>
          </div>
        </div>
        {alts.length > 0 && (
          <TooltipProvider delayDuration={300}>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-7 px-2 text-[11px]"
                  onClick={() => setShowAlts(!showAlts)}
                >
                  <RefreshCw className="mr-1 h-3 w-3" />
                  {alts.length} alternatif
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Lihat {alts.length} makanan pengganti setara nutrisi</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        )}
      </div>

      {showAlts && alts.length > 0 && (
        <div className="mt-2 ml-12 space-y-1.5 rounded-md border border-dashed border-border/60 bg-muted/20 p-2">
          <p className="text-[10px] font-bold uppercase tracking-wide text-muted-foreground">
            Alternatif Pengganti ({alts.length})
          </p>
          {alts.map((alt: any, i: number) => (
            <div
              key={i}
              className="flex items-start justify-between gap-2 rounded bg-background/60 p-1.5 text-[11px]"
            >
              <div className="min-w-0 flex-1">
                <p className="font-medium text-foreground">
                  {alt.foodName} <span className="text-muted-foreground">· {alt.amount}g</span>
                </p>
                <p className="text-[10px] text-muted-foreground">{alt.reason}</p>
              </div>
              <div className="shrink-0 text-right text-[10px] text-muted-foreground">
                <div><strong className="text-foreground">{alt.cal}</strong> kkal</div>
                <div>P {alt.protein}g</div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------
// NutritionValidationTable — target vs actual with OK/LOW/HIGH
// ---------------------------------------------------------------------
function NutritionValidationTable({ validation }: { validation: any[] }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-border/60 text-left text-xs text-muted-foreground">
            <th className="py-2 pr-3 font-medium">Nutrien</th>
            <th className="py-2 pr-3 font-medium">Target</th>
            <th className="py-2 pr-3 font-medium">Aktual</th>
            <th className="py-2 pr-3 font-medium">Pencapaian</th>
            <th className="py-2 font-medium">Status</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-border/40">
          {validation.map((row: any, i: number) => {
            const statusColor =
              row.status === "OK"
                ? "bg-emerald-500/10 text-emerald-700 ring-emerald-500/20"
                : row.status === "LOW"
                ? "bg-amber-500/10 text-amber-700 ring-amber-500/20"
                : "bg-rose-500/10 text-rose-700 ring-rose-500/20";
            const statusLabel =
              row.status === "OK" ? "✓ Tercapai" : row.status === "LOW" ? "↓ Kurang" : "↑ Berlebih";
            const pctColor =
              row.pct >= 95 && row.pct <= 105
                ? "text-emerald-600"
                : row.pct < 95
                ? "text-amber-600"
                : "text-rose-600";
            return (
              <tr key={i}>
                <td className="py-2 pr-3 font-medium text-foreground">{row.nutrient}</td>
                <td className="py-2 pr-3 text-muted-foreground">
                  {row.target} <span className="text-[10px]">{row.unit}</span>
                </td>
                <td className="py-2 pr-3 text-foreground">
                  {row.actual} <span className="text-[10px]">{row.unit}</span>
                </td>
                <td className={`py-2 pr-3 font-semibold ${pctColor}`}>{row.pct}%</td>
                <td className="py-2">
                  <Badge variant="outline" className={`text-[10px] ring-1 ${statusColor}`}>
                    {statusLabel}
                  </Badge>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
      <p className="mt-2 text-[11px] text-muted-foreground">
        <Info className="mr-1 inline h-3 w-3" />
        Standar kepatuhan: 95-105% dianggap tercapai. Natrium adalah batas atas (&gt;100% = berlebih).
      </p>
    </div>
  );
}

// ---------------------------------------------------------------------
// GroupCoverageCard — count of items per plate group
// ---------------------------------------------------------------------
function GroupCoverageCard({
  group,
  count,
  target,
}: {
  group: PlateGroup;
  count: number;
  target: number;
}) {
  const pct = Math.min(100, Math.round((count / target) * 100));
  const isComplete = count >= target;
  return (
    <div className="rounded-lg border border-border/60 bg-gradient-to-br from-background to-muted/30 p-4">
      <div className="mb-2 flex items-center justify-between">
        <span className="text-2xl">{PLATE_GROUP_ICON[group]}</span>
        {isComplete ? (
          <CheckCircle2 className="h-4 w-4 text-emerald-500" />
        ) : (
          <AlertCircle className="h-4 w-4 text-amber-500" />
        )}
      </div>
      <p className="text-xs font-medium text-muted-foreground">
        {PLATE_GROUP_LABEL[group]}
      </p>
      <p className="mt-1 text-2xl font-bold text-foreground">
        {count}
        <span className="ml-1 text-xs font-normal text-muted-foreground">
          / {target}+
        </span>
      </p>
      <Progress value={pct} className="mt-2 h-1.5" />
      <p className="mt-1.5 text-[10px] text-muted-foreground">
        {isComplete ? "Cakupan terpenuhi" : "Tambah variasi"}
      </p>
    </div>
  );
}

// ---------------------------------------------------------------------
// LatestMealPlanEditor — Editable view for the latest persisted meal plan.
// Operates on Supabase data via useMealPlans() — NOT on preview data.
// Add/Edit/Delete foods with realtime recalculation + debounce.
// ---------------------------------------------------------------------
function LatestMealPlanEditor({ plan }: { plan: any }) {
  const items = Array.isArray(plan.items) ? plan.items : [];

  // Group items by slot
  const itemsBySlot = React.useMemo(() => {
    const map: Record<string, any[]> = {};
    for (const item of items) {
      const slot = String(item.slot || "");
      if (!map[slot]) map[slot] = [];
      map[slot].push(item);
    }
    return map;
  }, [items]);

  // Recompute totals (realtime, after edits)
  const totals = React.useMemo(() => {
    const t = { cal: 0, protein: 0, fat: 0, carb: 0, fiber: 0, sodium: 0 };
    for (const it of items) {
      t.cal += Number(it.cal) || 0;
      t.protein += Number(it.protein) || 0;
      t.fat += Number(it.fat) || 0;
      t.carb += Number(it.carb) || 0;
      t.fiber += Number(it.fiber) || 0;
      t.sodium += Number(it.sodium) || 0;
    }
    return {
      cal: Math.round(t.cal),
      protein: Math.round(t.protein * 10) / 10,
      fat: Math.round(t.fat * 10) / 10,
      carb: Math.round(t.carb * 10) / 10,
      fiber: Math.round(t.fiber * 10) / 10,
      sodium: Math.round(t.sodium),
    };
  }, [items]);

  const targetCal = Number(plan.targetCal) || 0;
  const pctOfTarget = targetCal > 0 ? Math.round((totals.cal / targetCal) * 100) : 0;

  const planDate = plan.date ? new Date(plan.date) : null;
  const dateLabel = planDate
    ? planDate.toLocaleDateString("id-ID", { day: "numeric", month: "short", year: "numeric" })
    : "—";

  return (
    <SectionCard
      title="Edit Meal Plan Terkini (Database)"
      description="Edit makanan pada meal plan tersimpan terakhir. Perubahan langsung disinkronkan ke database Supabase."
    >
      {/* Plan summary */}
      <div className="mb-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-lg border border-border/60 bg-muted/30 p-3">
          <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Tanggal Plan</p>
          <p className="mt-1 text-sm font-semibold text-foreground">{dateLabel}</p>
        </div>
        <div className="rounded-lg border border-border/60 bg-muted/30 p-3">
          <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Total Energi</p>
          <p className="mt-1 text-sm font-semibold text-foreground">
            {totals.cal} kcal
            {targetCal > 0 && (
              <span className="ml-1 text-xs text-muted-foreground">/ {targetCal} ({pctOfTarget}%)</span>
            )}
          </p>
        </div>
        <div className="rounded-lg border border-border/60 bg-muted/30 p-3">
          <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Makro (P/L/K)</p>
          <p className="mt-1 text-sm font-semibold text-foreground">
            {totals.protein}g / {totals.fat}g / {totals.carb}g
          </p>
        </div>
        <div className="rounded-lg border border-border/60 bg-muted/30 p-3">
          <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Serat & Natrium</p>
          <p className="mt-1 text-sm font-semibold text-foreground">
            {totals.fiber}g · {totals.sodium}mg
          </p>
        </div>
      </div>

      {items.length === 0 ? (
        <div className="rounded-lg border border-dashed border-border/60 p-6 text-center">
          <p className="text-sm text-muted-foreground">
            Meal plan ini belum memiliki item. Tambahkan makanan pada salah satu slot di bawah.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {(Object.keys(SLOT_LABELS) as MealSlot[]).map((slot) => (
            <EditableSlotItemsCard
              key={slot}
              slot={slot}
              items={itemsBySlot[slot] || []}
              mealPlanId={plan.id}
            />
          ))}
        </div>
      )}
    </SectionCard>
  );
}

// ---------------------------------------------------------------------
// EditableSlotItemsCard — One slot's items + "+ Tambah Makanan" button
// ---------------------------------------------------------------------
function EditableSlotItemsCard({
  slot,
  items,
  mealPlanId,
}: {
  slot: MealSlot;
  items: any[];
  mealPlanId: string;
}) {
  const [open, setOpen] = React.useState(true);
  const [showAddFood, setShowAddFood] = React.useState(false);
  const addMut = useAddMealItem(mealPlanId);

  const slotCal = items.reduce((sum, it) => sum + (Number(it.cal) || 0), 0);
  const isMain = MAIN_SLOTS.includes(slot);

  const handleAddFood = async (result: FoodPickerResult) => {
    try {
      await addMut.mutateAsync({
        slot,
        foodId: result.foodId,
        amount: result.amount,
      });
      toast.success(`${result.foodName} ditambahkan ke ${SLOT_LABELS[slot]}`);
    } catch (e: any) {
      toast.error(e.message || "Gagal menambahkan makanan");
    }
  };

  return (
    <Collapsible open={open} onOpenChange={setOpen}>
      <div className="rounded-lg border border-border/60">
        <CollapsibleTrigger asChild>
          <button className="flex w-full items-center justify-between px-4 py-2.5 text-left hover:bg-muted/30">
            <div className="flex items-center gap-2">
              {open ? (
                <ChevronDown className="h-4 w-4 text-muted-foreground" />
              ) : (
                <ChevronRight className="h-4 w-4 text-muted-foreground" />
              )}
              <span
                className={`inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-bold ring-1 ${SLOT_COLORS[slot]}`}
              >
                {SLOT_LABELS[slot]}
              </span>
              <Badge variant="outline" className="text-[10px]">
                {SLOT_DISTRIBUTION_PCT[slot]}
              </Badge>
              {isMain && (
                <Badge variant="secondary" className="bg-emerald-500/10 text-[10px] text-emerald-700">
                  Isi Piringku
                </Badge>
              )}
            </div>
            <div className="flex items-center gap-3 text-xs">
              <span className="text-muted-foreground">
                {items.length} item · {Math.round(slotCal)} kcal
              </span>
            </div>
          </button>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <div className="divide-y divide-border/40 border-t border-border/40">
            {items.length === 0 ? (
              <div className="px-4 py-3 text-xs text-muted-foreground">
                Slot kosong — tambahkan makanan untuk mengisi slot ini.
              </div>
            ) : (
              items.map((item) => (
                <EditableMealItemRow
                  key={item.id}
                  item={item}
                  mealPlanId={mealPlanId}
                />
              ))
            )}
          </div>

          {/* Add food button */}
          <div className="border-t border-border/40 p-2">
            <Button
              variant="ghost"
              size="sm"
              className="w-full justify-center border border-dashed border-border/60 text-xs"
              onClick={() => setShowAddFood(true)}
              disabled={addMut.isPending}
            >
              <Plus className="mr-1.5 h-3.5 w-3.5" />
              {addMut.isPending ? "Menambahkan..." : "Tambah Makanan"}
            </Button>
          </div>
        </CollapsibleContent>
      </div>

      <FoodPickerDialog
        open={showAddFood}
        onOpenChange={setShowAddFood}
        onSelect={handleAddFood}
        title={`Tambah Makanan — ${SLOT_LABELS[slot]}`}
        excludeFoodIds={items.map((it) => it.foodId)}
      />
    </Collapsible>
  );
}

// ---------------------------------------------------------------------
// EditableMealItemRow — Inline-editable gram + edit food + delete food
// Realtime nutrition preview while typing (proportional recompute).
// Debounced (300ms) update via useUpdateMealItem.
// ---------------------------------------------------------------------
function EditableMealItemRow({
  item,
  mealPlanId,
}: {
  item: any;
  mealPlanId: string;
}) {
  const updateMut = useUpdateMealItem(mealPlanId);
  const deleteMut = useDeleteMealItem(mealPlanId);

  const [grams, setGrams] = React.useState<number>(Number(item.amount) || 0);
  const [isEditingFood, setIsEditingFood] = React.useState(false);
  const [confirmDelete, setConfirmDelete] = React.useState(false);
  const debounceRef = React.useRef<ReturnType<typeof setTimeout> | null>(null);
  const lastSavedRef = React.useRef<number>(Number(item.amount) || 0);

  // Sync local grams when the server refetches a new amount for this item.
  // Only sync if the server value differs from what we last saved — this
  // prevents overwriting the user's in-progress typing with stale cache data
  // when React Query refetches mid-typing.
  React.useEffect(() => {
    const serverAmount = Number(item.amount) || 0;
    if (serverAmount !== lastSavedRef.current) {
      setGrams(serverAmount);
      lastSavedRef.current = serverAmount;
    }
  }, [item.amount, item.id]);

  // Realtime proportional preview while typing (uses computeFoodNutrition)
  const baseAmount = Number(item.amount) || 0;
  const baseCal = Number(item.cal) || 0;
  const baseProtein = Number(item.protein) || 0;
  const baseFat = Number(item.fat) || 0;
  const baseCarb = Number(item.carb) || 0;
  const baseFiber = Number(item.fiber) || 0;
  const baseSodium = Number(item.sodium) || 0;

  // Derive per-100g nutrient values from the existing snapshot so we can use
  // the canonical computeFoodNutrition() helper for realtime preview.
  const per100 = baseAmount > 0
    ? {
        energy: (baseCal / baseAmount) * 100,
        protein: (baseProtein / baseAmount) * 100,
        fat: (baseFat / baseAmount) * 100,
        carb: (baseCarb / baseAmount) * 100,
        fiber: (baseFiber / baseAmount) * 100,
        sodium: (baseSodium / baseAmount) * 100,
        potassium: 0,
      }
    : { energy: 0, protein: 0, fat: 0, carb: 0, fiber: 0, sodium: 0, potassium: 0 };

  const preview = computeFoodNutrition(per100, grams || 0);
  const previewCal = Math.round(preview.cal * 10) / 10;
  const previewProtein = Math.round(preview.protein * 10) / 10;
  const previewFat = Math.round(preview.fat * 10) / 10;
  const previewCarb = Math.round(preview.carb * 10) / 10;
  const previewFiber = Math.round(preview.fiber * 10) / 10;
  const previewSodium = Math.round(preview.sodium * 10) / 10;

  // Whether the displayed preview differs from the saved baseline (i.e., user is typing)
  const isDirty = grams !== baseAmount;

  const handleGramsChange = (value: string) => {
    const num = Number(value);
    if (Number.isNaN(num) || num <= 0) {
      // Allow empty input — just don't fire update
      setGrams(num > 0 ? num : 0);
      return;
    }
    setGrams(num);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(async () => {
      try {
        await updateMut.mutateAsync({ itemId: item.id, amount: num });
        lastSavedRef.current = num;
      } catch (e: any) {
        toast.error(e.message || "Gagal memperbarui gram");
        // Revert on error
        setGrams(baseAmount);
        lastSavedRef.current = baseAmount;
      }
    }, 300);
  };

  // Cleanup debounce on unmount
  React.useEffect(() => {
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, []);

  const handleEditFood = async (result: FoodPickerResult) => {
    try {
      await updateMut.mutateAsync({
        itemId: item.id,
        foodId: result.foodId,
        amount: result.amount,
      });
      lastSavedRef.current = result.amount;
      toast.success(`Makanan diganti ke "${result.foodName}" (${result.amount}g)`);
    } catch (e: any) {
      toast.error(e.message || "Gagal mengganti makanan");
    }
  };

  const handleDelete = async () => {
    try {
      await deleteMut.mutateAsync(item.id);
      toast.success(`"${item.food?.name || "Item"}" dihapus dari meal plan`);
      setConfirmDelete(false);
    } catch (e: any) {
      toast.error(e.message || "Gagal menghapus item");
    }
  };

  const foodName = item.food?.name || "Makanan tidak diketahui";

  return (
    <div className="px-4 py-2.5">
      <div className="flex items-start justify-between gap-3">
        <div className="flex min-w-0 flex-1 items-start gap-3">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-base">
            <Apple className="h-4 w-4 text-primary" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-semibold text-foreground">{foodName}</p>

            {/* Inline gram editor + realtime nutrition preview */}
            <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-muted-foreground">
              <label className="flex items-center gap-1">
                <Input
                  type="number"
                  value={grams}
                  onChange={(e) => handleGramsChange(e.target.value)}
                  className="h-6 w-16 px-1.5 py-0 text-xs"
                  min={1}
                  max={2000}
                  disabled={updateMut.isPending}
                />
                <span>g</span>
              </label>
              <span>
                · <strong className={isDirty ? "text-primary" : "text-foreground"}>{previewCal}</strong> kkal
              </span>
              <span>· P {previewProtein}g</span>
              <span>· L {previewFat}g</span>
              <span>· K {previewCarb}g</span>
              <span>· Serat {previewFiber}g</span>
              <span>· Na {previewSodium}mg</span>
              {isDirty && (
                <Badge variant="outline" className="bg-amber-500/10 text-[9px] text-amber-700">
                  {updateMut.isPending ? "menyimpan…" : "preview"}
                </Badge>
              )}
            </div>
          </div>
        </div>

        {/* Edit Food + Delete Food buttons */}
        <div className="flex shrink-0 items-center gap-1">
          <TooltipProvider delayDuration={300}>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-7 w-7"
                  onClick={() => setIsEditingFood(true)}
                  disabled={updateMut.isPending}
                >
                  <Pencil className="h-3.5 w-3.5" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Ganti makanan</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>

          {confirmDelete ? (
            <div className="flex items-center gap-1 rounded-md border border-rose-500/30 bg-rose-500/5 px-1">
              <span className="px-1 text-[10px] text-rose-700 dark:text-rose-400">Hapus?</span>
              <Button
                variant="ghost"
                size="sm"
                className="h-6 px-2 text-[10px] text-rose-700 hover:bg-rose-500/10 dark:text-rose-400"
                onClick={handleDelete}
                disabled={deleteMut.isPending}
              >
                {deleteMut.isPending ? "…" : "Ya"}
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="h-6 px-2 text-[10px]"
                onClick={() => setConfirmDelete(false)}
                disabled={deleteMut.isPending}
              >
                Tidak
              </Button>
            </div>
          ) : (
            <TooltipProvider delayDuration={300}>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7 text-rose-600 hover:bg-rose-50 hover:text-rose-700 dark:hover:bg-rose-950"
                    onClick={() => setConfirmDelete(true)}
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Hapus makanan</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          )}
        </div>
      </div>

      {/* Edit Food picker dialog */}
      <FoodPickerDialog
        open={isEditingFood}
        onOpenChange={setIsEditingFood}
        onSelect={handleEditFood}
        title={`Ganti Makanan — ${foodName}`}
        defaultAmount={Number(item.amount) || 100}
      />
    </div>
  );
}
