"use client";

import * as React from "react";
import {
  FileText,
  User,
  Printer,
  HeartPulse,
  Activity,
  Target,
  Beef,
  Droplet,
  Wheat,
  Leaf,
  Utensils,
  Dumbbell,
  Brain,
  Stethoscope,
  ClipboardCheck,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import {
  PageHeader,
  EmptyState,
  LoadingState,
} from "@/components/carelivia/ui-helpers";
import {
  usePatients,
  usePatient,
} from "@/hooks/use-carelivia";
import { useCareLiviaStore } from "@/store/carelivia";
import {
  DIAGNOSIS_ADJUSTMENTS,
  classifyBMI,
  idealBodyWeight,
} from "@/lib/clinical/constants";
import type {
  DiagnosisType,
  Gender,
  MealSlot,
  ExerciseType,
  ExerciseIntensity,
} from "@prisma/client";

const SLOT_LABELS: Record<MealSlot, string> = {
  BREAKFAST: "Sarapan",
  MORNING_SNACK: "Snack Pagi",
  LUNCH: "Makan Siang",
  AFTERNOON_SNACK: "Snack Sore",
  DINNER: "Makan Malam",
  EVENING_SNACK: "Snack Malam",
};

const SLOT_ORDER: MealSlot[] = [
  "BREAKFAST",
  "MORNING_SNACK",
  "LUNCH",
  "AFTERNOON_SNACK",
  "DINNER",
  "EVENING_SNACK",
];

const GENDER_LABELS: Record<Gender, string> = {
  MALE: "Laki-laki",
  FEMALE: "Perempuan",
};

const RELIGION_LABELS: Record<string, string> = {
  ISLAM: "Islam",
  KRISTEN: "Kristen",
  KATOLIK: "Katolik",
  HINDU: "Hindu",
  BUDDHA: "Buddha",
  KONGHUCU: "Konghucu",
  OTHER: "Lainnya",
};

const EXERCISE_TYPE_LABELS: Record<ExerciseType, string> = {
  AEROBIC: "Aerobik",
  RESISTANCE: "Resistance",
  FLEXIBILITY: "Fleksibilitas",
  BALANCE: "Keseimbangan",
  FUNCTIONAL: "Fungsional",
};

const INTENSITY_LABELS: Record<ExerciseIntensity, string> = {
  LOW: "Ringan",
  MODERATE: "Sedang",
  HIGH: "Berat",
};

function calcAge(birthDate: string | Date): number {
  const d = new Date(birthDate);
  const diff = Date.now() - d.getTime();
  return Math.floor(diff / (365.25 * 86400000));
}

function fmtDate(d: string | Date): string {
  return new Date(d).toLocaleDateString("id-ID", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

export function ReportView() {
  const { data: patients } = usePatients();
  const { activePatientId, setActivePatient } = useCareLiviaStore();
  const [selectedPatientId, setSelectedPatientId] = React.useState<string>(
    activePatientId || "",
  );

  React.useEffect(() => {
    if (activePatientId && !selectedPatientId) {
      setSelectedPatientId(activePatientId);
    }
  }, [activePatientId, selectedPatientId]);

  const { data: patient, isLoading } = usePatient(selectedPatientId || null);

  const handleSelectPatient = (id: string) => {
    setSelectedPatientId(id);
    setActivePatient(id);
  };

  const handlePrint = () => {
    if (typeof window !== "undefined") {
      toast.info(
        "Membuka dialog cetak — pilih 'Simpan sebagai PDF' sebagai printer untuk mengunduh PDF",
        { duration: 5000 },
      );
      setTimeout(() => window.print(), 500);
    }
  };

  return (
    <div>
      <PageHeader
        title="Laporan Nutrisi Klinis"
        subtitle="Laporan profesional siap cetak / PDF untuk arsip rekam medis"
        icon={FileText}
        actions={
          selectedPatientId && patient ? (
            <Button onClick={handlePrint} size="sm" className="no-print">
              <Printer className="mr-2 h-4 w-4" /> Cetak / Simpan PDF
            </Button>
          ) : undefined
        }
      />

      {/* Patient selector — no-print */}
      <div className="no-print mb-4 flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="flex items-center gap-2">
          <User className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm font-medium">Pasien:</span>
        </div>
        <Select value={selectedPatientId} onValueChange={handleSelectPatient}>
          <SelectTrigger className="w-full sm:w-72">
            <SelectValue placeholder="Pilih pasien..." />
          </SelectTrigger>
          <SelectContent>
            {(patients || []).map((p) => (
              <SelectItem key={p.id} value={p.id}>
                {p.name} ({p.mrn})
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {!selectedPatientId ? (
        <EmptyState
          title="Pilih pasien untuk menampilkan laporan"
          description="Laporan nutrisi klinis profesional akan dibuat dari data pasien terkini."
          icon={FileText}
        />
      ) : isLoading ? (
        <LoadingState count={3} />
      ) : !patient ? (
        <EmptyState
          title="Data pasien tidak ditemukan"
          icon={FileText}
        />
      ) : (
        <ClinicalReport patient={patient} />
      )}
    </div>
  );
}

function ClinicalReport({ patient }: { patient: any }) {
  const age = calcAge(patient.birthDate);
  const height = patient.height ?? null;
  const weight = patient.weight ?? null;
  const bmi =
    height && weight ? weight / Math.pow(height / 100, 2) : null;
  const bmiInfo = bmi != null ? classifyBMI(bmi) : null;
  const bbi =
    height != null ? idealBodyWeight(height, patient.gender) : null;

  const latestAnthro = patient.anthropometry?.[0];
  const latestAssessment = patient.assessments?.[0];
  const latestMealPlan = patient.mealPlans?.[0];
  const latestExercisePlan = patient.exercisePlans?.[0];
  const activeDiagnoses = (patient.diagnoses || [])
    .map((raw: any, i: number) => (typeof raw === "string" ? { id: `${raw}-${i}`, type: raw, active: true } : raw))
    .filter((d: any) => d.active !== false && d.type);

  // Meal items grouped by slot
  const itemsBySlot: Record<string, any[]> = {};
  (latestMealPlan?.items || []).forEach((item: any) => {
    if (!itemsBySlot[item.slot]) itemsBySlot[item.slot] = [];
    itemsBySlot[item.slot].push(item);
  });

  return (
    <div className="cl-report mx-auto max-w-[820px] rounded-lg border border-border bg-white shadow-sm print:border-0 print:shadow-none dark:bg-card">
      {/* === Header band === */}
      <div className="cl-gradient-primary relative overflow-hidden px-6 py-6 text-primary-foreground print:py-5 sm:px-8">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary-foreground/15 backdrop-blur">
              <HeartPulse className="h-6 w-6" />
            </div>
            <div>
              <p className="text-lg font-bold leading-tight">CareLivia CNMS</p>
              <p className="text-[11px] uppercase tracking-widest text-primary-foreground/80">
                Clinical Nutrition Management System
              </p>
            </div>
          </div>
          <div className="text-right text-xs text-primary-foreground/90">
            <p className="font-semibold uppercase tracking-wide">
              LAPORAN NUTRISI KLINIS
            </p>
            <p className="mt-0.5">
              {new Date().toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" })}
            </p>
            <p>No. Dok: CL-NUT/{new Date().getFullYear()}/{(patient.mrn || "").replace(/[^0-9A-Z]/g, "").slice(-6) || "—"}</p>
          </div>
        </div>
      </div>

      <div className="space-y-5 px-6 py-6 print:px-8 sm:px-8">
        {/* === 1. Patient identification summary === */}
        <div className="rounded-md border border-border/60 bg-muted/20 px-4 py-3">
          <div className="flex flex-wrap items-baseline justify-between gap-2">
            <div>
              <p className="text-xs uppercase tracking-wide text-muted-foreground">Nama Pasien</p>
              <p className="text-lg font-bold text-foreground">{patient.name}</p>
            </div>
            <div className="text-right">
              <p className="text-xs uppercase tracking-wide text-muted-foreground">No. Rekam Medis</p>
              <p className="font-mono font-semibold text-foreground">{patient.mrn}</p>
            </div>
          </div>
        </div>

        {/* === 2. Profil Pasien === */}
        <ReportSection
          title="Profil Pasien"
          icon={User}
        >
          <div className="grid grid-cols-2 gap-x-6 gap-y-2.5 sm:grid-cols-3">
            <Field label="Nama Lengkap" value={patient.name} />
            <Field label="No. Rekam Medis" value={patient.mrn} mono />
            <Field label="Jenis Kelamin" value={GENDER_LABELS[patient.gender] || patient.gender} />
            <Field label="Usia" value={`${age} tahun`} />
            <Field label="Tanggal Lahir" value={fmtDate(patient.birthDate)} />
            <Field label="No. Telepon" value={patient.phone || "—"} />
            <Field label="Agama" value={RELIGION_LABELS[patient.religion] || patient.religion || "—"} />
            <Field label="Gol. Darah" value={patient.bloodType || "—"} />
            <Field label="Alergi" value={patient.allergy || "Tidak ada"} />
            <div className="col-span-2 sm:col-span-3">
              <Field label="Alamat" value={patient.address || "—"} />
            </div>
          </div>
        </ReportSection>

        {/* === 3. Antropometri === */}
        <ReportSection title="Antropometri" icon={Activity}>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Metric label="Tinggi Badan" value={height ? `${height} cm` : "—"} />
            <Metric label="Berat Badan" value={weight ? `${weight} kg` : "—"} />
            <Metric
              label="BMI"
              value={bmi ? (Math.round(bmi * 10) / 10).toString() : "—"}
              hint={bmiInfo ? bmiInfo.label : undefined}
            />
            <Metric
              label="BBI (Ideal)"
              value={bbi ? `${Math.round(bbi * 10) / 10} kg` : "—"}
              hint="Broca-Indonesia"
            />
          </div>
          {bmiInfo && (
            <div className="mt-3 flex flex-wrap items-center gap-2 text-xs">
              <span className="text-muted-foreground">Kategori BMI:</span>
              <Badge
                variant="outline"
                className="text-[10px]"
                style={{
                  borderColor: bmiInfo.color,
                  color: bmiInfo.color,
                }}
              >
                {bmiInfo.label} ({bmiInfo.category})
              </Badge>
              {latestAnthro && (
                <span className="text-muted-foreground">
                  · Terakhir diperbarui {fmtDate(latestAnthro.recordedAt)}
                </span>
              )}
            </div>
          )}
        </ReportSection>

        {/* === 4. Diagnosis === */}
        <ReportSection title="Diagnosis Aktif" icon={Stethoscope}>
          {activeDiagnoses.length === 0 ? (
            <p className="text-sm text-muted-foreground">Tidak ada diagnosis aktif tercatat.</p>
          ) : (
            <div className="space-y-2">
              {activeDiagnoses.map((d: any) => {
                const adj = DIAGNOSIS_ADJUSTMENTS[d.type as DiagnosisType];
                return (
                  <div
                    key={d.id}
                    className="flex flex-wrap items-baseline justify-between gap-2 rounded-md border border-border/60 px-3 py-2"
                  >
                    <div>
                      <p className="text-sm font-semibold text-foreground">
                        {adj?.label || d.type}
                      </p>
                      {adj?.notes && (
                        <p className="text-[11px] text-muted-foreground">{adj.notes}</p>
                      )}
                    </div>
                    <div className="flex gap-1">
                      {d.icd && (
                        <Badge variant="outline" className="text-[10px]">
                          ICD {d.icd}
                        </Badge>
                      )}
                      {adj?.icd && !d.icd && (
                        <Badge variant="outline" className="text-[10px]">
                          ICD {adj.icd}
                        </Badge>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </ReportSection>

        {/* === 4b. Asesmen Gizi & Fungsional === */}
        {latestAssessment && (
          <ReportSection title="Asesmen Gizi & Fungsional" icon={ClipboardCheck}>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-4">
              {latestAssessment.must && (
                <AssessmentScoreCard
                  label="MUST"
                  score={latestAssessment.mustScore != null ? String(latestAssessment.mustScore) : "—"}
                  category={latestAssessment.must === "LOW" ? "Risiko Rendah" : latestAssessment.must === "MEDIUM" ? "Risiko Sedang" : "Risiko Tinggi"}
                  color={latestAssessment.must === "LOW" ? "emerald" : latestAssessment.must === "MEDIUM" ? "amber" : "rose"}
                />
              )}
              {latestAssessment.sga && (
                <AssessmentScoreCard
                  label="SGA"
                  score={latestAssessment.sga}
                  category={latestAssessment.sga === "A" ? "Gizi Baik" : latestAssessment.sga === "B" ? "Sedang" : "Berat"}
                  color={latestAssessment.sga === "A" ? "emerald" : latestAssessment.sga === "B" ? "amber" : "rose"}
                />
              )}
              {latestAssessment.nrs2002 && (
                <AssessmentScoreCard
                  label="NRS-2002"
                  score={latestAssessment.nrsScore != null ? String(latestAssessment.nrsScore) : "—"}
                  category={latestAssessment.nrs2002 === "AT_RISK" ? "Berisiko" : "Tidak Berisiko"}
                  color={latestAssessment.nrs2002 === "AT_RISK" ? "rose" : "emerald"}
                />
              )}
              {latestAssessment.mna && (
                <AssessmentScoreCard
                  label="MNA"
                  score={latestAssessment.mnaScore != null ? String(latestAssessment.mnaScore) : "—"}
                  category={latestAssessment.mna === "NORMAL" ? "Normal" : latestAssessment.mna === "AT_RISK" ? "Berisiko" : "Malnutrisi"}
                  color={latestAssessment.mna === "NORMAL" ? "emerald" : latestAssessment.mna === "AT_RISK" ? "amber" : "rose"}
                />
              )}
              {latestAssessment.ecog != null && (
                <AssessmentScoreCard
                  label="ECOG"
                  score={latestAssessment.ecog}
                  category={latestAssessment.ecog === "0" ? "Aktif" : latestAssessment.ecog === "1" ? "Ringan" : latestAssessment.ecog === "2" ? "Bisa Jalan" : latestAssessment.ecog === "3" ? "Bedrest >50%" : "Bedrest Total"}
                  color={Number(latestAssessment.ecog) <= 1 ? "emerald" : Number(latestAssessment.ecog) <= 2 ? "amber" : "rose"}
                />
              )}
              {latestAssessment.barthel != null && (
                <AssessmentScoreCard
                  label="Barthel"
                  score={String(latestAssessment.barthel)}
                  category={latestAssessment.barthel >= 95 ? "Mandiri" : latestAssessment.barthel >= 60 ? "Bantuan Minimal" : latestAssessment.barthel >= 40 ? "Bantuan Sedang" : "Ketergantungan"}
                  color={latestAssessment.barthel >= 60 ? "emerald" : latestAssessment.barthel >= 40 ? "amber" : "rose"}
                />
              )}
              {latestAssessment.frailty && (
                <AssessmentScoreCard
                  label="FRAIL"
                  score={latestAssessment.frailtyScore != null ? String(latestAssessment.frailtyScore) : "—"}
                  category={latestAssessment.frailty === "ROBUST" ? "Robust" : latestAssessment.frailty === "PREFRAIL" ? "Prefrail" : "Frail"}
                  color={latestAssessment.frailty === "ROBUST" ? "emerald" : latestAssessment.frailty === "PREFRAIL" ? "amber" : "rose"}
                />
              )}
              {latestAssessment.fallRisk && (
                <AssessmentScoreCard
                  label="Fall Risk"
                  score={latestAssessment.fallRisk}
                  category={latestAssessment.fallRisk === "LOW" ? "Rendah" : latestAssessment.fallRisk === "MODERATE" ? "Sedang" : "Tinggi"}
                  color={latestAssessment.fallRisk === "LOW" ? "emerald" : latestAssessment.fallRisk === "MODERATE" ? "amber" : "rose"}
                />
              )}
              {latestAssessment.handGrip != null && (
                <AssessmentScoreCard
                  label="Hand Grip"
                  score={`${latestAssessment.handGrip} kg`}
                  category={latestAssessment.handGrip < 27 ? "Risiko Sarcopenia" : "Normal"}
                  color={latestAssessment.handGrip < 27 ? "amber" : "emerald"}
                />
              )}
              {latestAssessment.calfCirc != null && (
                <AssessmentScoreCard
                  label="Calf Circ."
                  score={`${latestAssessment.calfCirc} cm`}
                  category={latestAssessment.calfCirc < 31 ? "Risiko Sarcopenia" : "Normal"}
                  color={latestAssessment.calfCirc < 31 ? "amber" : "emerald"}
                />
              )}
            </div>
            {(latestAssessment.activity || latestAssessment.stress) && (
              <div className="mt-3 flex flex-wrap gap-2 text-[11px]">
                {latestAssessment.activity && (
                  <span className="rounded-md border border-border bg-muted/30 px-2 py-1">
                    <strong>Aktivitas:</strong> {latestAssessment.activity.replace("_", " ")}
                  </span>
                )}
                {latestAssessment.stress && latestAssessment.stress !== "NONE" && (
                  <span className="rounded-md border border-border bg-muted/30 px-2 py-1">
                    <strong>Stress:</strong> {latestAssessment.stress}
                  </span>
                )}
                {latestAssessment.notes && (
                  <span className="rounded-md border border-border bg-muted/30 px-2 py-1">
                    <strong>Catatan:</strong> {latestAssessment.notes}
                  </span>
                )}
              </div>
            )}
            <p className="mt-2 text-[10px] text-muted-foreground">
              Tanggal asesmen: {new Date(latestAssessment.recordedAt).toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" })}
            </p>
          </ReportSection>
        )}

        {/* === 5. Target Gizi === */}
        {latestMealPlan ? (
          <ReportSection title="Target Gizi" icon={Target}>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
              <NutrientCard label="Kalori" value={Math.round(latestMealPlan.targetCal)} unit="kcal" icon={Activity} />
              <NutrientCard label="Protein" value={Math.round(latestMealPlan.targetProtein)} unit="g" icon={Beef} />
              <NutrientCard label="Lemak" value={Math.round(latestMealPlan.targetFat)} unit="g" icon={Droplet} />
              <NutrientCard label="Karbohidrat" value={Math.round(latestMealPlan.targetCarb)} unit="g" icon={Wheat} />
              <NutrientCard label="Serat" value={Math.round(latestMealPlan.targetFiber)} unit="g" icon={Leaf} />
              <NutrientCard label="Natrium" value={Math.round(latestMealPlan.targetSodium)} unit="mg" icon={Leaf} />
            </div>
            <p className="mt-2 text-[11px] text-muted-foreground">
              Meal plan: {fmtDate(latestMealPlan.date)} · Status {latestMealPlan.status}
            </p>
          </ReportSection>
        ) : (
          <ReportSection title="Target Gizi" icon={Target}>
            <p className="text-sm text-muted-foreground">Belum ada meal plan tersusun untuk pasien ini.</p>
          </ReportSection>
        )}

        {/* === 6. Rencana Makan === */}
        {latestMealPlan && (
          <ReportSection
            title="Rencana Makan"
            icon={Utensils}
            subtitle={`${(latestMealPlan.items || []).length} item · Compliance ${Math.round(latestMealPlan.compliance || 0)}%`}
          >
            <div className="space-y-3">
              {SLOT_ORDER.map((slot) => {
                const items = itemsBySlot[slot] || [];
                if (items.length === 0) return null;
                const slotCal = items.reduce((s, i) => s + i.cal, 0);
                return (
                  <div key={slot} className="rounded-md border border-border/50">
                    <div className="flex items-center justify-between border-b border-border/40 bg-muted/30 px-3 py-1.5">
                      <span className="text-xs font-semibold uppercase tracking-wide text-foreground">
                        {SLOT_LABELS[slot]}
                      </span>
                      <span className="text-xs font-bold text-primary">
                        {Math.round(slotCal)} kcal
                      </span>
                    </div>
                    <div className="divide-y divide-border/30">
                      {items.map((item: any) => (
                        <div
                          key={item.id}
                          className="flex items-center justify-between gap-2 px-3 py-1.5"
                        >
                          <div className="min-w-0">
                            <p className="truncate text-sm text-foreground">{item.food.name}</p>
                            <p className="text-[10px] text-muted-foreground">
                              {item.amount}g{item.food.urt ? ` · URT ${item.food.urt}` : ""}
                            </p>
                          </div>
                          <div className="flex shrink-0 items-center gap-3 text-[11px] text-muted-foreground">
                            <span>P {Math.round(item.protein)}g</span>
                            <span className="font-semibold text-primary">
                              {Math.round(item.cal)} kcal
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </ReportSection>
        )}

        {/* === 7. Rencana Latihan === */}
        {latestExercisePlan ? (
          <ReportSection
            title="Rencana Latihan"
            icon={Dumbbell}
            subtitle={`Target ${Math.round(latestExercisePlan.targetBurned)} kcal · Aktual ${Math.round(latestExercisePlan.totalBurned)} kcal`}
          >
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border/60 text-left text-[11px] uppercase tracking-wide text-muted-foreground">
                    <th className="py-1.5 pr-2">Latihan</th>
                    <th className="px-2">Tipe</th>
                    <th className="px-2">Intensitas</th>
                    <th className="px-2 text-right">Durasi</th>
                    <th className="px-2 text-right">Kalori</th>
                    <th className="pl-2 text-right">MET</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/30">
                  {(latestExercisePlan.items || []).map((item: any) => (
                    <tr key={item.id}>
                      <td className="py-1.5 pr-2 font-medium text-foreground">{item.name}</td>
                      <td className="px-2 text-xs text-muted-foreground">
                        {EXERCISE_TYPE_LABELS[item.type as ExerciseType] || item.type}
                      </td>
                      <td className="px-2 text-xs text-muted-foreground">
                        {INTENSITY_LABELS[item.intensity as ExerciseIntensity] || item.intensity}
                      </td>
                      <td className="px-2 text-right tabular-nums">{item.duration} min</td>
                      <td className="px-2 text-right font-semibold tabular-nums text-primary">
                        {Math.round(item.caloriesBurned)} kcal
                      </td>
                      <td className="pl-2 text-right tabular-nums text-muted-foreground">
                        {item.met.toFixed(1)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {latestExercisePlan.notes && (
              <p className="mt-2 rounded-md bg-muted/30 p-2 text-[11px] text-muted-foreground">
                <b>Catatan:</b> {latestExercisePlan.notes}
              </p>
            )}
          </ReportSection>
        ) : (
          <ReportSection title="Rencana Latihan" icon={Dumbbell}>
            <p className="text-sm text-muted-foreground">Belum ada rencana latihan tersusun untuk pasien ini.</p>
          </ReportSection>
        )}

        {/* === 8. AI Evaluation === */}
        {latestMealPlan?.aiReasoning ? (
          <ReportSection title="Evaluasi AI CareLivia" icon={Brain}>
            <div className="rounded-md border border-primary/30 bg-primary/5 p-3">
              {latestMealPlan.aiModel && (
                <Badge variant="outline" className="mb-2 text-[10px]">
                  {latestMealPlan.aiModel}
                </Badge>
              )}
              <p className="text-sm leading-relaxed text-foreground">
                {latestMealPlan.aiReasoning}
              </p>
            </div>
          </ReportSection>
        ) : null}

        {/* === 9. Footer — signature + QR === */}
        <div className="mt-8 flex flex-col gap-6 border-t border-border pt-6 sm:flex-row sm:items-end sm:justify-between">
          <div className="flex gap-8">
            <div>
              <p className="text-xs uppercase tracking-wide text-muted-foreground">
                Dokter Penanggung Jawab
              </p>
              <div className="mt-6 border-b border-foreground/60 pb-0.5 text-sm">
                __________________________
              </div>
            </div>
            <div>
              <p className="text-xs uppercase tracking-wide text-muted-foreground">
                Tanggal
              </p>
              <div className="mt-6 border-b border-foreground/60 pb-0.5 text-sm">
                __________________________
              </div>
            </div>
          </div>
          <div className="flex flex-col items-center">
            <div className="flex h-20 w-20 items-center justify-center rounded-md border-2 border-foreground/70">
              <div className="grid grid-cols-5 gap-0.5">
                {Array.from({ length: 25 }).map((_, i) => {
                  const seed = (i * 7 + 3) % 5;
                  return (
                    <div
                      key={i}
                      className={`h-2 w-2 ${seed % 2 === 0 ? "bg-foreground" : "bg-transparent"}`}
                    />
                  );
                })}
              </div>
            </div>
            <p className="mt-1 text-[10px] uppercase tracking-wide text-muted-foreground">
              QR Verifikasi
            </p>
          </div>
        </div>

        {/* Report footer note */}
        <div className="border-t border-border/40 pt-3 text-center text-[10px] text-muted-foreground">
          Dokumen ini dihasilkan oleh CareLivia Clinical Nutrition Management System.
          <br />
          Sesuai pedoman PERKENI · ESPEN · ASPEN · KDIGO · WHO · Kemenkes RI.
        </div>
      </div>
    </div>
  );
}

function ReportSection({
  title,
  subtitle,
  icon: Icon,
  children,
}: {
  title: string;
  subtitle?: string;
  icon: React.ComponentType<{ className?: string }>;
  children: React.ReactNode;
}) {
  return (
    <section className="border-b border-border/60 pb-4 last:border-b-0 last:pb-0">
      <div className="mb-3 flex items-center gap-2">
        <div className="flex h-7 w-7 items-center justify-center rounded-md bg-primary/10 text-primary">
          <Icon className="h-4 w-4" />
        </div>
        <div className="flex flex-1 flex-wrap items-baseline justify-between gap-2">
          <h3 className="text-sm font-bold uppercase tracking-wide text-foreground">
            {title}
          </h3>
          {subtitle && (
            <span className="text-[11px] text-muted-foreground">{subtitle}</span>
          )}
        </div>
      </div>
      {children}
    </section>
  );
}

function Field({
  label,
  value,
  mono,
}: {
  label: string;
  value: string;
  mono?: boolean;
}) {
  return (
    <div className="min-w-0">
      <p className="text-[10px] uppercase tracking-wide text-muted-foreground">
        {label}
      </p>
      <p
        className={`mt-0.5 truncate text-sm font-medium text-foreground ${mono ? "font-mono" : ""}`}
      >
        {value}
      </p>
    </div>
  );
}

function Metric({
  label,
  value,
  hint,
}: {
  label: string;
  value: string;
  hint?: string;
}) {
  return (
    <div className="rounded-md border border-border/60 bg-muted/20 px-3 py-2">
      <p className="text-[10px] uppercase tracking-wide text-muted-foreground">
        {label}
      </p>
      <p className="mt-0.5 text-base font-bold text-foreground">{value}</p>
      {hint && (
        <p className="text-[10px] text-muted-foreground">{hint}</p>
      )}
    </div>
  );
}

function NutrientCard({
  label,
  value,
  unit,
  icon: Icon,
}: {
  label: string;
  value: number;
  unit: string;
  icon: React.ComponentType<{ className?: string }>;
}) {
  return (
    <div className="flex items-center gap-2 rounded-md border border-border/60 bg-muted/20 px-3 py-2">
      <Icon className="h-4 w-4 shrink-0 text-primary" />
      <div className="min-w-0">
        <p className="text-[10px] uppercase tracking-wide text-muted-foreground">
          {label}
        </p>
        <p className="text-sm font-bold tabular-nums text-foreground">
          {value}
          <span className="ml-0.5 text-[10px] font-normal text-muted-foreground">
            {unit}
          </span>
        </p>
      </div>
    </div>
  );
}

// Assessment Score Card — for clinical report
function AssessmentScoreCard({
  label,
  score,
  category,
  color,
}: {
  label: string;
  score: string;
  category: string;
  color: "emerald" | "amber" | "rose";
}) {
  const colorMap: Record<string, string> = {
    emerald: "border-emerald-300 bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-400",
    amber: "border-amber-300 bg-amber-50 dark:bg-amber-950/30 text-amber-700 dark:text-amber-400",
    rose: "border-rose-300 bg-rose-50 dark:bg-rose-950/30 text-rose-700 dark:text-rose-400",
  };
  return (
    <div className={`rounded-md border p-2 ${colorMap[color]}`}>
      <p className="text-[9px] font-bold uppercase tracking-wide opacity-80">{label}</p>
      <p className="text-base font-bold tabular-nums">{score}</p>
      <p className="text-[9px] opacity-80">{category}</p>
    </div>
  );
}
