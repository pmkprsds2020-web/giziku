"use client";

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import type { Gender, ActivityLevel, StressLevel, DiagnosisType, MealSlot } from "@prisma/client";
import {
  // Patients
  supabaseFetchPatients,
  supabaseFetchPatient,
  supabaseCreatePatient,
  supabaseUpdatePatient,
  supabaseSoftDeletePatient,
  // Foods
  supabaseFetchFoods,
  supabaseCreateFood,
  supabaseUpdateFood,
  supabaseDeleteFood,
  supabaseFetchFoodPriceHistory,
  supabaseUpdateFoodPrice,
  supabaseFetchFoodChangeLogs,
  // Dashboard
  supabaseFetchDashboard,
  // Weight Records
  supabaseFetchWeightRecords,
  supabaseAddWeightRecord,
  supabaseDeleteWeightRecord,
  // Assessments
  supabaseFetchAssessments,
  supabaseCreateAssessment,
  supabaseDeleteAssessment,
  // Food Records
  supabaseFetchFoodRecords,
  supabaseAddFoodRecord,
  supabaseDeleteFoodRecord,
  // Meal Plans
  supabaseFetchMealPlans,
  supabaseAddMealItem,
  supabaseUpdateMealItem,
  supabaseDeleteMealItem,
  // Presets
  supabaseFetchPresets,
  supabaseCreatePreset,
  supabaseUpdatePreset,
  supabaseDeletePreset,
  supabaseClonePreset,
  supabaseTogglePresetFavorite,
  supabaseFetchPresetHistory,
  // Recipes
  supabaseFetchRecipes,
  supabaseCreateRecipe,
  supabaseDeleteRecipe,
  supabaseUpdateRecipe,
  // Saved Meal Plans
  supabaseFetchSavedMealPlans,
  supabaseCreateSavedMealPlan,
  supabaseDeleteSavedMealPlan,
  supabaseMarkSavedMealPlanUsed,
  // Saved Menus (per-slot)
  supabaseFetchSavedMenus,
  supabaseCreateSavedMenu,
  supabaseDeleteSavedMenu,
  supabaseMarkSavedMenuUsed,
} from "@/lib/supabase/frontend-data";

// Helper for API routes — ONLY for AI/complex server-side operations
// (z-ai-web-dev-sdk cannot run in browser)
async function jsonFetch<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    ...init,
    headers: { "Content-Type": "application/json", ...init?.headers },
  });
  const body = await res.json();
  if (!body.success) throw new Error(body.error || "Gagal memuat data");
  return body.data as T;
}

// ---------------- Patients (Direct Supabase) ----------------
export function usePatients() {
  return useQuery({
    queryKey: ["patients"],
    queryFn: () => supabaseFetchPatients(),
  });
}

export function usePatient(id: string | null) {
  return useQuery({
    queryKey: ["patient", id],
    queryFn: () => supabaseFetchPatient(id!),
    enabled: !!id,
  });
}

export function useCreatePatient() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: any) => supabaseCreatePatient(data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["patients"] });
      qc.invalidateQueries({ queryKey: ["dashboard"] });
    },
  });
}

export function useUpdatePatient(id: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: any) => supabaseUpdatePatient(id, data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["patients"] });
      qc.invalidateQueries({ queryKey: ["patient", id] });
    },
  });
}

export function useDeletePatient() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => supabaseSoftDeletePatient(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["patients"] });
      qc.invalidateQueries({ queryKey: ["dashboard"] });
    },
  });
}

// ---------------- Foods (Direct Supabase) ----------------
export function useFoods(params: { q?: string; categoryId?: string; highProtein?: boolean; lowGi?: boolean; lowSodium?: boolean; highFiber?: boolean }) {
  return useQuery({
    queryKey: ["foods", params],
    queryFn: () => supabaseFetchFoods(params),
  });
}

export function useCreateFood() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: any) => supabaseCreateFood(data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["foods"] }),
  });
}

export function useUpdateFood() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { id: string; [key: string]: any }) => {
      const { id, ...rest } = data;
      return supabaseUpdateFood(id, rest);
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["foods"] }),
  });
}

export function useDeleteFood() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => supabaseDeleteFood(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["foods"] }),
  });
}

export function useFoodPriceHistory(foodId: string | null) {
  return useQuery({
    queryKey: ["food-price-history", foodId],
    queryFn: () => supabaseFetchFoodPriceHistory(foodId!),
    enabled: !!foodId,
  });
}

export function useUpdateFoodPrice() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { id: string; price: number; unit?: string; location?: string | null; source?: string | null; notes?: string | null }) =>
      supabaseUpdateFoodPrice(data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["food-price-history"] });
      qc.invalidateQueries({ queryKey: ["foods"] });
    },
  });
}

export function useFoodChangeLogs(foodId: string | null) {
  return useQuery({
    queryKey: ["food-change-logs", foodId],
    queryFn: () => supabaseFetchFoodChangeLogs(foodId!),
    enabled: !!foodId,
  });
}

// ---------------- Calorie (API route — server-side clinical engine) ----------------
export interface CalorieInput { gender: Gender; ageYears: number; heightCm: number; weightKg: number; activity: ActivityLevel; stress: StressLevel; diagnoses: DiagnosisType[]; isPregnant?: boolean; pregnancyTrimester?: number; isLactating?: boolean; }
export function useComputeCalorie() {
  return useMutation({
    mutationFn: (input: CalorieInput) => jsonFetch<any>("/api/calorie", { method: "POST", body: JSON.stringify(input) }),
  });
}

// ---------------- Meal Plans (Direct Supabase reads, API route for AI generation) ----------------
export function useMealPlans(patientId?: string) {
  const qc = useQueryClient();
  return useQuery({
    queryKey: ["meal-plans", patientId],
    queryFn: () =>
      supabaseFetchMealPlans(patientId, {
        // Reuse whatever usePatients()/usePresets() already loaded on this
        // page instead of re-querying Supabase for the same rows.
        patients: qc.getQueryData<any[]>(["patients"]),
        presets: qc.getQueryData<any[]>(["presets", patientId]),
      }),
  });
}

// AI generation — server-side (z-ai-web-dev-sdk)
export function useGenerateMealPlan() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ patientId, presetId }: { patientId: string; presetId?: string }) =>
      jsonFetch<any>("/api/meal-plan", { method: "POST", body: JSON.stringify({ patientId, presetId }) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["meal-plans"] }),
  });
}

// Isi Piringku preview — server-side AI engine
export function usePreviewIsiPiringku() {
  return useMutation({
    mutationFn: ({ patientId, presetId }: { patientId: string; presetId?: string }) =>
      jsonFetch<any>("/api/meal-plan/isi-piringku", {
        method: "POST",
        body: JSON.stringify({ patientId, presetId }),
      }),
  });
}

// Meal Plan Items — Direct Supabase
export function useAddMealItem(mealPlanId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { slot: string; foodId: string; amount: number }) =>
      supabaseAddMealItem(mealPlanId, data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["meal-plans"] }),
  });
}

export function useUpdateMealItem(mealPlanId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { itemId: string; foodId?: string; amount?: number }) =>
      supabaseUpdateMealItem(mealPlanId, data.itemId, { foodId: data.foodId, amount: data.amount }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["meal-plans"] }),
  });
}

export function useDeleteMealItem(mealPlanId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (itemId: string) => supabaseDeleteMealItem(itemId),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["meal-plans"] }),
  });
}

// ---------------- Exercise (API route — server-side AI generation) ----------------
export function useExercisePlans(patientId: string | null) {
  return useQuery({
    queryKey: ["exercise-plans", patientId],
    queryFn: () => jsonFetch<any[]>(`/api/exercise?patientId=${patientId}`),
    enabled: !!patientId,
  });
}

export function useGenerateExercise() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ patientId }: { patientId: string }) => jsonFetch<any>("/api/exercise", { method: "POST", body: JSON.stringify({ patientId }) }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["exercise-plans"] });
      qc.invalidateQueries({ queryKey: ["patient"] });
    },
  });
}

// ---------------- Food Record (Direct Supabase) ----------------
export function useFoodRecords(patientId: string | null, date?: string) {
  return useQuery({
    queryKey: ["food-records", patientId, date],
    queryFn: () => supabaseFetchFoodRecords(patientId!, date),
    enabled: !!patientId,
  });
}

export function useAddFoodRecord() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { patientId: string; foodId: string; slot: MealSlot; amount: number; consumed?: number; date?: string; notes?: string }) =>
      supabaseAddFoodRecord(data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["food-records"] });
      qc.invalidateQueries({ queryKey: ["dashboard"] });
    },
  });
}

export function useDeleteFoodRecord() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => supabaseDeleteFoodRecord(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["food-records"] }),
  });
}

// ---------------- Shopping (API route — server-side aggregation) ----------------
export function useGenerateShopping() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { mealPlanId: string; period?: "DAILY" | "WEEKLY" | "MONTHLY" }) =>
      jsonFetch<any>("/api/shopping", { method: "POST", body: JSON.stringify(data) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["patient"] }),
  });
}

// ---------------- Dashboard (Direct Supabase) ----------------
export function useDashboard() {
  return useQuery({
    queryKey: ["dashboard"],
    queryFn: () => supabaseFetchDashboard(),
  });
}

// ---------------- Weight Records (Direct Supabase) ----------------
export function useWeightRecords(patientId: string | null) {
  return useQuery({
    queryKey: ["weight-records", patientId],
    queryFn: () => supabaseFetchWeightRecords(patientId!),
    enabled: !!patientId,
  });
}

export function useAddWeightRecord() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { patientId: string; date?: string; weight: number; height?: number | null; note?: string }) =>
      supabaseAddWeightRecord(data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["weight-records"] });
      qc.invalidateQueries({ queryKey: ["patients"] });
      qc.invalidateQueries({ queryKey: ["patient"] });
      qc.invalidateQueries({ queryKey: ["dashboard"] });
    },
  });
}

export function useDeleteWeightRecord() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => supabaseDeleteWeightRecord(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["weight-records"] });
      qc.invalidateQueries({ queryKey: ["patients"] });
      qc.invalidateQueries({ queryKey: ["patient"] });
    },
  });
}

// ---------------- Assessments (Direct Supabase) ----------------
export function useAssessments(patientId: string | null) {
  return useQuery({
    queryKey: ["assessments", patientId],
    queryFn: () => supabaseFetchAssessments(patientId!),
    enabled: !!patientId,
  });
}

export function useCreateAssessment() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: any) => supabaseCreateAssessment(data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["assessments"] });
      qc.invalidateQueries({ queryKey: ["patient"] });
    },
  });
}

export function useDeleteAssessment() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => supabaseDeleteAssessment(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["assessments"] });
      qc.invalidateQueries({ queryKey: ["patient"] });
    },
  });
}

// ---------------- Nutrition Presets (Direct Supabase) ----------------
export function usePresets(patientId?: string) {
  return useQuery({
    queryKey: ["presets", patientId],
    queryFn: () => supabaseFetchPresets(patientId),
  });
}

export function usePresetTemplates() {
  return useQuery({
    queryKey: ["preset-templates"],
    queryFn: () => supabaseFetchPresets(undefined).then((p) => p.filter((x: any) => x.isTemplate)),
  });
}

export function usePreset(id: string | null) {
  return useQuery({
    queryKey: ["preset", id],
    queryFn: async () => {
      const all = await supabaseFetchPresets();
      return all.find((p: any) => p.id === id) || null;
    },
    enabled: !!id,
  });
}

export function useCreatePreset() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: any) => supabaseCreatePreset(data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["presets"] }),
  });
}

export function useUpdatePreset() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { id: string; [key: string]: any }) => {
      const { id, ...rest } = data;
      return supabaseUpdatePreset(id, rest);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["presets"] });
      qc.invalidateQueries({ queryKey: ["preset"] });
    },
  });
}

export function useDeletePreset() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => supabaseDeletePreset(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["presets"] }),
  });
}

export function useClonePreset() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { id: string; newName?: string; patientId?: string | null }) =>
      supabaseClonePreset(data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["presets"] }),
  });
}

export function useToggleFavorite() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => supabaseTogglePresetFavorite(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["presets"] }),
  });
}

export function usePresetHistory(id: string | null) {
  return useQuery({
    queryKey: ["preset-history", id],
    queryFn: () => supabaseFetchPresetHistory(id!),
    enabled: !!id,
  });
}

export function useComparePresets() {
  return useMutation({
    mutationFn: async (ids: string[]) => {
      // Client-side comparison: fetch presets and compare
      const all = await supabaseFetchPresets();
      return ids.map((id) => all.find((p: any) => p.id === id)).filter(Boolean);
    },
  });
}

// ---------------- Saved Menus (per-slot) — Direct Supabase ----------------
export function useSavedMenus(params: { patientId?: string; category?: string; q?: string }) {
  return useQuery({
    queryKey: ["saved-menus", params],
    queryFn: () => supabaseFetchSavedMenus(params),
  });
}

export function useCreateSavedMenu() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: any) => supabaseCreateSavedMenu(data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["saved-menus"] }),
  });
}

export function useDeleteSavedMenu() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => supabaseDeleteSavedMenu(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["saved-menus"] }),
  });
}

export function useMarkSavedMenuUsed() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => supabaseMarkSavedMenuUsed(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["saved-menus"] }),
  });
}

// ---------------- Saved Meal Plans (Direct Supabase) ----------------
export function useSavedMealPlans(patientId?: string, q?: string) {
  return useQuery({
    queryKey: ["saved-meal-plans", patientId, q],
    queryFn: () => supabaseFetchSavedMealPlans(patientId),
  });
}

export function useCreateSavedMealPlan() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: any) => supabaseCreateSavedMealPlan(data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["saved-meal-plans"] }),
  });
}

export function useDeleteSavedMealPlan() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => supabaseDeleteSavedMealPlan(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["saved-meal-plans"] }),
  });
}

export function useMarkSavedMealPlanUsed() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => supabaseMarkSavedMealPlanUsed(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["saved-meal-plans"] }),
  });
}

// ---------------- Recipes (Direct Supabase) ----------------
export function useRecipes(q?: string) {
  return useQuery({
    queryKey: ["recipes", q],
    queryFn: () => supabaseFetchRecipes(q),
  });
}

export function useCreateRecipe() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: any) => supabaseCreateRecipe(data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["recipes"] }),
  });
}

export function useUpdateRecipe() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { id: string; [key: string]: any }) => {
      const { id, ...rest } = data;
      return supabaseUpdateRecipe(id, rest);
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["recipes"] }),
  });
}

export function useDeleteRecipe() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => supabaseDeleteRecipe(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["recipes"] }),
  });
}

// ---------------- Comparisons (API route — complex aggregation) ----------------
export function useComparisons(patientId: string | null) {
  return useQuery({
    queryKey: ["comparisons", patientId],
    queryFn: () => jsonFetch<any[]>(`/api/comparisons?patientId=${patientId}`),
    enabled: !!patientId,
  });
}

export function useRunComparison() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { patientId: string; date: string; mealPlanId?: string; savedMenuId?: string; savedMealPlanId?: string }) =>
      jsonFetch<any>("/api/comparisons", { method: "POST", body: JSON.stringify(data) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["comparisons"] }),
  });
}

// ---------------- Weekly Compliance (API route — aggregation) ----------------
export function useWeeklyCompliance(patientId: string | null) {
  return useQuery({
    queryKey: ["weekly-compliance", patientId],
    queryFn: () => jsonFetch<any>(`/api/compliance/weekly?patientId=${patientId}`),
    enabled: !!patientId,
  });
}
