import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, err, handleZod, ageFromBirth } from "@/lib/api-helpers";
import { computeCalorieTarget } from "@/lib/clinical/calorie-engine";
import {
  generateMealPlan,
  generateAIReasoning,
} from "@/lib/ai/meal-generator";
import {
  supabaseListMealPlans,
  supabaseCreateMealPlan,
  getServerClient,
  supabaseGetPatient,
  resolvePatientId,
} from "@/lib/supabase/data-layer";

// ---------------------------------------------------------------------
// GET /api/meal-plan?patientId=...
// List meal plans for a patient — reads from Supabase only
// ---------------------------------------------------------------------
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const patientId = searchParams.get("patientId");
    const plans = await supabaseListMealPlans(patientId || undefined);
    return ok(plans);
  } catch (e) {
    return handleZod(e);
  }
}

// ---------------------------------------------------------------------
// POST /api/meal-plan
// Generate Isi Piringku compliant meal plan AND persist to Supabase.
// ALL data comes from Supabase — NO Prisma.
// ---------------------------------------------------------------------
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { patientId, presetId } = body as {
      patientId?: string;
      presetId?: string;
    };
    if (!patientId) return err("patientId wajib diisi", 422);

    // Resolve Prisma cuid → Supabase UUID if needed
    const resolvedPatientId = await resolvePatientId(patientId);

    // Try Supabase first, fall back to Prisma for patient data
    let patient: any = await supabaseGetPatient(resolvedPatientId);
    if (!patient) {
      patient = await db.patient.findUnique({
        where: { id: patientId },
        include: {
          diagnoses: { where: { active: true } },
          assessments: { orderBy: { recordedAt: "desc" }, take: 1 },
        },
      });
    }
    if (!patient) return err("Pasien tidak ditemukan", 404);
    if (!patient.height || !patient.weight)
      return err("Tinggi & berat badan pasien harus diisi", 422);

    const ageYears = ageFromBirth(patient.birthDate);
    const latestAssessment = patient.assessments?.[0];

    // Filter active diagnoses
    const activeDiagnoses = (patient.diagnoses || []).filter((d: any) => d.active);

    // Derive activity & stress from assessment
    let activity = "LIGHT" as string;
    let stress = "NONE" as string;
    if (latestAssessment) {
      if (latestAssessment.activity) {
        activity = latestAssessment.activity;
      } else if (latestAssessment.ecog) {
        const ecogNum = Number(latestAssessment.ecog);
        if (ecogNum >= 3) activity = "BED_REST";
        else if (ecogNum === 2) activity = "VERY_LIGHT";
        else if (ecogNum === 1) activity = "LIGHT";
        else activity = "MODERATE";
      } else if (latestAssessment.barthel != null) {
        if (latestAssessment.barthel < 40) activity = "BED_REST";
        else if (latestAssessment.barthel < 60) activity = "VERY_LIGHT";
        else activity = "LIGHT";
      }
      if (latestAssessment.stress) stress = latestAssessment.stress;
    }

    const calResult = computeCalorieTarget({
      gender: patient.gender,
      ageYears,
      heightCm: patient.height,
      weightKg: patient.weight,
      activity: activity as any,
      stress: stress as any,
      diagnoses: activeDiagnoses.map((d: any) => d.type),
      isPregnant: patient.isPregnant,
      pregnancyTrimester: patient.pregnancyTrimester,
      isLactating: patient.isLactating,
    });

    // Preset override — fetch from Supabase
    let preset: any = null;
    let targets = {
      targetCal: calResult.targetCalorie,
      targetProtein: calResult.macros.proteinG,
      targetFat: calResult.macros.fatG,
      targetCarb: calResult.macros.carbG,
      targetFiber: calResult.fiberTarget,
      targetSodium: calResult.sodiumMax,
    };
    if (presetId) {
      const { client } = await getServerClient();
      const { data: presetData } = await client
        .from("nutrition_presets")
        .select("*")
        .eq("id", presetId)
        .is("deleted_at", null)
        .single();
      if (presetData) {
        preset = {
          id: presetData.id,
          name: presetData.name,
          totalCal: presetData.total_cal,
          proteinG: presetData.protein_g,
          fatG: presetData.fat_g,
          carbG: presetData.carb_g,
          fiberG: presetData.fiber_g,
          sodiumMg: presetData.sodium_mg,
          proteinPct: presetData.protein_pct,
          fatPct: presetData.fat_pct,
          carbPct: presetData.carb_pct,
        };
      } else {
        // Prisma fallback for preset
        preset = await db.nutritionPreset.findUnique({ where: { id: presetId } });
      }
      if (preset && !(preset as any).deletedAt) {
        targets = {
          targetCal: preset.totalCal,
          targetProtein: preset.proteinG,
          targetFat: preset.fatG,
          targetCarb: preset.carbG,
          targetFiber: preset.fiberG,
          targetSodium: preset.sodiumMg,
        };
        (calResult as any).targetCalorie = preset.totalCal;
        (calResult as any).macros = {
          proteinG: preset.proteinG,
          fatG: preset.fatG,
          carbG: preset.carbG,
          proteinKcal: preset.proteinG * 4,
          fatKcal: preset.fatG * 9,
          carbKcal: preset.carbG * 4,
          proteinPct: preset.proteinPct,
          fatPct: preset.fatPct,
          carbPct: preset.carbPct,
        };
        (calResult as any).fiberTarget = preset.fiberG;
        (calResult as any).sodiumMax = preset.sodiumMg;
      }
    }

    // Build rotation history from patient's last 14 meal plans (from Supabase)
    const recentPlans = await supabaseListMealPlans(patientId);
    const rotationHistory = recentPlans.slice(0, 14).map((p: any, idx: number) => ({
      day: idx,
      items: (p.items || []).map((i: any) => ({ foodId: i.foodId, foodName: i.food?.name || "" })),
    }));

    const plan = await generateMealPlan(
      calResult,
      activeDiagnoses.map((d: any) => d.type),
      { rotationHistory, currentDay: rotationHistory.length },
    );

    // AI reasoning (OpenAI, server-side) with timeout and fallback
    let reasoning = `Rencana makan disusun mengikuti Pedoman "Isi Piringku" Kemenkes RI dengan compliance ${plan.overallCompliance}% (${plan.overallTierLabel}). Setiap makan utama mengandung makanan pokok, lauk pauk, sayuran, dan buah. Komposisi disesuaikan untuk diagnosis: ${calResult.primaryDiagnosis?.label || "Umum"}.`;
    let reasoningModel = "fallback-deterministic";

    try {
      const reasoningPromise = generateAIReasoning(
        calResult,
        plan,
        activeDiagnoses.map((d: any) => d.type),
        patient.name,
        patientId,
      );
      const timeoutPromise = new Promise<{ text: string; model: string }>((_, reject) =>
        setTimeout(() => reject(new Error("AI reasoning timeout")), 30000)
      );
      const result = await Promise.race([reasoningPromise, timeoutPromise]);
      reasoning = result.text;
      reasoningModel = result.model;
    } catch (e) {
      console.warn("[meal-plan] AI reasoning failed, using fallback:", e);
    }

    // Persist to Supabase PostgreSQL
    const planData = {
      patientId,
      presetId: presetId || null,
      date: new Date().toISOString(),
      targetCal: targets.targetCal,
      targetProtein: targets.targetProtein,
      targetFat: targets.targetFat,
      targetCarb: targets.targetCarb,
      targetFiber: targets.targetFiber,
      targetSodium: targets.targetSodium,
      totalCal: plan.totals.cal,
      totalProtein: plan.totals.protein,
      totalFat: plan.totals.fat,
      totalCarb: plan.totals.carb,
      totalFiber: plan.totals.fiber,
      totalSodium: plan.totals.sodium,
      compliance: plan.overallCompliance,
      status: "FINAL",
      aiModel: preset
        ? `carelivia-isi-piringku-v2 + ${reasoningModel} (preset: ${preset.name})`
        : `carelivia-isi-piringku-v2 + ${reasoningModel}`,
      aiReasoning: reasoning,
    };

    const itemsData = plan.items.map((i) => ({
      slot: i.slot,
      foodId: i.foodId,
      amount: i.amount,
      cal: i.cal,
      protein: i.protein,
      fat: i.fat,
      carb: i.carb,
      fiber: i.fiber,
      sodium: i.sodium,
    }));

    const { data: mealPlan, error: saveError } = await supabaseCreateMealPlan(planData, itemsData);

    if (saveError) {
      // Prisma fallback — saves to local SQLite when Supabase isn't accessible
      console.warn("[meal-plan] Supabase save failed, falling back to Prisma:", saveError);
      try {
        const prismaMealPlan = await db.mealPlan.create({
          data: {
            patientId,
            presetId: presetId || null,
            date: new Date(),
            targetCal: targets.targetCal,
            targetProtein: targets.targetProtein,
            targetFat: targets.targetFat,
            targetCarb: targets.targetCarb,
            targetFiber: targets.targetFiber,
            targetSodium: targets.targetSodium,
            totalCal: plan.totals.cal,
            totalProtein: plan.totals.protein,
            totalFat: plan.totals.fat,
            totalCarb: plan.totals.carb,
            totalFiber: plan.totals.fiber,
            totalSodium: plan.totals.sodium,
            compliance: plan.overallCompliance,
            status: "FINAL",
            aiModel: preset
              ? `carelivia-isi-piringku-v2 + z-ai-llm (preset: ${preset.name})`
              : "carelivia-isi-piringku-v2 + z-ai-llm",
            aiReasoning: reasoning,
            items: {
              create: plan.items.map((i) => ({
                slot: i.slot,
                foodId: i.foodId,
                amount: i.amount,
                cal: i.cal,
                protein: i.protein,
                fat: i.fat,
                carb: i.carb,
                fiber: i.fiber,
                sodium: i.sodium,
              })),
            },
          },
          include: { items: true },
        });
        return ok({
          plan,
          mealPlan: prismaMealPlan,
          calorieResult: calResult,
          preset,
          aiReasoning: reasoning,
          compliance: plan.overallCompliance,
          patient: { id: patient.id, name: patient.name, mrn: patient.mrn, diagnoses: activeDiagnoses.map((d: any) => d.type) },
          targets,
          savedTo: "Local cache (login required for Supabase)",
        });
      } catch (prismaErr: any) {
        return err(`Gagal menyimpan meal plan: ${saveError}`, 500);
      }
    }

    return ok({
      plan,
      mealPlan,
      calorieResult: calResult,
      preset,
      aiReasoning: reasoning,
      compliance: plan.overallCompliance,
      patient: {
        id: patient.id,
        name: patient.name,
        mrn: patient.mrn,
        diagnoses: activeDiagnoses.map((d: any) => d.type),
      },
      targets,
      savedTo: "Supabase PostgreSQL",
    });
  } catch (e) {
    return handleZod(e);
  }
}
