export const runtime = "nodejs";

import { NextRequest } from "next/server";
import { z } from "zod";
import { ok, err, handleZod } from "@/lib/api-helpers";
import { generateStructured, AIUnavailableError } from "@/lib/ai/validator/validate";
import { ExercisePlanOutputSchema } from "@/lib/ai/schemas/features";
import { EXERCISE_PLAN_SYSTEM_PROMPT } from "@/lib/ai/prompts/features";
import { AI_MODELS } from "@/lib/ai/models";
import { logAIUsage } from "@/lib/ai/logging";
import { buildCacheKey, getCached, setCached } from "@/lib/ai/cache";
import { sanitizeObject, sanitizeErrorForClient } from "@/lib/ai/sanitize";
import { checkRateLimit, clientKeyFromRequest } from "@/lib/ai/rate-limit";
import { getServerClient } from "@/lib/supabase/data-layer";

const RequestSchema = z.object({
  patientId: z.string().min(1),
  patientName: z.string().min(1),
  ageYears: z.number().int().nonnegative(),
  gender: z.string(),
  bmi: z.number(),
  diagnoses: z.array(z.string()).default([]),
  activityLevel: z.string().default("LIGHT"),
  mobilityNotes: z.string().max(1000).default(""),
  targetCaloriesBurned: z.number().nonnegative().default(0),
});

// POST /api/ai/exercise-plan
export async function POST(req: NextRequest) {
  const rl = checkRateLimit(clientKeyFromRequest(req, "exercise-plan"), { limit: 15, windowMs: 60_000 });
  if (!rl.allowed) return err("Terlalu banyak permintaan. Coba lagi sebentar.", 429);

  try {
    const body = sanitizeObject(await req.json());
    const input = RequestSchema.parse(body);

    const cacheKey = buildCacheKey("exercise-plan", input);
    const cached = await getCached<z.infer<typeof ExercisePlanOutputSchema>>(cacheKey);
    if (cached) {
      await logAIUsage({
        feature: "exercise-plan",
        model: AI_MODELS.reasoning,
        promptTokens: 0,
        completionTokens: 0,
        responseTimeMs: 0,
        success: true,
        cacheHit: true,
        patientId: input.patientId,
      });
      return ok(cached);
    }

    const user = `Pasien: ${input.patientName}, ${input.ageYears} tahun, ${input.gender}, BMI ${input.bmi}
Diagnosis: ${input.diagnoses.join(", ") || "Umum"}
Tingkat aktivitas saat ini: ${input.activityLevel}
Catatan mobilitas/kontraindikasi: ${input.mobilityNotes || "(tidak ada)"}
Target kalori terbakar/hari: ${input.targetCaloriesBurned || "(sesuaikan dengan kondisi)"}

Susun rencana latihan aman sesuai schema JSON.`;

    const result = await generateStructured({
      model: AI_MODELS.reasoning,
      system: EXERCISE_PLAN_SYSTEM_PROMPT,
      user,
      schema: ExercisePlanOutputSchema,
    });

    await setCached(cacheKey, "exercise-plan", result.data);
    await logAIUsage({
      feature: "exercise-plan",
      model: result.model,
      promptTokens: result.promptTokens,
      completionTokens: result.completionTokens,
      responseTimeMs: result.responseTimeMs,
      success: true,
      patientId: input.patientId,
    });

    // Persist to Supabase (exercise_plans + exercise_items)
    try {
      const { client } = await getServerClient();
      const { data: planRow } = await client
        .from("exercise_plans")
        .insert({
          patient_id: input.patientId,
          date: new Date().toISOString(),
          total_burned: result.data.total_calories_burned,
          target_burned: input.targetCaloriesBurned,
          notes: result.data.reasoning,
        })
        .select()
        .single();

      if (planRow) {
        const items = result.data.items.map((it) => ({
          exercise_plan_id: planRow.id,
          name: it.name,
          type: it.type,
          intensity: it.intensity,
          duration: Math.round(it.duration_minutes),
          calories_burned: it.estimated_calories_burned,
          notes: it.precautions,
        }));
        if (items.length) await client.from("exercise_items").insert(items);
      }
    } catch (e) {
      console.error("[exercise-plan] persist failed (non-fatal):", e);
    }

    return ok(result.data);
  } catch (e) {
    if (e instanceof AIUnavailableError) return err(e.message, 503);
    if (e instanceof z.ZodError) return handleZod(e);
    return err(sanitizeErrorForClient(e), 500);
  }
}
