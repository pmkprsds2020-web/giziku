// =====================================================================
// CareLivia — Schema-Validated AI Generation
//
// Wraps callOpenAI() with:
//   1. JSON extraction (parser/json-parser.ts)
//   2. Zod schema validation
//   3. Automatic regeneration (up to AI_DEFAULTS.maxRetries) if the
//      output is malformed or fails schema validation, feeding the
//      validation error back to the model so it can self-correct.
// =====================================================================

import "server-only";
import { z } from "zod";
import { callOpenAI } from "../client";
import { extractJson, AIJsonParseError } from "../parser/json-parser";
import { AI_DEFAULTS } from "../models";

export interface GenerateStructuredOptions<T> {
  model: string;
  system: string;
  user: string;
  schema: z.ZodSchema<T>;
  temperature?: number;
  maxOutputTokens?: number;
  maxRetries?: number;
}

export interface GenerateStructuredResult<T> {
  data: T;
  model: string;
  promptTokens: number;
  completionTokens: number;
  responseTimeMs: number;
  attempts: number;
}

export class AIUnavailableError extends Error {
  constructor(message = "AI sedang tidak tersedia. Silakan coba beberapa saat lagi.") {
    super(message);
    this.name = "AIUnavailableError";
  }
}

export async function generateStructured<T>(
  opts: GenerateStructuredOptions<T>,
): Promise<GenerateStructuredResult<T>> {
  const maxRetries = opts.maxRetries ?? AI_DEFAULTS.maxRetries;
  let lastError: string | null = null;
  let totalPromptTokens = 0;
  let totalCompletionTokens = 0;
  let totalResponseTimeMs = 0;
  let usedModel = opts.model;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    const userPrompt =
      attempt === 0
        ? opts.user
        : `${opts.user}\n\n---\nPERCOBAAN SEBELUMNYA GAGAL VALIDASI:\n${lastError}\nPerbaiki dan kembalikan HANYA JSON valid sesuai format yang diminta, tanpa teks lain, tanpa markdown code fence.`;

    let result;
    try {
      result = await callOpenAI({
        model: opts.model,
        system: opts.system,
        user: userPrompt,
        temperature: opts.temperature,
        maxOutputTokens: opts.maxOutputTokens,
        jsonMode: true,
      });
    } catch (e) {
      lastError = e instanceof Error ? e.message : String(e);
      if (attempt === maxRetries) {
        throw new AIUnavailableError();
      }
      continue;
    }

    totalPromptTokens += result.promptTokens;
    totalCompletionTokens += result.completionTokens;
    totalResponseTimeMs += result.responseTimeMs;
    usedModel = result.model;

    try {
      const json = extractJson(result.content);
      const parsed = opts.schema.safeParse(json);
      if (parsed.success) {
        return {
          data: parsed.data,
          model: usedModel,
          promptTokens: totalPromptTokens,
          completionTokens: totalCompletionTokens,
          responseTimeMs: totalResponseTimeMs,
          attempts: attempt + 1,
        };
      }
      lastError = parsed.error.issues
        .map((i) => `${i.path.join(".")}: ${i.message}`)
        .join("; ");
    } catch (e) {
      lastError = e instanceof AIJsonParseError ? e.message : String(e);
    }
  }

  throw new AIUnavailableError(
    `AI sedang tidak tersedia. Silakan coba beberapa saat lagi. (Validasi gagal setelah ${maxRetries + 1}x percobaan)`,
  );
}
