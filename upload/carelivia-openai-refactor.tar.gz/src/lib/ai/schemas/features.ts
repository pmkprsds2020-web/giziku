import { z } from "zod";

// ---------------------------------------------------------------------
// Nutrition Analysis
// ---------------------------------------------------------------------
export const NutritionAnalysisOutputSchema = z.object({
  summary: z.string().min(10),
  strengths: z.array(z.string()).default([]),
  concerns: z.array(z.string()).default([]),
  recommendations: z.array(z.string()).default([]),
  risk_level: z.enum(["LOW", "MODERATE", "HIGH"]).default("LOW"),
});
export type NutritionAnalysisOutput = z.infer<typeof NutritionAnalysisOutputSchema>;

// ---------------------------------------------------------------------
// Exercise Plan
// ---------------------------------------------------------------------
export const ExerciseItemSchema = z.object({
  name: z.string(),
  type: z.enum(["CARDIO", "STRENGTH", "FLEXIBILITY", "BALANCE", "OTHER"]),
  intensity: z.enum(["LIGHT", "MODERATE", "VIGOROUS"]),
  duration_minutes: z.number().positive(),
  estimated_calories_burned: z.number().nonnegative(),
  precautions: z.string().default(""),
});
export const ExercisePlanOutputSchema = z.object({
  items: z.array(ExerciseItemSchema).min(1),
  total_calories_burned: z.number().nonnegative(),
  reasoning: z.string(),
  contraindications: z.array(z.string()).default([]),
});
export type ExercisePlanOutput = z.infer<typeof ExercisePlanOutputSchema>;

// ---------------------------------------------------------------------
// Shopping Planner
// ---------------------------------------------------------------------
export const ShoppingItemSchema = z.object({
  food_name: z.string(),
  amount: z.number().positive(),
  unit: z.string().default("g"),
  estimated_price_idr: z.number().nonnegative(),
  category: z.string().default(""),
});
export const ShoppingPlannerOutputSchema = z.object({
  items: z.array(ShoppingItemSchema).min(1),
  total_estimate_idr: z.number().nonnegative(),
  budget_notes: z.string().default(""),
  savings_tips: z.array(z.string()).default([]),
});
export type ShoppingPlannerOutput = z.infer<typeof ShoppingPlannerOutputSchema>;

// ---------------------------------------------------------------------
// Alternative Food
// ---------------------------------------------------------------------
export const AlternativeFoodOutputSchema = z.object({
  alternatives: z
    .array(
      z.object({
        food_name: z.string(),
        amount: z.number().positive(),
        similarity_reason: z.string(),
        nutrient_delta_note: z.string().default(""),
      }),
    )
    .min(1),
});
export type AlternativeFoodOutput = z.infer<typeof AlternativeFoodOutputSchema>;

// ---------------------------------------------------------------------
// Food Record Analysis
// ---------------------------------------------------------------------
export const FoodRecordAnalysisOutputSchema = z.object({
  adherence_summary: z.string(),
  deviations: z.array(z.string()).default([]),
  positive_patterns: z.array(z.string()).default([]),
  suggestions: z.array(z.string()).default([]),
});
export type FoodRecordAnalysisOutput = z.infer<typeof FoodRecordAnalysisOutputSchema>;

// ---------------------------------------------------------------------
// Clinical Recommendation / SOAP Note
// ---------------------------------------------------------------------
export const SoapNoteOutputSchema = z.object({
  subjective: z.string(),
  objective: z.string(),
  assessment: z.string(),
  plan: z.string(),
});
export type SoapNoteOutput = z.infer<typeof SoapNoteOutputSchema>;

// ---------------------------------------------------------------------
// Patient Summary
// ---------------------------------------------------------------------
export const PatientSummaryOutputSchema = z.object({
  overview: z.string(),
  nutritional_status: z.string(),
  key_risks: z.array(z.string()).default([]),
  progress_notes: z.string().default(""),
  next_steps: z.array(z.string()).default([]),
});
export type PatientSummaryOutput = z.infer<typeof PatientSummaryOutputSchema>;
