// =====================================================================
// CareLivia — Input / Error Sanitization for AI Routes
// =====================================================================

/** Strips characters commonly used for prompt injection / control chars. */
export function sanitizeText(input: string, maxLen = 2000): string {
  return input
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "") // control chars
    .replace(/```/g, "'''") // prevent breaking out of our own code fences
    .trim()
    .slice(0, maxLen);
}

/** Recursively sanitizes all string values in a plain object (shallow depth-limited). */
export function sanitizeObject<T>(obj: T, depth = 0): T {
  if (depth > 5) return obj;
  if (typeof obj === "string") return sanitizeText(obj) as unknown as T;
  if (Array.isArray(obj)) return obj.map((v) => sanitizeObject(v, depth + 1)) as unknown as T;
  if (obj && typeof obj === "object") {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(obj as Record<string, unknown>)) {
      out[k] = sanitizeObject(v, depth + 1);
    }
    return out as T;
  }
  return obj;
}

/** Never leak internal error details (stack traces, DB errors) to the client. */
export function sanitizeErrorForClient(e: unknown): string {
  if (e instanceof Error) {
    // Known, safe-to-show messages (already user-facing Indonesian text)
    if (/^(AI sedang tidak tersedia|Validasi gagal|Rate limit|Terlalu banyak permintaan)/.test(e.message)) {
      return e.message;
    }
  }
  console.error("[ai] internal error:", e);
  return "Terjadi kesalahan pada layanan AI. Silakan coba lagi.";
}
