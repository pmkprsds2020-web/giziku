// =====================================================================
// CareLivia — OpenAI Server Client
//
// SECURITY: This file MUST only ever be imported from:
//   - app/api/**/route.ts  (Route Handlers)
//   - other files under src/lib/ai/** or src/lib/server/**
// It reads OPENAI_API_KEY from process.env, which is only available on
// the server. Never import this file from a "use client" component —
// Next.js will fail the build if the key would leak to the browser
// bundle, but keep the boundary explicit regardless.
// =====================================================================

import "server-only";
import OpenAI from "openai";
import { AI_DEFAULTS } from "./models";

let _client: OpenAI | null = null;

export function getOpenAIClient(): OpenAI {
  if (_client) return _client;

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    throw new Error(
      "OPENAI_API_KEY belum diset. Tambahkan di Environment Variables Vercel atau .env.local.",
    );
  }

  _client = new OpenAI({
    apiKey,
    timeout: AI_DEFAULTS.timeoutMs,
    maxRetries: 0, // we handle retries ourselves in validator.ts (schema-aware retry)
  });

  return _client;
}

export interface AICallOptions {
  model: string;
  system: string;
  user: string;
  temperature?: number;
  maxOutputTokens?: number;
  jsonMode?: boolean;
}

export interface AICallResult {
  content: string;
  model: string;
  promptTokens: number;
  completionTokens: number;
  responseTimeMs: number;
}

/**
 * Single non-streaming chat completion call. Server-side only.
 * Throws on timeout/API error — callers (validator.ts) decide on retry.
 */
export async function callOpenAI(opts: AICallOptions): Promise<AICallResult> {
  const client = getOpenAIClient();
  const start = Date.now();

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), AI_DEFAULTS.timeoutMs);

  try {
    const completion = await client.chat.completions.create(
      {
        model: opts.model,
        temperature: opts.temperature ?? AI_DEFAULTS.temperature,
        max_tokens: opts.maxOutputTokens ?? AI_DEFAULTS.maxOutputTokens,
        response_format: opts.jsonMode ? { type: "json_object" } : undefined,
        messages: [
          { role: "system", content: opts.system },
          { role: "user", content: opts.user },
        ],
      },
      { signal: controller.signal },
    );

    const content = completion.choices[0]?.message?.content ?? "";

    return {
      content,
      model: completion.model,
      promptTokens: completion.usage?.prompt_tokens ?? 0,
      completionTokens: completion.usage?.completion_tokens ?? 0,
      responseTimeMs: Date.now() - start,
    };
  } finally {
    clearTimeout(timeout);
  }
}

/**
 * Streaming chat completion — used only by the AI Chat feature.
 * Returns an async iterator of text deltas; caller pipes into a
 * ReadableStream for the Route Handler response.
 */
export async function* streamOpenAI(opts: {
  model: string;
  system: string;
  messages: { role: "user" | "assistant"; content: string }[];
  temperature?: number;
  maxOutputTokens?: number;
}): AsyncGenerator<string, { promptTokens: number; completionTokens: number }, unknown> {
  const client = getOpenAIClient();

  const stream = await client.chat.completions.create({
    model: opts.model,
    temperature: opts.temperature ?? AI_DEFAULTS.temperature,
    max_tokens: opts.maxOutputTokens ?? AI_DEFAULTS.maxOutputTokens,
    stream: true,
    stream_options: { include_usage: true },
    messages: [{ role: "system", content: opts.system }, ...opts.messages],
  });

  let promptTokens = 0;
  let completionTokens = 0;

  for await (const chunk of stream) {
    const delta = chunk.choices[0]?.delta?.content;
    if (delta) yield delta;
    if (chunk.usage) {
      promptTokens = chunk.usage.prompt_tokens ?? 0;
      completionTokens = chunk.usage.completion_tokens ?? 0;
    }
  }

  return { promptTokens, completionTokens };
}
