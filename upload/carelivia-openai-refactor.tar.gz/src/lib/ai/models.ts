// =====================================================================
// CareLivia — AI Model Configuration
// Single source of truth for which OpenAI model powers each feature.
// Change models here without touching any route/prompt code.
// =====================================================================

export const AI_MODELS = {
  // Structured JSON generation (meal plan reasoning, nutrition analysis,
  // exercise plan, shopping planner, alternative food, food record, SOAP,
  // patient summary). Needs strong instruction following + JSON mode.
  reasoning: process.env.OPENAI_MODEL_REASONING || "gpt-4.1",

  // Conversational chat (AI Chat feature) — streaming, lower latency.
  chat: process.env.OPENAI_MODEL_CHAT || "gpt-4.1-mini",

  // Lightweight classification / quick lookups (e.g. food matching).
  fast: process.env.OPENAI_MODEL_FAST || "gpt-4.1-mini",
} as const;

export type AIFeature = keyof typeof AI_MODELS;

// Per-feature generation defaults.
export const AI_DEFAULTS = {
  temperature: 0.4,
  maxOutputTokens: 3000,
  timeoutMs: 30_000,
  maxRetries: 2,
} as const;

// Approximate USD price per 1K tokens, used only for cost estimation in
// logs/dashboards. Update when OpenAI pricing changes. Not billed from here.
export const AI_PRICING_PER_1K: Record<string, { input: number; output: number }> = {
  "gpt-4.1": { input: 0.002, output: 0.008 },
  "gpt-4.1-mini": { input: 0.0004, output: 0.0016 },
  "gpt-4.1-nano": { input: 0.0001, output: 0.0004 },
  "gpt-4o": { input: 0.0025, output: 0.01 },
  "gpt-4o-mini": { input: 0.00015, output: 0.0006 },
};

export function estimateCostUsd(model: string, promptTokens: number, completionTokens: number): number {
  const price = AI_PRICING_PER_1K[model];
  if (!price) return 0;
  return (promptTokens / 1000) * price.input + (completionTokens / 1000) * price.output;
}
