import "server-only";
import { createClient as createSupabaseClient } from "@supabase/supabase-js";

/**
 * Service-role Supabase client — SERVER ONLY, bypasses RLS.
 *
 * Use this ONLY for internal, non-user-facing operations:
 *   - AI usage logging (ai_usage_logs)
 *   - AI response caching (ai_cache)
 *
 * NEVER use this client to read/write patient data on behalf of a request —
 * use lib/supabase/server.ts (cookie-authenticated, RLS-enforced) for that.
 * NEVER import this file from a "use client" component.
 */
let _serviceClient: ReturnType<typeof createSupabaseClient> | null = null;

export function getServiceClient() {
  if (_serviceClient) return _serviceClient;

  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!url || !serviceKey) {
    throw new Error(
      "SUPABASE_SERVICE_ROLE_KEY / NEXT_PUBLIC_SUPABASE_URL belum diset — diperlukan untuk AI logging/cache.",
    );
  }

  _serviceClient = createSupabaseClient(url, serviceKey, {
    auth: { autoRefreshToken: false, persistSession: false },
  });

  return _serviceClient;
}
