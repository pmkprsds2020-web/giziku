"use client";

import * as React from "react";
import {
  Dumbbell,
  User,
  Flame,
  Timer,
  Activity,
  ListChecks,
  Sparkles,
  StickyNote,
  TrendingUp,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { toast } from "sonner";
import {
  PageHeader,
  SectionCard,
  StatCard,
  EmptyState,
  LoadingState,
} from "@/components/carelivia/ui-helpers";
import {
  usePatients,
  usePatient,
  useGenerateExercise,
} from "@/hooks/use-carelivia";
import { useCareLiviaStore } from "@/store/carelivia";
import { DIAGNOSIS_ADJUSTMENTS } from "@/lib/clinical/constants";
import type {
  DiagnosisType,
  ExerciseIntensity,
  ExerciseType,
} from "@prisma/client";

const EXERCISE_TYPE_LABELS: Record<ExerciseType, string> = {
  AEROBIC: "Aerobik",
  RESISTANCE: "Resistance",
  FLEXIBILITY: "Fleksibilitas",
  BALANCE: "Keseimbangan",
  FUNCTIONAL: "Fungsional",
};

const INTENSITY_LABELS: Record<ExerciseIntensity, string> = {
  LOW: "Ringan",
  MODERATE: "Sedang",
  HIGH: "Berat",
};

const INTENSITY_COLORS: Record<ExerciseIntensity, string> = {
  LOW: "border-emerald-300 bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300",
  MODERATE:
    "border-amber-300 bg-amber-50 text-amber-700 dark:bg-amber-950 dark:text-amber-300",
  HIGH: "border-rose-300 bg-rose-50 text-rose-700 dark:bg-rose-950 dark:text-rose-300",
};

interface ExerciseItem {
  id: string;
  name: string;
  type: ExerciseType;
  intensity: ExerciseIntensity;
  duration: number;
  caloriesBurned: number;
  met: number;
  notes?: string | null;
}

interface ExercisePlan {
  id: string;
  date: string | Date;
  targetBurned: number;
  totalBurned: number;
  notes?: string | null;
  items: ExerciseItem[];
}

export function ExerciseView() {
  const { data: patients } = usePatients();
  const { activePatientId, setActivePatient } = useCareLiviaStore();
  const [selectedPatientId, setSelectedPatientId] = React.useState<string>(
    activePatientId || "",
  );

  React.useEffect(() => {
    if (activePatientId && !selectedPatientId) {
      setSelectedPatientId(activePatientId);
    }
  }, [activePatientId, selectedPatientId]);

  const { data: patient, isLoading } = usePatient(selectedPatientId || null);
  const generateMut = useGenerateExercise();

  const selectedPatient = patients?.find((p) => p.id === selectedPatientId);
  const latestPlan: ExercisePlan | undefined = patient?.exercisePlans?.[0];

  const handleSelectPatient = (id: string) => {
    setSelectedPatientId(id);
    setActivePatient(id);
  };

  const handleGenerate = async () => {
    if (!selectedPatientId) {
      toast.error("Pilih pasien terlebih dahulu");
      return;
    }
    try {
      await generateMut.mutateAsync({ patientId: selectedPatientId });
      toast.success("Rencana latihan berhasil dibuat");
    } catch (e: any) {
      toast.error(e.message || "Gagal membuat rencana latihan");
    }
  };

  return (
    <div>
      <PageHeader
        title="Rencana Latihan (Exercise Plan)"
        subtitle="Personalisasi berdasarkan diagnosis, BMI, ECOG, Barthel & risiko jatuh"
        icon={Dumbbell}
        actions={
          <Button
            onClick={handleGenerate}
            disabled={generateMut.isPending || !selectedPatientId}
          >
            {generateMut.isPending ? (
              <>
                <Sparkles className="mr-2 h-4 w-4 animate-pulse" /> Membuat...
              </>
            ) : (
              <>
                <Sparkles className="mr-2 h-4 w-4" /> Generate Exercise Plan
              </>
            )}
          </Button>
        }
      />

      {/* Patient selector */}
      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="flex items-center gap-2">
          <User className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm font-medium">Pasien:</span>
        </div>
        <Select value={selectedPatientId} onValueChange={handleSelectPatient}>
          <SelectTrigger className="w-full sm:w-72">
            <SelectValue placeholder="Pilih pasien..." />
          </SelectTrigger>
          <SelectContent>
            {(patients || []).map((p) => (
              <SelectItem key={p.id} value={p.id}>
                {p.name} ({p.mrn})
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {selectedPatient && (
          <div className="flex flex-wrap gap-1">
            {Array.isArray(selectedPatient.diagnoses) && selectedPatient.diagnoses.slice(0, 3).map((raw: any, i: number) => {
              const d: string = typeof raw === "string" ? raw : (raw?.type ?? "");
              if (!d) return null;
              return (
                <Badge key={`${d}-${i}`} variant="secondary" className="text-[10px]">
                  {DIAGNOSIS_ADJUSTMENTS[d as DiagnosisType]?.label.split(" ")[0] || d}
                </Badge>
              );
            })}
          </div>
        )}
      </div>

      {!selectedPatientId ? (
        <EmptyState
          title="Pilih pasien untuk memulai"
          description="Sistem akan menyusun rencana latihan berbasis MET (Compendium of Physical Activities)."
          icon={Dumbbell}
        />
      ) : isLoading ? (
        <LoadingState count={4} />
      ) : !latestPlan ? (
        <EmptyState
          title="Belum ada rencana latihan"
          description="Klik 'Generate Exercise Plan' untuk membuat rencana terpersonalisasi."
          icon={Sparkles}
          action={
            <Button onClick={handleGenerate} disabled={generateMut.isPending}>
              <Sparkles className="mr-2 h-4 w-4" /> Generate Sekarang
            </Button>
          }
        />
      ) : (
        <ExercisePlanDetail plan={latestPlan} />
      )}
    </div>
  );
}

function ExercisePlanDetail({ plan }: { plan: ExercisePlan }) {
  const items = plan.items || [];
  const totalDuration = items.reduce((s, i) => s + i.duration, 0);
  const totalBurned = plan.totalBurned || items.reduce((s, i) => s + i.caloriesBurned, 0);
  const targetBurned = plan.targetBurned || 0;
  const burnPct = targetBurned > 0 ? Math.min(100, (totalBurned / targetBurned) * 100) : 0;
  const planDate = new Date(plan.date).toLocaleDateString("id-ID", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  return (
    <div className="space-y-4">
      {/* KPI cards */}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          label="Target Burned"
          value={Math.round(targetBurned)}
          unit="kcal"
          icon={TrendingUp}
          color="amber"
          sublabel="20% kalori harian"
        />
        <StatCard
          label="Aktual Burned"
          value={Math.round(totalBurned)}
          unit="kcal"
          icon={Flame}
          color={burnPct >= 90 ? "emerald" : burnPct >= 60 ? "amber" : "rose"}
          sublabel={`${Math.round(burnPct)}% dari target`}
        />
        <StatCard
          label="Total Durasi"
          value={totalDuration}
          unit="menit"
          icon={Timer}
          color="teal"
          sublabel={`${items.length} jenis latihan`}
        />
        <StatCard
          label="Jumlah Latihan"
          value={items.length}
          unit="item"
          icon={ListChecks}
          color="violet"
          sublabel={planDate}
        />
      </div>

      {/* Exercise items table */}
      <SectionCard
        title="Daftar Latihan"
        description={`${items.length} item · Formula: MET × berat (kg) × durasi (menit) / 60`}
      >
        {items.length === 0 ? (
          <p className="py-4 text-center text-sm text-muted-foreground">
            Tidak ada item latihan.
          </p>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="min-w-[160px]">Nama Latihan</TableHead>
                  <TableHead>Tipe</TableHead>
                  <TableHead>Intensitas</TableHead>
                  <TableHead className="text-right">Durasi</TableHead>
                  <TableHead className="text-right">Kalori</TableHead>
                  <TableHead className="text-right">MET</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {items.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell className="font-medium text-foreground">
                      <div className="flex items-center gap-2">
                        <Activity className="h-4 w-4 text-primary" />
                        {item.name}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="text-[10px]">
                        {EXERCISE_TYPE_LABELS[item.type] || item.type}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant="outline"
                        className={`text-[10px] ${INTENSITY_COLORS[item.intensity]}`}
                      >
                        {INTENSITY_LABELS[item.intensity] || item.intensity}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right tabular-nums">
                      {item.duration} <span className="text-xs text-muted-foreground">min</span>
                    </TableCell>
                    <TableCell className="text-right font-semibold tabular-nums text-primary">
                      {Math.round(item.caloriesBurned)}{" "}
                      <span className="text-xs font-normal text-muted-foreground">kcal</span>
                    </TableCell>
                    <TableCell className="text-right tabular-nums text-muted-foreground">
                      {item.met.toFixed(1)}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </SectionCard>

      {/* Clinical notes */}
      {plan.notes && (
        <SectionCard
          title="Catatan Klinis"
          description="Pertimbangan klinis perencanaan latihan"
        >
          <div className="flex gap-3 rounded-lg border border-border/60 bg-muted/30 p-4">
            <StickyNote className="h-5 w-5 shrink-0 text-primary" />
            <p className="text-sm leading-relaxed text-foreground">{plan.notes}</p>
          </div>
        </SectionCard>
      )}
    </div>
  );
}
