import { NextRequest } from "next/server";
import { ok, err, handleZod, safeParse } from "@/lib/api-helpers";
import { z } from "zod";
import { getServerClient, foodFromSupabase, resolvePatientId, resolveFoodId } from "@/lib/supabase/data-layer";

const ItemSchema = z.object({
  foodId: z.string().min(1),
  amount: z.number().min(0.1).max(5000),
  foodName: z.string(),
  urt: z.string().optional().nullable(),
  cal: z.number(),
  protein: z.number(),
  fat: z.number(),
  carb: z.number(),
  fiber: z.number(),
  sodium: z.number(),
  potassium: z.number(),
});

const CreateSchema = z.object({
  patientId: z.string().optional().nullable(),
  name: z.string().min(1, "Nama menu wajib diisi"),
  category: z.enum(["BREAKFAST", "MORNING_SNACK", "LUNCH", "AFTERNOON_SNACK", "DINNER", "EVENING_SNACK"]),
  notes: z.string().optional().default(""),
  items: z.array(ItemSchema).min(1, "Minimal 1 bahan"),
});

function mapMenu(row: any) {
  return {
    id: row.id,
    patientId: row.patient_id,
    name: row.name,
    category: row.category,
    notes: row.notes,
    totalCal: row.total_cal,
    totalProtein: row.total_protein,
    totalFat: row.total_fat,
    totalCarb: row.total_carb,
    totalFiber: row.total_fiber,
    totalSodium: row.total_sodium,
    totalPotassium: row.total_potassium,
    version: row.version,
    useCount: row.use_count,
    lastUsedAt: row.last_used_at,
    deletedAt: row.deleted_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    items: (row.saved_menu_items || []).map((i: any) => ({
      id: i.id,
      savedMenuId: i.saved_menu_id,
      foodId: i.food_id,
      amount: i.amount,
      foodName: i.food_name,
      urt: i.urt,
      cal: i.cal,
      protein: i.protein,
      fat: i.fat,
      carb: i.carb,
      fiber: i.fiber,
      sodium: i.sodium,
      potassium: i.potassium,
      food: i.foods ? foodFromSupabase(i.foods, i.foods.food_categories) : null,
    })),
  };
}

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const patientId = searchParams.get("patientId");
    const category = searchParams.get("category");
    const q = searchParams.get("q");

    const { client } = await getServerClient();
    let query = client
      .from("saved_menus")
      .select("*, saved_menu_items(*, foods(*, food_categories(*)))")
      .is("deleted_at", null)
      .order("last_used_at", { ascending: false, nullsFirst: false })
      .order("created_at", { ascending: false });

    if (patientId) query = query.eq("patient_id", await resolvePatientId(patientId));
    if (category) query = query.eq("category", category);
    if (q) query = query.ilike("name", `%${q}%`);

    const { data, error } = await query;
    if (error) return err(error.message, 500);

    return ok((data || []).map(mapMenu));
  } catch (e) {
    return handleZod(e);
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = safeParse(CreateSchema, body);
    if (!parsed.success) return handleZod(parsed.error);
    const d = parsed.data;

    const resolvedPatientId = d.patientId ? await resolvePatientId(d.patientId) : null;
    const resolvedItems = await Promise.all(
      d.items.map(async (it) => ({ ...it, foodId: await resolveFoodId(it.foodId) })),
    );

    const totals = resolvedItems.reduce(
      (acc, i) => ({
        cal: acc.cal + i.cal,
        protein: acc.protein + i.protein,
        fat: acc.fat + i.fat,
        carb: acc.carb + i.carb,
        fiber: acc.fiber + i.fiber,
        sodium: acc.sodium + i.sodium,
        potassium: acc.potassium + i.potassium,
      }),
      { cal: 0, protein: 0, fat: 0, carb: 0, fiber: 0, sodium: 0, potassium: 0 },
    );

    const { client, session } = await getServerClient();
    if (!session) return err("Authentication required. Please log in to save menus.", 401);

    const { data: menuRow, error: menuError } = await client
      .from("saved_menus")
      .insert({
        patient_id: resolvedPatientId,
        name: d.name,
        category: d.category,
        notes: d.notes,
        total_cal: Math.round(totals.cal * 10) / 10,
        total_protein: Math.round(totals.protein * 10) / 10,
        total_fat: Math.round(totals.fat * 10) / 10,
        total_carb: Math.round(totals.carb * 10) / 10,
        total_fiber: Math.round(totals.fiber * 10) / 10,
        total_sodium: Math.round(totals.sodium),
        total_potassium: Math.round(totals.potassium),
      })
      .select()
      .single();
    if (menuError) return err(menuError.message, 500);

    const { error: itemsError } = await client.from("saved_menu_items").insert(
      resolvedItems.map((it) => ({
        saved_menu_id: menuRow.id,
        food_id: it.foodId,
        amount: it.amount,
        food_name: it.foodName,
        urt: it.urt || null,
        cal: it.cal,
        protein: it.protein,
        fat: it.fat,
        carb: it.carb,
        fiber: it.fiber,
        sodium: it.sodium,
        potassium: it.potassium,
      })),
    );
    if (itemsError) return err(itemsError.message, 500);

    const { data: fullMenu } = await client
      .from("saved_menus")
      .select("*, saved_menu_items(*, foods(*, food_categories(*)))")
      .eq("id", menuRow.id)
      .single();

    return ok(mapMenu(fullMenu || menuRow), 201);
  } catch (e) {
    return handleZod(e);
  }
}
