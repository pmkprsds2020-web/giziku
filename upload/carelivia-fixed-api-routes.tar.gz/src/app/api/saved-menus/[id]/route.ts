import { NextRequest } from "next/server";
import { ok, err, handleZod, safeParse } from "@/lib/api-helpers";
import { z } from "zod";
import { getServerClient, foodFromSupabase, resolveFoodId } from "@/lib/supabase/data-layer";

const UpdateSchema = z.object({
  name: z.string().min(1).optional(),
  notes: z.string().optional(),
  items: z
    .array(
      z.object({
        foodId: z.string().min(1),
        amount: z.number().min(0.1).max(5000),
        foodName: z.string(),
        urt: z.string().optional().nullable(),
        cal: z.number(),
        protein: z.number(),
        fat: z.number(),
        carb: z.number(),
        fiber: z.number(),
        sodium: z.number(),
        potassium: z.number(),
      }),
    )
    .optional(),
});

function mapMenu(row: any) {
  return {
    id: row.id,
    patientId: row.patient_id,
    name: row.name,
    category: row.category,
    notes: row.notes,
    totalCal: row.total_cal,
    totalProtein: row.total_protein,
    totalFat: row.total_fat,
    totalCarb: row.total_carb,
    totalFiber: row.total_fiber,
    totalSodium: row.total_sodium,
    totalPotassium: row.total_potassium,
    version: row.version,
    useCount: row.use_count,
    lastUsedAt: row.last_used_at,
    deletedAt: row.deleted_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    items: (row.saved_menu_items || []).map((i: any) => ({
      id: i.id,
      savedMenuId: i.saved_menu_id,
      foodId: i.food_id,
      amount: i.amount,
      foodName: i.food_name,
      urt: i.urt,
      cal: i.cal,
      protein: i.protein,
      fat: i.fat,
      carb: i.carb,
      fiber: i.fiber,
      sodium: i.sodium,
      potassium: i.potassium,
      food: i.foods ? foodFromSupabase(i.foods, i.foods.food_categories) : null,
    })),
  };
}

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const { client } = await getServerClient();
    const { data, error } = await client
      .from("saved_menus")
      .select("*, saved_menu_items(*, foods(*, food_categories(*)))")
      .eq("id", id)
      .is("deleted_at", null)
      .single();
    if (error || !data) return err("Menu tidak ditemukan", 404);
    return ok(mapMenu(data));
  } catch (e) {
    return handleZod(e);
  }
}

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const body = await req.json();
    const parsed = safeParse(UpdateSchema, body);
    if (!parsed.success) return handleZod(parsed.error);
    const d = parsed.data;

    const { client } = await getServerClient();
    const { data: existing, error: fetchError } = await client
      .from("saved_menus")
      .select("id, deleted_at, version")
      .eq("id", id)
      .single();
    if (fetchError || !existing || existing.deleted_at) return err("Menu tidak ditemukan", 404);

    const updatePayload: Record<string, any> = { version: (existing.version || 1) + 1 };
    if (d.name !== undefined) updatePayload.name = d.name;
    if (d.notes !== undefined) updatePayload.notes = d.notes;

    if (d.items) {
      await client.from("saved_menu_items").delete().eq("saved_menu_id", id);
      const resolvedItems = await Promise.all(
        d.items.map(async (it) => ({ ...it, foodId: await resolveFoodId(it.foodId) })),
      );
      const { error: itemsError } = await client.from("saved_menu_items").insert(
        resolvedItems.map((it) => ({
          saved_menu_id: id,
          food_id: it.foodId,
          amount: it.amount,
          food_name: it.foodName,
          urt: it.urt || null,
          cal: it.cal,
          protein: it.protein,
          fat: it.fat,
          carb: it.carb,
          fiber: it.fiber,
          sodium: it.sodium,
          potassium: it.potassium,
        })),
      );
      if (itemsError) return err(itemsError.message, 500);

      const totals = resolvedItems.reduce(
        (acc, i) => ({
          cal: acc.cal + i.cal,
          protein: acc.protein + i.protein,
          fat: acc.fat + i.fat,
          carb: acc.carb + i.carb,
          fiber: acc.fiber + i.fiber,
          sodium: acc.sodium + i.sodium,
          potassium: acc.potassium + i.potassium,
        }),
        { cal: 0, protein: 0, fat: 0, carb: 0, fiber: 0, sodium: 0, potassium: 0 },
      );
      updatePayload.total_cal = Math.round(totals.cal * 10) / 10;
      updatePayload.total_protein = Math.round(totals.protein * 10) / 10;
      updatePayload.total_fat = Math.round(totals.fat * 10) / 10;
      updatePayload.total_carb = Math.round(totals.carb * 10) / 10;
      updatePayload.total_fiber = Math.round(totals.fiber * 10) / 10;
      updatePayload.total_sodium = Math.round(totals.sodium);
      updatePayload.total_potassium = Math.round(totals.potassium);
    }

    const { error: updateError } = await client.from("saved_menus").update(updatePayload).eq("id", id);
    if (updateError) return err(updateError.message, 500);

    const { data: fullMenu } = await client
      .from("saved_menus")
      .select("*, saved_menu_items(*, foods(*, food_categories(*)))")
      .eq("id", id)
      .single();

    return ok(mapMenu(fullMenu));
  } catch (e) {
    return handleZod(e);
  }
}

// Mark as used
export async function PATCH(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const { client } = await getServerClient();
    const { data: existing, error: fetchError } = await client
      .from("saved_menus")
      .select("use_count, deleted_at")
      .eq("id", id)
      .single();
    if (fetchError || !existing || existing.deleted_at) return err("Menu tidak ditemukan", 404);

    const { data: updated, error } = await client
      .from("saved_menus")
      .update({ use_count: (existing.use_count || 0) + 1, last_used_at: new Date().toISOString() })
      .eq("id", id)
      .select()
      .single();
    if (error) return err(error.message, 500);

    return ok(mapMenu(updated));
  } catch (e) {
    return handleZod(e);
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const { client } = await getServerClient();
    const { data: existing, error: fetchError } = await client
      .from("saved_menus")
      .select("id, deleted_at")
      .eq("id", id)
      .single();
    if (fetchError || !existing || existing.deleted_at) return err("Menu tidak ditemukan", 404);

    const { error } = await client
      .from("saved_menus")
      .update({ deleted_at: new Date().toISOString() })
      .eq("id", id);
    if (error) return err(error.message, 500);

    return ok({ id, deleted: true });
  } catch (e) {
    return handleZod(e);
  }
}
