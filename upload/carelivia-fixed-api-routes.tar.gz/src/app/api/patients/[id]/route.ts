import { NextRequest } from "next/server";
import { ok, err, handleZod } from "@/lib/api-helpers";
import { z } from "zod";
import {
  getServerClient,
  patientFromSupabase,
  supabaseUpdatePatient,
  supabaseSoftDeletePatient,
  foodFromSupabase,
  resolvePatientId,
} from "@/lib/supabase/data-layer";

const UpdateSchema = z.object({
  name: z.string().min(1).optional(),
  phone: z.string().optional(),
  address: z.string().optional(),
  religion: z.enum(["ISLAM", "KRISTEN", "KATOLIK", "HINDU", "BUDDHA", "KONGHUCU", "OTHER"]).optional(),
  bloodType: z.enum(["A", "B", "AB", "O", "UNKNOWN"]).optional(),
  allergy: z.string().optional(),
  height: z.number().optional().nullable(),
  weight: z.number().optional().nullable(),
  isPregnant: z.boolean().optional(),
  pregnancyTrimester: z.number().optional(),
  isLactating: z.boolean().optional(),
  lactationMonth: z.number().optional(),
  notes: z.string().optional(),
});

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const resolvedId = await resolvePatientId(id);
    const { client } = await getServerClient();

    const { data: row, error } = await client
      .from("patients")
      .select("*, diagnoses(*)")
      .eq("id", resolvedId)
      .is("deleted_at", null)
      .single();
    if (error || !row) return err("Pasien tidak ditemukan", 404);

    const [
      { data: anthropometry },
      { data: assessments },
      { data: weightRecords },
      { data: mealPlans },
      { data: exercisePlans },
      { data: foodRecords },
      { data: shoppingLists },
    ] = await Promise.all([
      client.from("anthropometry").select("*").eq("patient_id", resolvedId).order("recorded_at", { ascending: false }).limit(20),
      client.from("nutrition_assessments").select("*").eq("patient_id", resolvedId).order("recorded_at", { ascending: false }).limit(10),
      client.from("weight_records").select("*").eq("patient_id", resolvedId).order("date", { ascending: true }).limit(60),
      client.from("meal_plans").select("*, meal_plan_items(*, foods(*))").eq("patient_id", resolvedId).is("deleted_at", null).order("date", { ascending: false }).limit(10),
      client.from("exercise_plans").select("*, exercise_items(*)").eq("patient_id", resolvedId).is("deleted_at", null).order("date", { ascending: false }).limit(5),
      client.from("food_records").select("*, foods(*)").eq("patient_id", resolvedId).order("date", { ascending: false }).limit(50),
      client.from("shopping_lists").select("*, shopping_items(*, foods(*))").eq("patient_id", resolvedId).is("deleted_at", null).order("created_at", { ascending: false }).limit(5),
    ]);

    const patient = patientFromSupabase(row);
    patient.diagnoses = row.diagnoses || [];
    patient.anthropometry = anthropometry || [];
    patient.assessments = assessments || [];
    patient.weightRecords = weightRecords || [];
    patient.mealPlans = (mealPlans || []).map((mp: any) => ({
      ...mp,
      items: (mp.meal_plan_items || []).map((i: any) => ({ ...i, food: i.foods ? foodFromSupabase(i.foods) : null })),
    }));
    patient.exercisePlans = (exercisePlans || []).map((ep: any) => ({ ...ep, items: ep.exercise_items || [] }));
    patient.foodRecords = (foodRecords || []).map((r: any) => ({ ...r, food: r.foods ? foodFromSupabase(r.foods) : null }));
    patient.shoppingLists = (shoppingLists || []).map((sl: any) => ({
      ...sl,
      items: (sl.shopping_items || []).map((i: any) => ({ ...i, food: i.foods ? foodFromSupabase(i.foods) : null })),
    }));

    return ok(patient);
  } catch (e) {
    return handleZod(e);
  }
}

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const resolvedId = await resolvePatientId(id);
    const body = await req.json();
    const parsed = UpdateSchema.safeParse(body);
    if (!parsed.success) return handleZod(parsed.error);
    const d = parsed.data;

    const { data: updated, error } = await supabaseUpdatePatient(resolvedId, d);
    if (error) {
      if (error.includes("Authentication required")) return err(error, 401);
      return err(error, 500);
    }

    if (d.weight && d.height) {
      const bmi = d.weight / Math.pow(d.height / 100, 2);
      const cat = bmi < 18.5 ? "UNDERWEIGHT" : bmi < 23 ? "NORMAL" : bmi < 25 ? "OVERWEIGHT" : "OBESE";
      const { client } = await getServerClient();
      await client.from("anthropometry").insert({
        patient_id: resolvedId,
        weight: d.weight,
        height: d.height,
        bmi: Math.round(bmi * 10) / 10,
        bmi_category: cat,
      });
      await client.from("weight_records").insert({
        patient_id: resolvedId,
        weight: d.weight,
        date: new Date().toISOString(),
      });
    }
    return ok(updated);
  } catch (e) {
    return handleZod(e);
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const resolvedId = await resolvePatientId(id);
    const { error } = await supabaseSoftDeletePatient(resolvedId);
    if (error) return err(error, 500);
    return ok({ id, deleted: true });
  } catch (e) {
    return handleZod(e);
  }
}
