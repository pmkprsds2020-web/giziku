import { NextRequest } from "next/server";
import { ok, err, handleZod, safeParse } from "@/lib/api-helpers";
import { z } from "zod";
import { getServerClient, foodFromSupabase, resolveFoodId } from "@/lib/supabase/data-layer";

const TRACKED_FIELDS = [
  "name", "englishName", "alias", "code", "description", "source",
  "energy", "protein", "fat", "carb", "fiber", "water", "ash",
  "sodium", "potassium", "calcium", "magnesium", "iron", "phosphorus", "zinc",
  "vitA", "vitB1", "vitB2", "vitB6", "vitB12", "vitC", "vitD", "vitE", "vitK",
  "cholesterol", "gi", "urt", "urtGram", "bdd", "unit", "imageUrl", "tags",
] as const;

const FIELD_MAP: Record<string, string> = {
  englishName: "english_name", vitA: "vit_a", vitB1: "vit_b1", vitB2: "vit_b2",
  vitB6: "vit_b6", vitB12: "vit_b12", vitC: "vit_c", vitD: "vit_d", vitE: "vit_e",
  vitK: "vit_k", urtGram: "urt_gram", imageUrl: "image_url",
};

const UpdateSchema = z.object({
  name: z.string().min(1).optional(),
  englishName: z.string().optional().nullable(),
  alias: z.string().optional().nullable(),
  code: z.string().optional().nullable(),
  categoryId: z.string().optional(),
  subcategoryId: z.string().optional().nullable(),
  description: z.string().optional().nullable(),
  source: z.enum(["TKPI", "DKBM", "USDA", "CUSTOM"]).optional(),
  energy: z.number().min(0).optional(),
  protein: z.number().min(0).optional(),
  fat: z.number().min(0).optional(),
  carb: z.number().min(0).optional(),
  fiber: z.number().min(0).optional(),
  water: z.number().min(0).optional(),
  ash: z.number().min(0).optional(),
  sodium: z.number().min(0).optional(),
  potassium: z.number().min(0).optional(),
  calcium: z.number().min(0).optional(),
  magnesium: z.number().min(0).optional(),
  iron: z.number().min(0).optional(),
  phosphorus: z.number().min(0).optional(),
  zinc: z.number().min(0).optional(),
  vitA: z.number().min(0).optional(),
  vitB1: z.number().min(0).optional(),
  vitB2: z.number().min(0).optional(),
  vitB6: z.number().min(0).optional(),
  vitB12: z.number().min(0).optional(),
  vitC: z.number().min(0).optional(),
  vitD: z.number().min(0).optional(),
  vitE: z.number().min(0).optional(),
  vitK: z.number().min(0).optional(),
  cholesterol: z.number().min(0).optional(),
  gi: z.number().min(0).max(100).optional(),
  urt: z.string().optional().nullable(),
  urtGram: z.number().optional().nullable(),
  bdd: z.number().min(0).max(100).optional(),
  unit: z.string().optional(),
  imageUrl: z.string().optional().nullable(),
  tags: z.string().optional(),
  approved: z.boolean().optional(),
});

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id: rawId } = await params;
    const id = await resolveFoodId(rawId);
    const body = await req.json();
    const parsed = safeParse(UpdateSchema, body);
    if (!parsed.success) return handleZod(parsed.error);
    const d = parsed.data;

    const { client } = await getServerClient();
    const { data: existingRow, error: fetchError } = await client
      .from("foods")
      .select("*")
      .eq("id", id)
      .single();
    if (fetchError || !existingRow || existingRow.deleted_at) return err("Makanan tidak ditemukan", 404);
    const existing = foodFromSupabase(existingRow);

    // Track changes
    const changes: Record<string, { from: any; to: any }> = {};
    for (const field of TRACKED_FIELDS) {
      if ((d as any)[field] !== undefined && (d as any)[field] !== (existing as any)[field]) {
        changes[field] = { from: (existing as any)[field], to: (d as any)[field] };
      }
    }

    const updatePayload: Record<string, any> = { version: (existing.version || 1) + 1 };
    for (const [key, value] of Object.entries(d)) {
      if (value === undefined) continue;
      const column = FIELD_MAP[key] || key.replace(/[A-Z]/g, (m) => `_${m.toLowerCase()}`);
      updatePayload[column] = value;
    }

    const { data: updatedRow, error: updateError } = await client
      .from("foods")
      .update(updatePayload)
      .eq("id", id)
      .select("*, food_categories(*)")
      .single();
    if (updateError) return err(updateError.message, 500);

    if (Object.keys(changes).length > 0) {
      const { error: logError } = await client.from("food_change_logs").insert({
        food_id: id,
        action: "UPDATE",
        changes,
        actor: "admin",
      });
      if (logError) console.error("[foods PUT] Failed to log change:", logError);
    }

    return ok(foodFromSupabase(updatedRow, updatedRow.food_categories));
  } catch (e) {
    return handleZod(e);
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id: rawId } = await params;
    const id = await resolveFoodId(rawId);
    const { client } = await getServerClient();
    const { data: existing, error: fetchError } = await client
      .from("foods")
      .select("id, name, deleted_at")
      .eq("id", id)
      .single();
    if (fetchError || !existing || existing.deleted_at) return err("Makanan tidak ditemukan", 404);

    const { error } = await client
      .from("foods")
      .update({ deleted_at: new Date().toISOString() })
      .eq("id", id);
    if (error) return err(error.message, 500);

    const { error: logError } = await client.from("food_change_logs").insert({
      food_id: id,
      action: "DELETE",
      changes: { name: { from: existing.name, to: null } },
      actor: "admin",
    });
    if (logError) console.error("[foods DELETE] Failed to log change:", logError);

    return ok({ id, deleted: true });
  } catch (e) {
    return handleZod(e);
  }
}
