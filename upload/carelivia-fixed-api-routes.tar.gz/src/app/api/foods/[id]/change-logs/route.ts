import { NextRequest } from "next/server";
import { ok, handleZod } from "@/lib/api-helpers";
import { getServerClient, resolveFoodId } from "@/lib/supabase/data-layer";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id: rawId } = await params;
    const id = await resolveFoodId(rawId);
    const { client } = await getServerClient();
    const { data, error } = await client
      .from("food_change_logs")
      .select("*")
      .eq("food_id", id)
      .order("created_at", { ascending: false })
      .limit(50);
    if (error) return ok([]);
    return ok(
      (data || []).map((l: any) => ({
        id: l.id,
        foodId: l.food_id,
        action: l.action,
        changes: l.changes ?? null,
        actor: l.actor,
        createdAt: l.created_at,
      })),
    );
  } catch (e) {
    return handleZod(e);
  }
}
