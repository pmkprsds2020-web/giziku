import { NextRequest } from "next/server";
import { ok, err, handleZod, safeParse } from "@/lib/api-helpers";
import { z } from "zod";
import { getServerClient, resolveFoodId } from "@/lib/supabase/data-layer";

const UpdatePriceSchema = z.object({
  price: z.number().min(0),
  unit: z.string().optional().default("g"),
  location: z.string().optional().nullable(),
  source: z.string().optional().nullable(),
  notes: z.string().optional().nullable(),
});

function mapHistory(row: any) {
  return {
    id: row.id,
    foodId: row.food_id,
    price: row.price,
    previousPrice: row.previous_price,
    unit: row.unit,
    location: row.location,
    source: row.source,
    notes: row.notes,
    actor: row.actor,
    createdAt: row.created_at,
  };
}

// GET price history for a food
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id: rawId } = await params;
    const id = await resolveFoodId(rawId);
    const { client } = await getServerClient();
    const { data, error } = await client
      .from("food_price_history")
      .select("*")
      .eq("food_id", id)
      .order("created_at", { ascending: false })
      .limit(100);
    if (error) return err(error.message, 500);
    return ok((data || []).map(mapHistory));
  } catch (e) {
    return handleZod(e);
  }
}

// POST — update price (creates history entry + updates food.price)
export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id: rawId } = await params;
    const id = await resolveFoodId(rawId);
    const body = await req.json();
    const parsed = safeParse(UpdatePriceSchema, body);
    if (!parsed.success) return handleZod(parsed.error);
    const d = parsed.data;

    const { client } = await getServerClient();
    const { data: food, error: fetchError } = await client
      .from("foods")
      .select("id, price, deleted_at")
      .eq("id", id)
      .single();
    if (fetchError || !food || food.deleted_at) return err("Makanan tidak ditemukan", 404);

    const previousPrice = food.price;
    const priceChange = d.price - previousPrice;
    const priceChangePct = previousPrice > 0 ? Math.round((priceChange / previousPrice) * 100) : 0;

    const { data: historyRow, error: historyError } = await client
      .from("food_price_history")
      .insert({
        food_id: id,
        price: d.price,
        previous_price: previousPrice,
        unit: d.unit,
        location: d.location || null,
        source: d.source || null,
        notes: d.notes || null,
        actor: "admin",
      })
      .select()
      .single();
    if (historyError) return err(historyError.message, 500);

    const { error: updateError } = await client
      .from("foods")
      .update({
        price: d.price,
        price_unit: d.unit,
        price_location: d.location || null,
        price_source: d.source || null,
        price_updated_at: new Date().toISOString(),
        price_is_estimate: false,
      })
      .eq("id", id);
    if (updateError) return err(updateError.message, 500);

    const { error: logError } = await client.from("food_change_logs").insert({
      food_id: id,
      action: "UPDATE",
      changes: { price: { from: previousPrice, to: d.price }, priceChangePct },
      actor: "admin",
    });
    if (logError) console.error("[foods prices POST] Failed to log change:", logError);

    return ok({
      history: mapHistory(historyRow),
      previousPrice,
      newPrice: d.price,
      priceChange,
      priceChangePct,
      alert: priceChangePct > 20 ? `Harga naik ${priceChangePct}%` : priceChangePct < -20 ? `Harga turun ${Math.abs(priceChangePct)}%` : null,
    });
  } catch (e) {
    return handleZod(e);
  }
}
