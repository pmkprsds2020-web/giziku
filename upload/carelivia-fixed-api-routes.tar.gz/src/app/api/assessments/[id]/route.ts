import { NextRequest } from "next/server";
import { ok, err, handleZod } from "@/lib/api-helpers";
import { getServerClient } from "@/lib/supabase/data-layer";

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const { client } = await getServerClient();
    const { data: existing, error: fetchError } = await client
      .from("nutrition_assessments")
      .select("id")
      .eq("id", id)
      .maybeSingle();
    if (fetchError || !existing) return err("Asesmen tidak ditemukan", 404);

    const { error } = await client.from("nutrition_assessments").delete().eq("id", id);
    if (error) return err(error.message, 500);

    return ok({ id, deleted: true });
  } catch (e) {
    return handleZod(e);
  }
}
