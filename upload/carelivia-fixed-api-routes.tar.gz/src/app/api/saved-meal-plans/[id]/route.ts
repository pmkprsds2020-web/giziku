import { NextRequest } from "next/server";
import { ok, err, handleZod } from "@/lib/api-helpers";
import { getServerClient, foodFromSupabase } from "@/lib/supabase/data-layer";

function mapPlan(row: any) {
  return {
    id: row.id,
    patientId: row.patient_id,
    name: row.name,
    totalCal: row.total_cal,
    totalProtein: row.total_protein,
    totalFat: row.total_fat,
    totalCarb: row.total_carb,
    totalFiber: row.total_fiber,
    totalSodium: row.total_sodium,
    totalPotassium: row.total_potassium,
    compliance: row.compliance,
    notes: row.notes,
    useCount: row.use_count,
    lastUsedAt: row.last_used_at,
    deletedAt: row.deleted_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    items: (row.saved_meal_plan_items || []).map((i: any) => ({
      id: i.id,
      savedMealPlanId: i.saved_meal_plan_id,
      slot: i.slot,
      foodId: i.food_id,
      amount: i.amount,
      cal: i.cal,
      protein: i.protein,
      fat: i.fat,
      carb: i.carb,
      fiber: i.fiber,
      sodium: i.sodium,
      potassium: i.potassium,
      foodName: i.food_name,
      urt: i.urt,
      food: i.foods ? foodFromSupabase(i.foods, i.foods.food_categories) : null,
    })),
  };
}

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const { client } = await getServerClient();
    const { data, error } = await client
      .from("saved_meal_plans")
      .select("*, saved_meal_plan_items(*, foods(*, food_categories(*)))")
      .eq("id", id)
      .is("deleted_at", null)
      .single();
    if (error || !data) return err("Meal plan tidak ditemukan", 404);
    return ok(mapPlan(data));
  } catch (e) {
    return handleZod(e);
  }
}

// Mark as used
export async function PATCH(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const { client } = await getServerClient();
    const { data: existing, error: fetchError } = await client
      .from("saved_meal_plans")
      .select("use_count, deleted_at")
      .eq("id", id)
      .single();
    if (fetchError || !existing || existing.deleted_at) return err("Meal plan tidak ditemukan", 404);

    const { data: updated, error } = await client
      .from("saved_meal_plans")
      .update({ use_count: (existing.use_count || 0) + 1, last_used_at: new Date().toISOString() })
      .eq("id", id)
      .select()
      .single();
    if (error) return err(error.message, 500);

    return ok(mapPlan(updated));
  } catch (e) {
    return handleZod(e);
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const { client } = await getServerClient();
    const { data: existing, error: fetchError } = await client
      .from("saved_meal_plans")
      .select("id, deleted_at")
      .eq("id", id)
      .single();
    if (fetchError || !existing || existing.deleted_at) return err("Meal plan tidak ditemukan", 404);

    const { error } = await client
      .from("saved_meal_plans")
      .update({ deleted_at: new Date().toISOString() })
      .eq("id", id);
    if (error) return err(error.message, 500);

    return ok({ id, deleted: true });
  } catch (e) {
    return handleZod(e);
  }
}
