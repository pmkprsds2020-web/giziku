import { NextRequest } from "next/server";
import { ok, err, handleZod } from "@/lib/api-helpers";
import { getServerClient } from "@/lib/supabase/data-layer";

// GET /api/database-browser?table=patients&page=1&limit=10&q=search
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const table = searchParams.get("table") || "patients";
    const page = Number(searchParams.get("page") || 1);
    const limit = Number(searchParams.get("limit") || 10);
    const q = searchParams.get("q") || "";
    const offset = (page - 1) * limit;

    const { client } = await getServerClient();
    let query: any;
    let countQuery: any;

    switch (table) {
      case "patients":
        query = client.from("patients").select("*").is("deleted_at", null);
        countQuery = client.from("patients").select("id", { count: "exact", head: true }).is("deleted_at", null);
        if (q) { query = query.ilike("name", `%${q}%`); countQuery = countQuery.ilike("name", `%${q}%`); }
        query = query.order("created_at", { ascending: false });
        break;
      case "foods":
        query = client.from("foods").select("*").is("deleted_at", null);
        countQuery = client.from("foods").select("id", { count: "exact", head: true }).is("deleted_at", null);
        if (q) { query = query.ilike("name", `%${q}%`); countQuery = countQuery.ilike("name", `%${q}%`); }
        query = query.order("name", { ascending: true });
        break;
      case "meal_plans":
        query = client.from("meal_plans").select("*, patients(name, mrn)").is("deleted_at", null).order("date", { ascending: false });
        countQuery = client.from("meal_plans").select("id", { count: "exact", head: true }).is("deleted_at", null);
        break;
      case "food_records":
        query = client.from("food_records").select("*, patients(name), foods(name)").order("date", { ascending: false });
        countQuery = client.from("food_records").select("id", { count: "exact", head: true });
        break;
      case "weight_records":
        query = client.from("weight_records").select("*, patients(name)").order("date", { ascending: false });
        countQuery = client.from("weight_records").select("id", { count: "exact", head: true });
        break;
      case "nutrition_assessments":
        query = client.from("nutrition_assessments").select("*, patients(name)").order("recorded_at", { ascending: false });
        countQuery = client.from("nutrition_assessments").select("id", { count: "exact", head: true });
        break;
      case "nutrition_presets":
        query = client.from("nutrition_presets").select("*").is("deleted_at", null).order("created_at", { ascending: false });
        countQuery = client.from("nutrition_presets").select("id", { count: "exact", head: true }).is("deleted_at", null);
        break;
      case "recipes":
        query = client.from("recipes").select("*, recipe_items(id)").is("deleted_at", null).order("created_at", { ascending: false });
        countQuery = client.from("recipes").select("id", { count: "exact", head: true }).is("deleted_at", null);
        break;
      case "exercise_plans":
        query = client.from("exercise_plans").select("*, patients(name), exercise_items(id)").is("deleted_at", null).order("date", { ascending: false });
        countQuery = client.from("exercise_plans").select("id", { count: "exact", head: true }).is("deleted_at", null);
        break;
      case "saved_meal_plans":
        query = client.from("saved_meal_plans").select("*").is("deleted_at", null).order("created_at", { ascending: false });
        countQuery = client.from("saved_meal_plans").select("id", { count: "exact", head: true }).is("deleted_at", null);
        break;
      case "shopping_lists":
        query = client.from("shopping_lists").select("*, patients(name)").is("deleted_at", null).order("created_at", { ascending: false });
        countQuery = client.from("shopping_lists").select("id", { count: "exact", head: true }).is("deleted_at", null);
        break;
      case "audit_logs":
        query = client.from("audit_logs").select("*").order("created_at", { ascending: false });
        countQuery = client.from("audit_logs").select("id", { count: "exact", head: true });
        break;
      default:
        return err("Table not supported", 400);
    }

    const { count: total } = await countQuery;
    const { data, error } = await query.range(offset, offset + limit - 1);
    if (error) return err(error.message, 500);

    const totalPages = Math.ceil((total || 0) / limit);

    return ok({
      table,
      data: data || [],
      pagination: {
        page,
        limit,
        total: total || 0,
        totalPages,
        hasNext: page < totalPages,
        hasPrev: page > 1,
      },
    });
  } catch (e) {
    return handleZod(e);
  }
}
