import { ok, handleZod, ageFromBirth } from "@/lib/api-helpers";
import { getServerClient } from "@/lib/supabase/data-layer";

export async function GET() {
  try {
    const { client } = await getServerClient();

    const { data: patients } = await client
      .from("patients")
      .select("*, diagnoses(*), meal_plans(id, date, compliance), weight_records(date, weight)")
      .is("deleted_at", null);

    const patientList = patients || [];
    const totalPatients = patientList.length;

    const { count: activeMealPlans } = await client
      .from("meal_plans")
      .select("id", { count: "exact", head: true })
      .is("deleted_at", null)
      .eq("status", "FINAL");

    const { count: totalFoods } = await client
      .from("foods")
      .select("id", { count: "exact", head: true })
      .is("deleted_at", null);

    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);
    const { data: todaysRecords } = await client
      .from("food_records")
      .select("cal, consumed")
      .gte("date", todayStart.toISOString());

    const todayCalTotal = (todaysRecords || []).reduce(
      (s: number, r: any) => s + r.cal * (r.consumed / 100),
      0,
    );

    const { data: recentPlans } = await client
      .from("meal_plans")
      .select("*, patients(name)")
      .order("date", { ascending: false })
      .limit(8);

    const allDiagnoses = (patientList as any[]).flatMap((p) => (p.diagnoses || []).filter((d: any) => d.active));
    const diagCounts: Record<string, number> = {};
    allDiagnoses.forEach((d: any) => {
      diagCounts[d.type] = (diagCounts[d.type] || 0) + 1;
    });

    const patientSummaries = patientList.map((p: any) => {
      const bmi = p.height && p.weight && p.height > 0 ? p.weight / Math.pow(p.height / 100, 2) : null;
      const mealPlans = (p.meal_plans || []).sort(
        (a: any, b: any) => new Date(b.date).getTime() - new Date(a.date).getTime(),
      );
      const latestPlan = mealPlans[0];
      const weightRecords = (p.weight_records || []).sort(
        (a: any, b: any) => new Date(a.date).getTime() - new Date(b.date).getTime(),
      );
      return {
        id: p.id,
        name: p.name,
        mrn: p.mrn,
        ageYears: ageFromBirth(p.birth_date),
        gender: p.gender,
        bmi: bmi ? Math.round(bmi * 10) / 10 : null,
        weight: p.weight,
        diagnoses: (p.diagnoses || []).filter((d: any) => d.active).map((d: any) => d.type),
        latestCompliance: latestPlan?.compliance ?? null,
        weightTrend: weightRecords.slice(-7).map((w: any) => ({
          date: new Date(w.date).toISOString(),
          weight: w.weight,
        })),
      };
    });

    return ok({
      totalPatients,
      activeMealPlans: activeMealPlans || 0,
      totalFoods: totalFoods || 0,
      todayCalTotal: Math.round(todayCalTotal),
      todayRecords: (todaysRecords || []).length,
      recentPlans: (recentPlans || []).map((mp: any) => ({
        id: mp.id,
        patientName: mp.patients?.name || "",
        date: new Date(mp.date).toISOString(),
        targetCal: mp.target_cal,
        totalCal: mp.total_cal,
        compliance: mp.compliance,
        status: mp.status,
      })),
      diagnosisDistribution: diagCounts,
      patientSummaries,
    });
  } catch (e) {
    return handleZod(e);
  }
}
