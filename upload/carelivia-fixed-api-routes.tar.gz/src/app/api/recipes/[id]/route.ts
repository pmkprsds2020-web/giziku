import { NextRequest } from "next/server";
import { ok, err, handleZod, safeParse } from "@/lib/api-helpers";
import { z } from "zod";
import { getServerClient, foodFromSupabase } from "@/lib/supabase/data-layer";

const UpdateSchema = z.object({
  name: z.string().min(1).optional(),
  description: z.string().optional(),
  servings: z.number().min(1).max(50).optional(),
  method: z.string().optional(),
  imageUrl: z.string().optional().nullable(),
  items: z
    .array(
      z.object({
        foodId: z.string().min(1),
        amount: z.number().min(0.1).max(5000),
      }),
    )
    .optional(),
});

function mapRecipe(row: any) {
  return {
    id: row.id,
    name: row.name,
    description: row.description,
    servings: row.servings,
    method: row.method,
    imageUrl: row.image_url,
    deletedAt: row.deleted_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    items: (row.recipe_items || []).map((ri: any) => ({
      id: ri.id,
      recipeId: ri.recipe_id,
      foodId: ri.food_id,
      amount: ri.amount,
      food: ri.foods ? foodFromSupabase(ri.foods, ri.foods.food_categories) : null,
    })),
  };
}

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const { client } = await getServerClient();
    const { data, error } = await client
      .from("recipes")
      .select("*, recipe_items(*, foods(*, food_categories(*)))")
      .eq("id", id)
      .is("deleted_at", null)
      .single();
    if (error || !data) return err("Resep tidak ditemukan", 404);
    return ok(mapRecipe(data));
  } catch (e) {
    return handleZod(e);
  }
}

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const body = await req.json();
    const parsed = safeParse(UpdateSchema, body);
    if (!parsed.success) return handleZod(parsed.error);
    const d = parsed.data;

    const { client } = await getServerClient();
    const { data: existing, error: fetchError } = await client
      .from("recipes")
      .select("id, deleted_at")
      .eq("id", id)
      .single();
    if (fetchError || !existing || existing.deleted_at) return err("Resep tidak ditemukan", 404);

    if (d.items) {
      await client.from("recipe_items").delete().eq("recipe_id", id);
      const { error: itemsError } = await client.from("recipe_items").insert(
        d.items.map((it) => ({ recipe_id: id, food_id: it.foodId, amount: it.amount })),
      );
      if (itemsError) return err(itemsError.message, 500);
    }

    const updatePayload: Record<string, any> = {};
    if (d.name !== undefined) updatePayload.name = d.name;
    if (d.description !== undefined) updatePayload.description = d.description;
    if (d.servings !== undefined) updatePayload.servings = d.servings;
    if (d.method !== undefined) updatePayload.method = d.method;
    if (d.imageUrl !== undefined) updatePayload.image_url = d.imageUrl;

    if (Object.keys(updatePayload).length > 0) {
      const { error: updateError } = await client.from("recipes").update(updatePayload).eq("id", id);
      if (updateError) return err(updateError.message, 500);
    }

    const { data: fullRecipe } = await client
      .from("recipes")
      .select("*, recipe_items(*, foods(*, food_categories(*)))")
      .eq("id", id)
      .single();

    return ok(mapRecipe(fullRecipe));
  } catch (e) {
    return handleZod(e);
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const { client } = await getServerClient();
    const { data: existing, error: fetchError } = await client
      .from("recipes")
      .select("id, deleted_at")
      .eq("id", id)
      .single();
    if (fetchError || !existing || existing.deleted_at) return err("Resep tidak ditemukan", 404);

    const { error } = await client
      .from("recipes")
      .update({ deleted_at: new Date().toISOString() })
      .eq("id", id);
    if (error) return err(error.message, 500);

    return ok({ id, deleted: true });
  } catch (e) {
    return handleZod(e);
  }
}
