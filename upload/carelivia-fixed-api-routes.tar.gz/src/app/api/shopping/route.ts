import { NextRequest } from "next/server";
import { ok, err, handleZod } from "@/lib/api-helpers";
import { getServerClient, foodFromSupabase } from "@/lib/supabase/data-layer";

// ---------------------------------------------------------------------
// Shopping List Generator
// Aggregates ingredients from a meal plan, multiplies by period,
// merges duplicate foods, estimates price, finds cheaper alternatives.
// ---------------------------------------------------------------------
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { mealPlanId, period } = body as {
      mealPlanId?: string;
      period?: "DAILY" | "WEEKLY" | "MONTHLY";
    };
    if (!mealPlanId) return err("mealPlanId wajib diisi", 422);

    const { client } = await getServerClient();
    const { data: mealPlan, error: planError } = await client
      .from("meal_plans")
      .select("*, meal_plan_items(*, foods(*))")
      .eq("id", mealPlanId)
      .single();
    if (planError || !mealPlan) return err("Meal plan tidak ditemukan", 404);

    const multiplier = period === "MONTHLY" ? 30 : period === "WEEKLY" ? 7 : 1;

    // Aggregate foods
    const agg = new Map<string, { foodId: string; amount: number; food: any }>();
    for (const item of mealPlan.meal_plan_items || []) {
      const existing = agg.get(item.food_id);
      if (existing) {
        existing.amount += item.amount;
      } else {
        agg.set(item.food_id, { foodId: item.food_id, amount: item.amount, food: item.foods });
      }
    }

    // Find cheaper alternatives for items with price > 0
    const alternatives: {
      foodId: string;
      foodName: string;
      currentPrice: number;
      altName?: string;
      altPrice?: number;
    }[] = [];

    for (const [, entry] of agg) {
      if (entry.food && entry.food.price > 1000) {
        const { data: alt } = await client
          .from("foods")
          .select("name, price")
          .is("deleted_at", null)
          .neq("id", entry.foodId)
          .lt("price", entry.food.price)
          .gte("protein", entry.food.protein * 0.6)
          .order("price", { ascending: true })
          .limit(1)
          .maybeSingle();
        if (alt) {
          alternatives.push({
            foodId: entry.foodId,
            foodName: entry.food.name,
            currentPrice: entry.food.price,
            altName: alt.name,
            altPrice: alt.price,
          });
        }
      }
    }

    // Build shopping list items
    const itemsData = Array.from(agg.values()).map((entry) => {
      const totalAmount = entry.amount * multiplier;
      const estPrice = entry.food ? (totalAmount / 100) * entry.food.price : 0;
      return {
        food_id: entry.foodId,
        amount: Math.round(totalAmount),
        unit: "g",
        est_price: Math.round(estPrice),
      };
    });

    const totalEstimate = itemsData.reduce((s, i) => s + i.est_price, 0);

    // Delete existing shopping list for this meal plan
    await client.from("shopping_lists").delete().eq("meal_plan_id", mealPlanId);

    const { data: listRow, error: listError } = await client
      .from("shopping_lists")
      .insert({
        patient_id: mealPlan.patient_id,
        meal_plan_id: mealPlanId,
        period: period ?? "WEEKLY",
        multiplier,
        total_estimate: totalEstimate,
        currency: "IDR",
      })
      .select()
      .single();
    if (listError) return err(listError.message, 500);

    if (itemsData.length > 0) {
      const { error: itemsError } = await client
        .from("shopping_items")
        .insert(itemsData.map((i) => ({ ...i, shopping_list_id: listRow.id })));
      if (itemsError) return err(itemsError.message, 500);
    }

    const { data: fullList } = await client
      .from("shopping_lists")
      .select("*, shopping_items(*, foods(*))")
      .eq("id", listRow.id)
      .single();

    const shoppingList = {
      id: fullList.id,
      patientId: fullList.patient_id,
      mealPlanId: fullList.meal_plan_id,
      period: fullList.period,
      multiplier: fullList.multiplier,
      totalEstimate: fullList.total_estimate,
      currency: fullList.currency,
      checkedCount: fullList.checked_count,
      createdAt: fullList.created_at,
      updatedAt: fullList.updated_at,
      items: (fullList.shopping_items || []).map((i: any) => ({
        id: i.id,
        shoppingListId: i.shopping_list_id,
        foodId: i.food_id,
        amount: i.amount,
        unit: i.unit,
        estPrice: i.est_price,
        checked: i.checked,
        food: i.foods ? foodFromSupabase(i.foods) : null,
      })),
    };

    return ok({ shoppingList, alternatives, totalEstimate });
  } catch (e) {
    return handleZod(e);
  }
}
