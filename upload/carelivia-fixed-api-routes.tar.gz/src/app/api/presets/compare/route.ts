import { NextRequest } from "next/server";
import { ok, err, handleZod } from "@/lib/api-helpers";
import { getServerClient, presetFromSupabase } from "@/lib/supabase/data-layer";

// GET /api/presets/compare?ids=id1,id2,id3
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const idsParam = searchParams.get("ids") || "";
    const ids = idsParam.split(",").filter(Boolean);
    if (ids.length < 2) return err("Pilih minimal 2 preset untuk dibandingkan", 422);

    const { client } = await getServerClient();
    const { data, error } = await client
      .from("nutrition_presets")
      .select("*")
      .in("id", ids)
      .is("deleted_at", null);
    if (error) return err(error.message, 500);

    const presets = (data || []).map(presetFromSupabase);
    if (presets.length < 2) return err("Preset tidak ditemukan", 404);

    const rows = [
      { label: "Kalori (kcal)", key: "totalCal", values: presets.map((p) => p.totalCal) },
      { label: "Protein (%)", key: "proteinPct", values: presets.map((p) => p.proteinPct) },
      { label: "Protein (g)", key: "proteinG", values: presets.map((p) => p.proteinG) },
      { label: "Karbohidrat (%)", key: "carbPct", values: presets.map((p) => p.carbPct) },
      { label: "Karbohidrat (g)", key: "carbG", values: presets.map((p) => p.carbG) },
      { label: "Lemak (%)", key: "fatPct", values: presets.map((p) => p.fatPct) },
      { label: "Lemak (g)", key: "fatG", values: presets.map((p) => p.fatG) },
      { label: "Serat (g)", key: "fiberG", values: presets.map((p) => p.fiberG) },
      { label: "Natrium max (mg)", key: "sodiumMg", values: presets.map((p) => p.sodiumMg) },
      { label: "Kalium (mg)", key: "potassiumMg", values: presets.map((p) => p.potassiumMg ?? "—") },
      { label: "Cairan (ml)", key: "fluidMl", values: presets.map((p) => p.fluidMl ?? "—") },
      { label: "Tujuan", key: "goal", values: presets.map((p) => p.goal) },
    ];

    return ok({ presets, rows });
  } catch (e) {
    return handleZod(e);
  }
}
