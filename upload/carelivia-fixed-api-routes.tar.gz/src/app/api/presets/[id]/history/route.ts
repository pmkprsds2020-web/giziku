import { NextRequest } from "next/server";
import { ok, handleZod } from "@/lib/api-helpers";
import { getServerClient } from "@/lib/supabase/data-layer";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const { client } = await getServerClient();
    const { data, error } = await client
      .from("nutrition_preset_history")
      .select("*")
      .eq("preset_id", id)
      .order("created_at", { ascending: false })
      .limit(50);
    if (error) {
      console.warn("[presets history] Supabase failed, falling back to Prisma:", error.message);
      try {
        const { db } = await import("@/lib/db");
        const history = await db.nutritionPresetHistory.findMany({
          where: { presetId: id },
          orderBy: { createdAt: "desc" },
          take: 50,
        });
        return ok(history.map((h) => ({ ...h, changes: h.changes ? JSON.parse(h.changes) : null })));
      } catch {
        return ok([]);
      }
    }
    return ok(
      (data || []).map((h: any) => ({
        id: h.id,
        presetId: h.preset_id,
        changes: h.changes,
        version: h.version,
        actor: h.actor,
        reason: h.reason,
        createdAt: h.created_at,
      })),
    );
  } catch (e) {
    return handleZod(e);
  }
}
