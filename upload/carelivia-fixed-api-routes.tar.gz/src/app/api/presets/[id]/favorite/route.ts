import { NextRequest } from "next/server";
import { ok, err, handleZod } from "@/lib/api-helpers";
import { getServerClient } from "@/lib/supabase/data-layer";

export async function POST(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const { client } = await getServerClient();
    const { data: existing, error: fetchError } = await client
      .from("nutrition_presets")
      .select("*")
      .eq("id", id)
      .is("deleted_at", null)
      .single();
    if (fetchError || !existing) return err("Preset tidak ditemukan", 404);

    const newFavorite = !existing.is_favorite;
    const { data: updated, error: updateError } = await client
      .from("nutrition_presets")
      .update({ is_favorite: newFavorite })
      .eq("id", id)
      .select()
      .single();
    if (updateError) return err(updateError.message, 500);

    const { error: histError } = await client.from("nutrition_preset_history").insert({
      preset_id: id,
      changes: { isFavorite: { from: existing.is_favorite, to: newFavorite } },
      version: existing.version,
      actor: "doctor",
      reason: newFavorite ? "Ditandai sebagai favorit" : "Dihapus dari favorit",
    });
    if (histError) console.error("[presets favorite] Failed to log history:", histError);

    return ok({ id, isFavorite: updated.is_favorite });
  } catch (e) {
    return handleZod(e);
  }
}
