import { NextRequest } from "next/server";
import { ok, err, handleZod } from "@/lib/api-helpers";
import { z } from "zod";
import { getServerClient, presetFromSupabase } from "@/lib/supabase/data-layer";

const CloneSchema = z.object({
  newName: z.string().optional(),
  patientId: z.string().optional().nullable(),
});

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const body = await req.json().catch(() => ({}));
    const parsed = CloneSchema.safeParse(body);
    if (!parsed.success) return handleZod(parsed.error);
    const d = parsed.data;

    const { client, session } = await getServerClient();
    if (!session) return err("Authentication required.", 401);

    const { data: sourceRow, error: fetchError } = await client
      .from("nutrition_presets")
      .select("*")
      .eq("id", id)
      .is("deleted_at", null)
      .single();
    if (fetchError || !sourceRow) return err("Preset sumber tidak ditemukan", 404);
    const source = presetFromSupabase(sourceRow);

    const { data: cloneRow, error: cloneError } = await client
      .from("nutrition_presets")
      .insert({
        patient_id: d.patientId !== undefined ? d.patientId : source.patientId,
        name: d.newName || `${source.name} (Salinan)`,
        description: source.description,
        color: source.color,
        icon: source.icon,
        is_template: false,
        is_favorite: false,
        total_cal: source.totalCal,
        target_weight: source.targetWeight,
        bmr: source.bmr,
        tdee: source.tdee,
        protein_pct: source.proteinPct,
        carb_pct: source.carbPct,
        fat_pct: source.fatPct,
        protein_g: source.proteinG,
        carb_g: source.carbG,
        fat_g: source.fatG,
        fiber_g: source.fiberG,
        sodium_mg: source.sodiumMg,
        potassium_mg: source.potassiumMg,
        fluid_ml: source.fluidMl,
        goal: source.goal,
        diagnoses: source.diagnoses,
        version: 1,
        created_by: "doctor",
        updated_by: "doctor",
      })
      .select()
      .single();
    if (cloneError) return err(cloneError.message, 500);

    const { error: histError } = await client.from("nutrition_preset_history").insert({
      preset_id: cloneRow.id,
      changes: { action: "CLONE", sourcePresetId: id, sourceName: source.name },
      version: 1,
      actor: "doctor",
      reason: `Duplikat dari "${source.name}"`,
    });
    if (histError) console.error("[presets clone] Failed to log history:", histError);

    return ok(presetFromSupabase(cloneRow), 201);
  } catch (e) {
    return handleZod(e);
  }
}
