import { NextRequest } from "next/server";
import { ok, err, handleZod, safeParse } from "@/lib/api-helpers";
import { z } from "zod";
import { getServerClient, presetFromSupabase } from "@/lib/supabase/data-layer";

const KCAL_PER_GRAM = { protein: 4, carb: 4, fat: 9 };

function computeGrams(totalCal: number, proteinPct: number, carbPct: number, fatPct: number) {
  const proteinKcal = (totalCal * proteinPct) / 100;
  const carbKcal = (totalCal * carbPct) / 100;
  const fatKcal = (totalCal * fatPct) / 100;
  return {
    proteinG: Math.round((proteinKcal / KCAL_PER_GRAM.protein) * 10) / 10,
    carbG: Math.round((carbKcal / KCAL_PER_GRAM.carb) * 10) / 10,
    fatG: Math.round((fatKcal / KCAL_PER_GRAM.fat) * 10) / 10,
  };
}

const TRACKED_FIELDS = [
  "name", "description", "color", "totalCal", "proteinPct", "carbPct", "fatPct",
  "fiberG", "sodiumMg", "potassiumMg", "fluidMl", "goal", "diagnoses", "isFavorite",
] as const;

const UpdateSchema = z.object({
  name: z.string().min(1).optional(),
  description: z.string().optional(),
  color: z.string().optional(),
  icon: z.string().optional(),
  totalCal: z.number().min(500).max(6000).optional(),
  targetWeight: z.number().optional().nullable(),
  bmr: z.number().optional().nullable(),
  tdee: z.number().optional().nullable(),
  proteinPct: z.number().min(5).max(60).optional(),
  carbPct: z.number().min(10).max(80).optional(),
  fatPct: z.number().min(10).max(60).optional(),
  fiberG: z.number().optional(),
  sodiumMg: z.number().optional(),
  potassiumMg: z.number().optional().nullable(),
  fluidMl: z.number().optional().nullable(),
  goal: z
    .enum(["WEIGHT_LOSS", "WEIGHT_MAINTAIN", "WEIGHT_GAIN", "HIGH_PROTEIN", "LOW_CARB", "LOW_FAT", "CKD_DIET", "DIABETES_DIET", "HYPERTENSION_DIET", "GENERAL"])
    .optional(),
  diagnoses: z.string().optional(),
  isFavorite: z.boolean().optional(),
  reason: z.string().optional(),
});

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const { client } = await getServerClient();
    const { data: row, error } = await client
      .from("nutrition_presets")
      .select("*")
      .eq("id", id)
      .is("deleted_at", null)
      .single();
    if (error || !row) return err("Preset tidak ditemukan", 404);

    const { data: history } = await client
      .from("nutrition_preset_history")
      .select("*")
      .eq("preset_id", id)
      .order("created_at", { ascending: false })
      .limit(20);

    const { count } = await client
      .from("meal_plans")
      .select("id", { count: "exact", head: true })
      .eq("preset_id", id);

    const preset = presetFromSupabase(row);
    preset.history = (history || []).map((h: any) => ({
      id: h.id,
      presetId: h.preset_id,
      changes: h.changes,
      version: h.version,
      actor: h.actor,
      reason: h.reason,
      createdAt: h.created_at,
    }));
    preset._count = { mealPlans: count || 0 };

    return ok(preset);
  } catch (e) {
    return handleZod(e);
  }
}

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const body = await req.json();
    const parsed = safeParse(UpdateSchema, body);
    if (!parsed.success) return handleZod(parsed.error);
    const d = parsed.data;

    const { client } = await getServerClient();
    const { data: existingRow, error: fetchError } = await client
      .from("nutrition_presets")
      .select("*")
      .eq("id", id)
      .is("deleted_at", null)
      .single();
    if (fetchError || !existingRow) return err("Preset tidak ditemukan", 404);
    const existing = presetFromSupabase(existingRow);

    const newProtein = d.proteinPct ?? existing.proteinPct;
    const newCarb = d.carbPct ?? existing.carbPct;
    const newFat = d.fatPct ?? existing.fatPct;
    const macroSum = newProtein + newCarb + newFat;
    if (Math.abs(macroSum - 100) > 10) {
      return err(`Total persentase makronutrien harus ~100% (saat ini ${macroSum}%)`, 422);
    }

    const newTotalCal = d.totalCal ?? existing.totalCal;
    const grams = computeGrams(newTotalCal, newProtein, newCarb, newFat);

    const changes: Record<string, { from: any; to: any }> = {};
    for (const field of TRACKED_FIELDS) {
      if ((d as any)[field] !== undefined && (d as any)[field] !== (existing as any)[field]) {
        changes[field] = { from: (existing as any)[field], to: (d as any)[field] };
      }
    }

    const updatePayload: Record<string, any> = {
      protein_g: grams.proteinG,
      carb_g: grams.carbG,
      fat_g: grams.fatG,
      version: (existing.version || 1) + 1,
      updated_by: "doctor",
    };
    if (d.name !== undefined) updatePayload.name = d.name;
    if (d.description !== undefined) updatePayload.description = d.description;
    if (d.color !== undefined) updatePayload.color = d.color;
    if (d.icon !== undefined) updatePayload.icon = d.icon;
    if (d.totalCal !== undefined) updatePayload.total_cal = d.totalCal;
    if (d.targetWeight !== undefined) updatePayload.target_weight = d.targetWeight;
    if (d.bmr !== undefined) updatePayload.bmr = d.bmr;
    if (d.tdee !== undefined) updatePayload.tdee = d.tdee;
    if (d.proteinPct !== undefined) updatePayload.protein_pct = d.proteinPct;
    if (d.carbPct !== undefined) updatePayload.carb_pct = d.carbPct;
    if (d.fatPct !== undefined) updatePayload.fat_pct = d.fatPct;
    if (d.fiberG !== undefined) updatePayload.fiber_g = d.fiberG;
    if (d.sodiumMg !== undefined) updatePayload.sodium_mg = d.sodiumMg;
    if (d.potassiumMg !== undefined) updatePayload.potassium_mg = d.potassiumMg;
    if (d.fluidMl !== undefined) updatePayload.fluid_ml = d.fluidMl;
    if (d.goal !== undefined) updatePayload.goal = d.goal;
    if (d.diagnoses !== undefined) updatePayload.diagnoses = d.diagnoses;
    if (d.isFavorite !== undefined) updatePayload.is_favorite = d.isFavorite;

    const { data: updatedRow, error: updateError } = await client
      .from("nutrition_presets")
      .update(updatePayload)
      .eq("id", id)
      .select()
      .single();
    if (updateError) return err(updateError.message, 500);

    if (Object.keys(changes).length > 0) {
      const { error: histError } = await client.from("nutrition_preset_history").insert({
        preset_id: id,
        changes,
        version: updatedRow.version,
        actor: "doctor",
        reason: d.reason || "Preset diperbarui",
      });
      if (histError) console.error("[presets PUT] Failed to log history:", histError);
    }

    return ok(presetFromSupabase(updatedRow));
  } catch (e) {
    return handleZod(e);
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const { client } = await getServerClient();
    const { data: existingRow, error: fetchError } = await client
      .from("nutrition_presets")
      .select("*")
      .eq("id", id)
      .is("deleted_at", null)
      .single();
    if (fetchError || !existingRow) return err("Preset tidak ditemukan", 404);

    const { error: updateError } = await client
      .from("nutrition_presets")
      .update({ deleted_at: new Date().toISOString() })
      .eq("id", id);
    if (updateError) return err(updateError.message, 500);

    const { error: histError } = await client.from("nutrition_preset_history").insert({
      preset_id: id,
      changes: { action: "DELETE" },
      version: existingRow.version,
      actor: "doctor",
      reason: "Preset dihapus (soft delete)",
    });
    if (histError) console.error("[presets DELETE] Failed to log history:", histError);

    return ok({ id, deleted: true });
  } catch (e) {
    return handleZod(e);
  }
}
