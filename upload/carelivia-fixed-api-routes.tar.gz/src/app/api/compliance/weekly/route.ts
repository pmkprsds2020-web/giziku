import { NextRequest } from "next/server";
import { ok, err, handleZod } from "@/lib/api-helpers";
import { getServerClient, resolvePatientId } from "@/lib/supabase/data-layer";

// GET /api/compliance/weekly?patientId=xxx
// Returns 7-day compliance history: for each day, total intake vs latest meal plan target
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const patientId = searchParams.get("patientId");
    if (!patientId) return err("patientId wajib diisi", 422);

    const resolvedId = await resolvePatientId(patientId);
    const { client } = await getServerClient();

    const { data: latestPlan } = await client
      .from("meal_plans")
      .select("*, nutrition_presets(name)")
      .eq("patient_id", resolvedId)
      .is("deleted_at", null)
      .order("date", { ascending: false })
      .limit(1)
      .maybeSingle();

    if (!latestPlan) return ok({ hasPlan: false, days: [] });

    const target = {
      cal: latestPlan.target_cal,
      protein: latestPlan.target_protein,
      fat: latestPlan.target_fat,
      carb: latestPlan.target_carb,
      fiber: latestPlan.target_fiber,
      sodium: latestPlan.target_sodium,
    };

    // Build 7-day window (today and 6 previous days)
    const days: any[] = [];
    const now = new Date();
    now.setHours(23, 59, 59, 999);

    for (let i = 6; i >= 0; i--) {
      const dayStart = new Date(now);
      dayStart.setDate(dayStart.getDate() - i);
      dayStart.setHours(0, 0, 0, 0);
      const dayEnd = new Date(dayStart);
      dayEnd.setHours(23, 59, 59, 999);

      const { data: records } = await client
        .from("food_records")
        .select("cal, protein, fat, carb, fiber, sodium")
        .eq("patient_id", resolvedId)
        .gte("date", dayStart.toISOString())
        .lte("date", dayEnd.toISOString());

      const totals = (records || []).reduce(
        (acc: any, r: any) => ({
          cal: acc.cal + r.cal,
          protein: acc.protein + r.protein,
          fat: acc.fat + r.fat,
          carb: acc.carb + r.carb,
          fiber: acc.fiber + r.fiber,
          sodium: acc.sodium + r.sodium,
        }),
        { cal: 0, protein: 0, fat: 0, carb: 0, fiber: 0, sodium: 0 },
      );

      const ratios = [
        target.cal > 0 ? Math.min(totals.cal, target.cal) / target.cal : 0,
        target.protein > 0 ? Math.min(totals.protein, target.protein) / target.protein : 0,
        target.fat > 0 ? Math.min(totals.fat, target.fat) / target.fat : 0,
        target.carb > 0 ? Math.min(totals.carb, target.carb) / target.carb : 0,
        target.fiber > 0 ? Math.min(totals.fiber, target.fiber) / target.fiber : 0,
        totals.sodium <= target.sodium ? 1 : target.sodium / Math.max(totals.sodium, 1),
      ];
      const compliance = Math.round((ratios.reduce((s, r) => s + r, 0) / ratios.length) * 100);

      days.push({
        date: dayStart.toISOString(),
        dayLabel: dayStart.toLocaleDateString("id-ID", { weekday: "short" }),
        dateLabel: dayStart.toLocaleDateString("id-ID", { day: "numeric", month: "numeric" }),
        totals,
        compliance,
        recordCount: (records || []).length,
      });
    }

    const weeklyAvgCompliance = Math.round(days.reduce((s, d) => s + d.compliance, 0) / days.length);
    const weeklyAvgCal = Math.round(days.reduce((s, d) => s + d.totals.cal, 0) / days.length);

    return ok({
      hasPlan: true,
      plan: {
        id: latestPlan.id,
        date: new Date(latestPlan.date).toISOString(),
        presetName: latestPlan.nutrition_presets?.name || null,
        target,
      },
      days,
      weeklyAvg: { compliance: weeklyAvgCompliance, cal: weeklyAvgCal },
    });
  } catch (e) {
    return handleZod(e);
  }
}
