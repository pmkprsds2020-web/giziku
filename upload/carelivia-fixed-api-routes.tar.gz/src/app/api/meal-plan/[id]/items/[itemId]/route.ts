import { NextRequest } from "next/server";
import { ok, err, handleZod, safeParse } from "@/lib/api-helpers";
import { computeFoodNutrition, computeCompliance } from "@/lib/clinical/calorie-engine";
import { z } from "zod";
import { getServerClient, resolveFoodId, foodFromSupabase } from "@/lib/supabase/data-layer";

const UpdateItemSchema = z.object({
  foodId: z.string().min(1).optional(),
  amount: z.number().min(1).max(1000).optional(),
});

async function recalcPlan(client: any, mealPlanId: string) {
  const { data: items } = await client.from("meal_plan_items").select("*").eq("meal_plan_id", mealPlanId);
  const totals = (items || []).reduce(
    (acc: any, i: any) => ({
      cal: acc.cal + i.cal,
      protein: acc.protein + i.protein,
      fat: acc.fat + i.fat,
      carb: acc.carb + i.carb,
      fiber: acc.fiber + i.fiber,
      sodium: acc.sodium + i.sodium,
    }),
    { cal: 0, protein: 0, fat: 0, carb: 0, fiber: 0, sodium: 0 },
  );

  const { data: plan } = await client.from("meal_plans").select("*").eq("id", mealPlanId).single();
  let compliance = 0;
  if (plan) {
    compliance = computeCompliance(totals, {
      cal: plan.target_cal,
      protein: plan.target_protein,
      fat: plan.target_fat,
      carb: plan.target_carb,
      fiber: plan.target_fiber,
      sodiumMax: plan.target_sodium,
    });
  }

  await client
    .from("meal_plans")
    .update({
      total_cal: Math.round(totals.cal),
      total_protein: Math.round(totals.protein),
      total_fat: Math.round(totals.fat),
      total_carb: Math.round(totals.carb),
      total_fiber: Math.round(totals.fiber),
      total_sodium: Math.round(totals.sodium),
      compliance,
    })
    .eq("id", mealPlanId);
  return { totals, compliance };
}

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string; itemId: string }> },
) {
  try {
    const { id, itemId } = await params;
    const body = await req.json();
    const parsed = safeParse(UpdateItemSchema, body);
    if (!parsed.success) return handleZod(parsed.error);
    const d = parsed.data;

    const { client } = await getServerClient();
    const { data: existing } = await client.from("meal_plan_items").select("*").eq("id", itemId).maybeSingle();
    if (!existing || existing.meal_plan_id !== id) {
      return err("Item tidak ditemukan dalam meal plan ini", 404);
    }

    const foodId = d.foodId ? await resolveFoodId(d.foodId) : existing.food_id;
    const amount = d.amount ?? existing.amount;

    const { data: food } = await client.from("foods").select("*").eq("id", foodId).maybeSingle();
    if (!food) return err("Bahan makanan tidak ditemukan", 404);

    const nut = computeFoodNutrition(food, amount);

    const { data: updatedRow, error: updateError } = await client
      .from("meal_plan_items")
      .update({
        food_id: foodId,
        amount,
        cal: nut.cal,
        protein: nut.protein,
        fat: nut.fat,
        carb: nut.carb,
        fiber: nut.fiber,
        sodium: nut.sodium,
      })
      .eq("id", itemId)
      .select()
      .single();
    if (updateError) return err(updateError.message, 500);

    const { totals, compliance } = await recalcPlan(client, id);

    const item = { ...updatedRow, food: foodFromSupabase(food) };
    return ok({ item, totals: { ...totals, compliance } });
  } catch (e) {
    return handleZod(e);
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string; itemId: string }> },
) {
  try {
    const { id, itemId } = await params;
    const { client } = await getServerClient();
    const { data: existing } = await client.from("meal_plan_items").select("id, meal_plan_id").eq("id", itemId).maybeSingle();
    if (!existing || existing.meal_plan_id !== id) {
      return err("Item tidak ditemukan", 404);
    }

    const { error } = await client.from("meal_plan_items").delete().eq("id", itemId);
    if (error) return err(error.message, 500);

    const { totals, compliance } = await recalcPlan(client, id);

    return ok({ deleted: true, totals: { ...totals, compliance } });
  } catch (e) {
    return handleZod(e);
  }
}
