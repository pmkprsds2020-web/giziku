import { NextRequest } from "next/server";
import { ok, err, handleZod, safeParse } from "@/lib/api-helpers";
import { computeFoodNutrition, computeCompliance } from "@/lib/clinical/calorie-engine";
import { z } from "zod";
import { getServerClient, resolveFoodId, foodFromSupabase } from "@/lib/supabase/data-layer";

const AddItemSchema = z.object({
  slot: z.enum(["BREAKFAST", "MORNING_SNACK", "LUNCH", "AFTERNOON_SNACK", "DINNER", "EVENING_SNACK"]),
  foodId: z.string().min(1),
  amount: z.number().min(1).max(1000),
});

// Recalculate meal plan totals + compliance from items
async function recalcPlan(client: any, mealPlanId: string) {
  const { data: items } = await client.from("meal_plan_items").select("*").eq("meal_plan_id", mealPlanId);
  const totals = (items || []).reduce(
    (acc: any, i: any) => ({
      cal: acc.cal + i.cal,
      protein: acc.protein + i.protein,
      fat: acc.fat + i.fat,
      carb: acc.carb + i.carb,
      fiber: acc.fiber + i.fiber,
      sodium: acc.sodium + i.sodium,
    }),
    { cal: 0, protein: 0, fat: 0, carb: 0, fiber: 0, sodium: 0 },
  );

  const { data: plan } = await client.from("meal_plans").select("*").eq("id", mealPlanId).single();
  let compliance = 0;
  if (plan) {
    compliance = computeCompliance(totals, {
      cal: plan.target_cal,
      protein: plan.target_protein,
      fat: plan.target_fat,
      carb: plan.target_carb,
      fiber: plan.target_fiber,
      sodiumMax: plan.target_sodium,
    });
  }

  await client
    .from("meal_plans")
    .update({
      total_cal: Math.round(totals.cal),
      total_protein: Math.round(totals.protein),
      total_fat: Math.round(totals.fat),
      total_carb: Math.round(totals.carb),
      total_fiber: Math.round(totals.fiber),
      total_sodium: Math.round(totals.sodium),
      compliance,
    })
    .eq("id", mealPlanId);
  return { totals, compliance };
}

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const body = await req.json();
    const parsed = safeParse(AddItemSchema, body);
    if (!parsed.success) return handleZod(parsed.error);
    const d = parsed.data;

    const resolvedFoodId = await resolveFoodId(d.foodId);
    const { client } = await getServerClient();

    const { data: plan } = await client.from("meal_plans").select("id").eq("id", id).maybeSingle();
    if (!plan) return err("Meal plan tidak ditemukan", 404);

    const { data: food } = await client.from("foods").select("*").eq("id", resolvedFoodId).maybeSingle();
    if (!food) return err("Bahan makanan tidak ditemukan", 404);

    const nut = computeFoodNutrition(food, d.amount);

    const { data: itemRow, error: itemError } = await client
      .from("meal_plan_items")
      .insert({
        meal_plan_id: id,
        slot: d.slot,
        food_id: resolvedFoodId,
        amount: d.amount,
        cal: nut.cal,
        protein: nut.protein,
        fat: nut.fat,
        carb: nut.carb,
        fiber: nut.fiber,
        sodium: nut.sodium,
      })
      .select()
      .single();
    if (itemError) return err(itemError.message, 500);

    const { totals, compliance } = await recalcPlan(client, id);

    const item = { ...itemRow, food: foodFromSupabase(food) };
    return ok({ item, totals: { ...totals, compliance } }, 201);
  } catch (e) {
    return handleZod(e);
  }
}

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const { client } = await getServerClient();
    const { data, error } = await client
      .from("meal_plan_items")
      .select("*, foods(*)")
      .eq("meal_plan_id", id)
      .order("created_at", { ascending: true });
    if (error) return err(error.message, 500);
    return ok((data || []).map((i: any) => ({ ...i, food: i.foods ? foodFromSupabase(i.foods) : null })));
  } catch (e) {
    return handleZod(e);
  }
}
