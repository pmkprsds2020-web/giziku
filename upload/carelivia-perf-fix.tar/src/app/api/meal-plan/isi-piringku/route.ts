import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, err, handleZod, ageFromBirth } from "@/lib/api-helpers";
import { computeCalorieTarget } from "@/lib/clinical/calorie-engine";
import { generateMealPlan } from "@/lib/ai/meal-generator";
import {
  supabaseListMealPlanRotation,
  supabaseGetPatient,
  getServerClient,
  resolvePatientId,
} from "@/lib/supabase/data-layer";

// ---------------------------------------------------------------------
// POST /api/meal-plan/isi-piringku
// Generates an Isi Piringku compliant meal plan PREVIEW (does not persist).
// ALL data comes from Supabase — NO Prisma.
//
// Body: { patientId, presetId?, rotationHistory?, currentDay? }
// ---------------------------------------------------------------------
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      patientId,
      presetId,
      rotationHistory,
      currentDay,
    } = body as {
      patientId?: string;
      presetId?: string;
      rotationHistory?: { day: number; items: { foodId: string; foodName: string }[] }[];
      currentDay?: number;
    };

    if (!patientId) return err("patientId wajib diisi", 422);

    // Resolve Prisma cuid → Supabase UUID if needed
    const resolvedPatientId = await resolvePatientId(patientId);

    // Try Supabase first, fall back to Prisma for patient data
    let patient: any = await supabaseGetPatient(resolvedPatientId);
    if (!patient) {
      // Prisma fallback — handles case when Supabase RLS blocks access
      patient = await db.patient.findUnique({
        where: { id: patientId },
        include: {
          diagnoses: { where: { active: true } },
          assessments: { orderBy: { recordedAt: "desc" }, take: 1 },
        },
      });
    }
    if (!patient) return err("Pasien tidak ditemukan", 404);
    if (!patient.height || !patient.weight)
      return err("Tinggi & berat badan pasien harus diisi", 422);

    const ageYears = ageFromBirth(patient.birthDate);
    const latestAssessment = patient.assessments?.[0];

    // Filter active diagnoses
    const activeDiagnoses = (patient.diagnoses || []).filter((d: any) => d.active);

    // Derive activity & stress from assessment
    let activity = "LIGHT" as string;
    let stress = "NONE" as string;
    if (latestAssessment) {
      if (latestAssessment.activity) {
        activity = latestAssessment.activity;
      } else if (latestAssessment.ecog) {
        const ecogNum = Number(latestAssessment.ecog);
        if (ecogNum >= 3) activity = "BED_REST";
        else if (ecogNum === 2) activity = "VERY_LIGHT";
        else if (ecogNum === 1) activity = "LIGHT";
        else activity = "MODERATE";
      } else if (latestAssessment.barthel != null) {
        if (latestAssessment.barthel < 40) activity = "BED_REST";
        else if (latestAssessment.barthel < 60) activity = "VERY_LIGHT";
        else activity = "LIGHT";
      }
      if (latestAssessment.stress) stress = latestAssessment.stress;
    }

    const calResult = computeCalorieTarget({
      gender: patient.gender,
      ageYears,
      heightCm: patient.height,
      weightKg: patient.weight,
      activity: activity as any,
      stress: stress as any,
      diagnoses: activeDiagnoses.map((d: any) => d.type),
      isPregnant: patient.isPregnant,
      pregnancyTrimester: patient.pregnancyTrimester,
      isLactating: patient.isLactating,
    });

    // Preset override — fetch from Supabase
    let preset: any = null;
    let targets = {
      targetCal: calResult.targetCalorie,
      targetProtein: calResult.macros.proteinG,
      targetFat: calResult.macros.fatG,
      targetCarb: calResult.macros.carbG,
      targetFiber: calResult.fiberTarget,
      targetSodium: calResult.sodiumMax,
    };
    if (presetId) {
      const { client } = await getServerClient();
      const { data: presetData } = await client
        .from("nutrition_presets")
        .select("*")
        .eq("id", presetId)
        .is("deleted_at", null)
        .single();
      if (presetData) {
        preset = {
          id: presetData.id,
          name: presetData.name,
          totalCal: presetData.total_cal,
          proteinG: presetData.protein_g,
          fatG: presetData.fat_g,
          carbG: presetData.carb_g,
          fiberG: presetData.fiber_g,
          sodiumMg: presetData.sodium_mg,
          proteinPct: presetData.protein_pct,
          fatPct: presetData.fat_pct,
          carbPct: presetData.carb_pct,
        };
        targets = {
          targetCal: preset.totalCal,
          targetProtein: preset.proteinG,
          targetFat: preset.fatG,
          targetCarb: preset.carbG,
          targetFiber: preset.fiberG,
          targetSodium: preset.sodiumMg,
        };
        (calResult as any).targetCalorie = preset.totalCal;
        (calResult as any).macros = {
          proteinG: preset.proteinG,
          fatG: preset.fatG,
          carbG: preset.carbG,
          proteinKcal: preset.proteinG * 4,
          fatKcal: preset.fatG * 9,
          carbKcal: preset.carbG * 4,
          proteinPct: preset.proteinPct,
          fatPct: preset.fatPct,
          carbPct: preset.carbPct,
        };
        (calResult as any).fiberTarget = preset.fiberG;
        (calResult as any).sodiumMax = preset.sodiumMg;
      }
    }

    // Build rotation history from patient's last 14 meal plans (from Supabase)
    let rotation = rotationHistory;
    if (!rotation) {
      rotation = await supabaseListMealPlanRotation(resolvedPatientId, 14);
    }

    const plan = await generateMealPlan(
      calResult,
      activeDiagnoses.map((d: any) => d.type),
      { rotationHistory: rotation, currentDay: currentDay ?? (rotation?.length ?? 0) },
    );

    // AI reasoning is NOT awaited here — the deterministic Isi Piringku plan
    // is already complete and correct on its own. Waiting up to 15s for an
    // LLM narrative was the single biggest latency source in this endpoint.
    // The client fetches the narrative afterwards via
    // POST /api/meal-plan/ai-reasoning, so Generate returns as soon as the
    // (fast, DB + math only) plan is ready.
    const fallbackReasoning = `Rencana makan disusun mengikuti Pedoman "Isi Piringku" Kemenkes RI dengan compliance ${plan.overallCompliance}% (${plan.overallTierLabel}). Setiap makan utama mengandung makanan pokok, lauk pauk, sayuran, dan buah.`;

    return ok({
      plan,
      calorieResult: calResult,
      preset,
      aiReasoning: fallbackReasoning,
      aiReasoningPending: true,
      patient: {
        id: patient.id,
        name: patient.name,
        mrn: patient.mrn,
        diagnoses: activeDiagnoses.map((d: any) => d.type),
      },
      targets,
      isPreview: true,
    });
  } catch (e) {
    return handleZod(e);
  }
}
