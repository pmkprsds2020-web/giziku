import { NextRequest } from "next/server";
import { ok, err, handleZod } from "@/lib/api-helpers";
import { generateAIReasoning } from "@/lib/ai/meal-generator";

// ---------------------------------------------------------------------
// POST /api/meal-plan/ai-reasoning
// Returns the LLM narrative evaluation for a meal plan that has ALREADY
// been generated (deterministically, from /api/meal-plan/isi-piringku).
//
// This is intentionally a separate endpoint so the UI can render the
// (fast, math + Supabase only) plan immediately and fetch this narrative
// afterwards in the background, instead of the Generate action blocking
// on an LLM call.
//
// Body: { calorieResult, plan, diagnoses, patientName }
// ---------------------------------------------------------------------
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { calorieResult, plan, diagnoses, patientName } = body as {
      calorieResult?: any;
      plan?: any;
      diagnoses?: string[];
      patientName?: string;
    };

    if (!calorieResult || !plan) {
      return err("calorieResult dan plan wajib diisi", 422);
    }

    // Still bounded so a slow/hung LLM call can't hang this request forever,
    // but this no longer costs the Generate button anything — the plan is
    // already on screen while this resolves.
    const reasoningPromise = generateAIReasoning(
      calorieResult,
      plan,
      (diagnoses || []) as any,
      patientName || "",
    );
    const timeoutPromise = new Promise<string>((_, reject) =>
      setTimeout(() => reject(new Error("AI reasoning timeout")), 20000),
    );

    let reasoning: string;
    try {
      reasoning = await Promise.race([reasoningPromise, timeoutPromise]);
    } catch (e) {
      console.warn("[ai-reasoning] AI reasoning failed:", e);
      reasoning = `Rencana makan disusun mengikuti Pedoman "Isi Piringku" Kemenkes RI dengan compliance ${plan.overallCompliance}% (${plan.overallTierLabel}). Setiap makan utama mengandung makanan pokok, lauk pauk, sayuran, dan buah. AI reasoning gagal dimuat — silakan coba lagi.`;
    }

    return ok({ aiReasoning: reasoning });
  } catch (e) {
    return handleZod(e);
  }
}
